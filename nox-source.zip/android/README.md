# NØX Android

Native Kotlin/Jetpack Compose authentication client for the existing NØX API.
It is Persian-first (RTL is inherited from the Persian device locale), uses Material 3,
and keeps the access and refresh tokens in AndroidX encrypted preferences. Recovery
codes and OTPs are never persisted or logged.

## Configure and run on Windows

1. Install Android Studio (current stable) with Android SDK Platform 35 and JDK 17.
2. Start PostgreSQL and configure the backend as described in `../README.md`:

   ```powershell
   cd ..\backend
   Copy-Item .env.example .env
   # Set DATABASE_URL, TEST_DATABASE_URL, JWT_ACCESS_SECRET, SERVER_PEPPER.
   npm install
   npx prisma generate
   npx prisma migrate deploy
   npm run dev
   ```

3. Open the `android` directory in Android Studio and let it download Gradle dependencies.
4. In the app, open **تنظیم آدرس سرور** before signing in:
   - Android Emulator and backend on this computer: `http://10.0.2.2:3000`
   - Physical phone on the same network: `http://<computer-LAN-IP>:3000`
   - Deployed server: `https://api.example.com`

   HTTP is accepted only in the `debug` build for local development. Release builds
   do not permit cleartext traffic; use HTTPS with a valid certificate.

5. Select an emulator/device and press Run, or build an APK:

   ```powershell
   cd android
   .\gradlew.bat :app:assembleDebug
   # If the wrapper has not been generated yet, Android Studio can generate it on first sync.
   # Or, with a compatible Gradle installation: gradle :app:assembleDebug
   ```

   The debug APK is `app\build\outputs\apk\debug\app-debug.apk`. Install it with:

   ```powershell
   adb install -r app\build\outputs\apk\debug\app-debug.apk
   ```

## External providers

- Email: configure `SMTP_HOST`, `SMTP_FROM`, and the other SMTP values in the backend `.env`.
- SMS: configure `SMS_PROVIDER=kavenegar`, `KAVENEGAR_API_KEY`, and `KAVENEGAR_TEMPLATE`.
- Google: create Android and Web OAuth clients in Google Cloud, register the Web client ID in
  `GOOGLE_CLIENT_IDS` on the backend, and provide the same Web client ID at build time (never a secret):

  ```powershell
  .\gradlew.bat :app:assembleDebug -PNOX_GOOGLE_WEB_CLIENT_ID="your-web-client-id.apps.googleusercontent.com"
  ```

## Manual end-to-end checklist

- Create a guest account, save its one-time recovery code, close/reopen, and recover it.
- Verify wrong account ID/recovery code, OTP expiry, wrong OTP, resend cooldown and rate limits.
- Link email/phone to a guest and confirm the account code, wallet and profile remain unchanged.
- Attempt to link a method owned by another account and verify `IDENTITY_IN_USE` without a merge.
- Disable networking / use an invalid URL and verify the retry-safe Persian error.
- Leave a guest inactive near the configured warning period and verify account status shows expiry.
- Test on a Persian-locale physical phone to confirm RTL order, type sizes and touch targets.
