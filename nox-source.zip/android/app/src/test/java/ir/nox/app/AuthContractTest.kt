package ir.nox.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthContractTest {
    @Test fun api_failure_keeps_server_code_for_the_ui() {
        val error = ApiFailure("IDENTITY_IN_USE", "این روش ورود قبلاً استفاده شده است")
        assertEquals("IDENTITY_IN_USE", error.code)
        assertTrue(error.message.contains("قبلاً"))
    }
    @Test fun captcha_option_has_only_opaque_identifier_and_image_url() {
        val option = CaptchaOption("opaque-token", "https://api.example/v1/captcha/challenges/id/images/opaque-token.svg")
        assertEquals("opaque-token", option.id)
        assertTrue(option.imageUrl.endsWith(".svg"))
    }
    @Test fun authentication_inputs_are_validated_before_networking() {
        assertTrue(InputValidation.otp("123456"))
        assertTrue(!InputValidation.otp("12345x"))
        assertTrue(InputValidation.email("player@example.com"))
        assertTrue(!InputValidation.email("not-an-email"))
        assertTrue(InputValidation.phone("09123456789"))
        assertTrue(!InputValidation.phone("123"))
    }
}
