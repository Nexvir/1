package ir.nox.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.annotation.DrawableRes
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import java.text.NumberFormat
import java.util.Locale

val NoxBg = Color(0xFF0B0716)
val NoxBg2 = Color(0xFF1A0B33)
val NoxCard = Color(0xFF150E27)
val NoxPurple = Color(0xFFC86BFF)
val NoxBlue = Color(0xFF3AA8FF)
val NoxPink = Color(0xFFFF4FA3)
val NoxGold = Color(0xFFFFC94A)
val NoxGreen = Color(0xFF2EE6A0)
val NoxMuted = Color(0xFF9A90B5)

@Composable fun NIcon(@DrawableRes id: Int, modifier: Modifier = Modifier, tint: Color = Color.White, size: Dp = 22.dp) =
    Icon(painterResource(id), contentDescription = null, modifier = modifier.size(size), tint = tint)

fun fmt(n: Int): String = NumberFormat.getInstance(Locale.US).format(n)

@Composable fun NoxBackground(content: @Composable BoxScope.() -> Unit) =
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(NoxBg2, NoxBg))), content = content)

@Composable fun GlowCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    align: Alignment.Horizontal = Alignment.Start,
    accentColor: Color? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    val borderBrush = accentColor?.let { Brush.linearGradient(listOf(it, it.copy(alpha = 0.45f))) } ?: Brush.linearGradient(listOf(NoxPurple, NoxBlue))
    val base = modifier.clip(shape).background(NoxCard, shape).border(1.dp, borderBrush, shape)
    Column((if (onClick != null) base.clickable(onClick = onClick) else base).padding(14.dp), horizontalAlignment = align, content = content)
}

@Composable fun NeonButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    val brush = if (enabled) Brush.horizontalGradient(listOf(NoxPurple, NoxPink)) else Brush.horizontalGradient(listOf(Color(0xFF3A3350), Color(0xFF3A3350)))
    Box(
        modifier.clip(shape).background(brush).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold) }
}

@Composable fun Pill(text: String, color: Color = NoxPurple, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape).background(color.copy(alpha = 0.18f)).border(1.dp, color.copy(alpha = 0.6f), shape).padding(horizontal = 10.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun Avatar(name: String, size: Dp = 48.dp, imageUrl: String? = null, frameColor: Color? = null) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(NoxPurple, NoxBlue))).border(3.dp, (frameColor ?: NoxPink).copy(alpha = 0.9f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (!imageUrl.isNullOrBlank()) AsyncImage(model = imageUrl, contentDescription = "تصویر پروفایل $name", modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
        else Text(name.trim().take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
    }
}

@Composable fun XpBar(progress: Float, modifier: Modifier = Modifier) =
    LinearProgressIndicator(
        progress = { progress.coerceIn(0f, 1f) },
        modifier = modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
        color = NoxGold,
        trackColor = Color(0xFF2B2145),
    )

@Composable fun StatPill(@DrawableRes icon: Int, value: String, modifier: Modifier = Modifier, tint: Color = NoxPurple) {
    val shape = RoundedCornerShape(14.dp)
    Row(modifier.clip(shape).background(Color(0xFF1E1536)).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        NIcon(icon, tint = tint, size = 20.dp)
        Text("  $value", fontWeight = FontWeight.Bold, color = Color.White)
    }
}
