package ir.nox.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class MainState(
    val wallet: WalletSummary? = null,
    val txs: List<Tx> = emptyList(),
    val rank: List<RankItem> = emptyList(),
    val rankMe: RankMe? = null,
    val friends: List<Friend> = emptyList(),
    val requests: List<FriendReq> = emptyList(),
    val conversations: List<Conversation> = emptyList(),
    val chatMessages: List<ChatMessage> = emptyList(),
    val storeItems: List<StoreItem> = emptyList(),
    val inventory: List<InventoryEntry> = emptyList(),
    val myProfile: Profile? = null,
    val viewedProfile: PublicProfile? = null,
    val notifs: List<Notif> = emptyList(),
    val unread: Int = 0,
    val loading: Boolean = false,
    val message: String? = null,
)

class MainViewModel(private val api: NoxApi) : ViewModel() {
    private val _ui = MutableStateFlow(MainState())
    val ui: StateFlow<MainState> = _ui

    private fun update(change: (MainState) -> MainState) { _ui.value = change(_ui.value) }

    private fun run(action: suspend () -> Unit) = viewModelScope.launch {
        update { it.copy(loading = true) }
        try { action() }
        catch (e: CancellationException) { throw e }
        catch (e: ApiFailure) { update { it.copy(message = e.message) } }
        catch (e: Exception) { update { it.copy(message = "خطا در دریافت اطلاعات. اتصال به سرور را بررسی کن.") } }
        finally { update { it.copy(loading = false) } }
    }

    fun clearMessage() = update { it.copy(message = null) }
    fun loadUnread() = run { val n = api.unreadCount(); update { it.copy(unread = n) } }
    fun loadWallet() = run { val w = api.wallet(); val t = api.transactions(); update { it.copy(wallet = w, txs = t) } }
    fun loadRanking(kind: String = "wealth") = run { val (items, me) = api.leaderboard(kind); update { it.copy(rank = items, rankMe = me) } }
    fun loadFriends() = run { val f = api.friends(); val r = api.friendRequests(); update { it.copy(friends = f, requests = r) } }
    fun loadChats() = run { val conversations = api.conversations(); update { it.copy(conversations = conversations) } }
    fun startConversation(username: String, onReady: (String) -> Unit) = run { val id = api.startConversation(username); onReady(id) }
    fun loadMessages(id: String) = run { val messages = api.messages(id); update { it.copy(chatMessages = messages) } }
    fun sendMessage(id: String, body: String) = run { api.sendMessage(id, body); val messages = api.messages(id); update { it.copy(chatMessages = messages) } }
    fun loadProfile(username: String) = run { val profile = api.publicProfile(username); update { it.copy(viewedProfile = profile) } }
    fun loadStore() = run { val items = api.storeItems(); val inventory = api.inventory(); val profile = api.me(); update { it.copy(storeItems = items, inventory = inventory, myProfile = profile) } }
    fun buyItem(sku: String) = run { api.buyStoreItem(sku, java.util.UUID.randomUUID().toString()); val items = api.storeItems(); val inventory = api.inventory(); val profile = api.me(); update { it.copy(storeItems = items, inventory = inventory, myProfile = profile, message = "آیتم خریداری شد.") } }
    fun equipItem(type: String, sku: String?) = run { api.equipStoreItem(type, sku); val profile = api.me(); update { it.copy(myProfile = profile, message = if (sku == null) "آیتم از پروفایل برداشته شد." else "آیتم روی پروفایل فعال شد.") } }
    fun requestFriend(username: String) = sendRequest(username)
    fun sendGift(username: String, amount: Int) = run { api.sendGift(username, amount); update { it.copy(message = "هدیه ارسال شد.") } }
    fun loadNotifs() = run { val n = api.notifications(); val c = api.unreadCount(); update { it.copy(notifs = n, unread = c) } }
    fun readAll() = run { api.readAllNotifications(); val n = api.notifications(); update { it.copy(notifs = n, unread = 0) } }
    fun sendRequest(username: String) = run { api.sendFriendRequest(username); update { it.copy(message = "درخواست دوستی ارسال شد.") } }
    fun respond(id: String, accept: Boolean) = run {
        api.respondFriendRequest(id, accept)
        val f = api.friends(); val r = api.friendRequests()
        update { it.copy(friends = f, requests = r, message = if (accept) "درخواست پذیرفته شد." else "درخواست رد شد.") }
    }
    fun buyCoins() = run { api.buyCoins(); update { it.copy(message = "درخواست ثبت شد.") } }
}
