package ir.nox.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class Screen { WELCOME, CAPTCHA, CONTACT, RECOVER, OTP, RECOVERY_CODE, ACCOUNT, SETTINGS, LINK, HOME }
data class UiState(val screen: Screen = Screen.WELCOME, val loading: Boolean = false, val message: String? = null, val methods: AuthMethods = AuthMethods(), val captcha: Captcha? = null, val captchaPass: String? = null, val afterCaptcha: String = "GUEST", val recoveryCode: String? = null, val account: Account? = null, val profile: Profile? = null, val otpChannel: String = "EMAIL", val otpDestination: String = "")

class AuthViewModel(private val api: NoxApi, private val store: SessionStore) : ViewModel() {
    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui
    init { loadMethods(); restore() }
    private fun update(block: (UiState) -> UiState) { _ui.value = block(_ui.value) }
    private fun run(action: suspend () -> Unit) = viewModelScope.launch { update { it.copy(loading = true, message = null) }; try { action() } catch (e: ApiFailure) { update { it.copy(message = e.message) } } finally { update { it.copy(loading = false) } } }
    fun loadMethods() = run { val methods = api.methods(); update { it.copy(methods = methods) } }
    fun restore() { if (store.tokens() != null) run { val account = api.account(); val profile = api.me(); update { it.copy(account = account, profile = profile, screen = Screen.HOME) } } }
    fun refreshAccount() = run { val account = api.account(); update { it.copy(account = account) } }
    fun enterHome() = run { val profile = api.me(); update { it.copy(profile = profile, screen = Screen.HOME) } }
    fun updateProfile(name: String, bio: String, avatarUrl: String) = run { val charged = api.updateProfile(name, bio, avatarUrl); val profile = api.me(); update { it.copy(profile = profile, message = if (charged == 0) "پروفایل ذخیره شد؛ هزینه‌ای نداشت." else "پروفایل ذخیره شد؛ $charged سکه پرداخت شد.") } }
    fun openCaptcha(flow: String = "GUEST") = run { val captcha = api.captcha(); update { it.copy(captcha = captcha, captchaPass = null, afterCaptcha = flow, screen = Screen.CAPTCHA) } }
    fun answer(option: String) = run { val pass = api.answerCaptcha(_ui.value.captcha!!.id, option); val flow = _ui.value.afterCaptcha; update { it.copy(captchaPass = pass, screen = if (flow == "GUEST") Screen.CAPTCHA else Screen.CONTACT, otpChannel = flow) }; if (flow == "GUEST") createGuestWithCode() }
    fun retryCaptcha() = openCaptcha(_ui.value.afterCaptcha)
    fun createGuestWithCode() = run { val result = api.guestWithCode(_ui.value.captchaPass); update { it.copy(account = result.first, recoveryCode = result.second, screen = Screen.RECOVERY_CODE) } }
    fun recover(account: String, code: String) = run { val result = api.recover(account, code); val profile = api.me(); update { it.copy(account = result, profile = profile, screen = Screen.HOME) } }
    fun requestOtp(channel: String, destination: String) = run { api.requestOtp(channel, destination, _ui.value.captchaPass); update { it.copy(screen = Screen.OTP, otpChannel = channel, otpDestination = destination, message = "کد ارسال شد.") } }
    fun verifyOtp(code: String) = run { val old = _ui.value; val result = api.verifyOtp(old.otpChannel, old.otpDestination, code, old.captchaPass); val profile = api.me(); update { it.copy(account = result, profile = profile, screen = Screen.HOME, captchaPass = null) } }
    fun google(idToken: String) = run { val result = api.google(idToken, _ui.value.captchaPass); val profile = api.me(); update { it.copy(account = result, profile = profile, screen = Screen.HOME, captchaPass = null) } }
    fun rotate() = run { val code = api.rotate(); update { it.copy(recoveryCode = code, screen = Screen.RECOVERY_CODE) } }
    fun linkRequest(channel: String, destination: String) = run { api.linkOtpRequest(channel, destination); update { it.copy(screen = Screen.OTP, afterCaptcha = "LINK", otpChannel = channel, otpDestination = destination, message = "کد اتصال ارسال شد.") } }
    fun linkVerify(code: String) = run { val old = _ui.value; api.linkOtpVerify(old.otpChannel, old.otpDestination, code); val account = api.account(); update { it.copy(account = account, screen = Screen.ACCOUNT, message = "روش ورود متصل شد.") } }
    fun linkGoogle(idToken: String) = run { api.linkGoogle(idToken); val account = api.account(); update { it.copy(account = account, screen = Screen.ACCOUNT) } }
    fun settings(url: String) { store.setBaseUrl(url); update { it.copy(message = "آدرس ذخیره شد. اتصال را دوباره امتحان کن.") }; loadMethods() }
    fun navigate(screen: Screen) = update { it.copy(screen = screen, message = null) }
    fun logout() { store.clear(); update { UiState(methods = it.methods) } }
}
