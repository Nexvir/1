package ir.nox.app

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Modern Credential Manager flow. The backend, not this app, verifies the returned ID token. */
suspend fun requestGoogleIdToken(context: Context): String {
    require(BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()) { "شناسهٔ Web client برای Google تنظیم نشده است." }
    val option = GetGoogleIdOption.Builder().setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID).setFilterByAuthorizedAccounts(false).setAutoSelectEnabled(false).build()
    val result = CredentialManager.create(context).getCredential(context, GetCredentialRequest.Builder().addCredentialOption(option).build())
    val credential = result.credential
    require(credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) { "حساب Google انتخاب نشد." }
    return GoogleIdTokenCredential.createFrom(credential.data).idToken
}
