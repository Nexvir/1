package ir.nox.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.SvgDecoder
import kotlinx.coroutines.launch

private val NoxColors = darkColorScheme(primary = Color(0xFFC86BFF), secondary = Color(0xFF66A9FF), tertiary = Color(0xFFFF78B8), background = Color(0xFF09070E), surface = Color(0xFF15111D), onBackground = Color(0xFFF1EAF5))

@Composable fun NoxApp(context: Context) {
    val model: AuthViewModel = viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory { @Suppress("UNCHECKED_CAST") override fun <T : androidx.lifecycle.ViewModel> create(c: Class<T>): T = AuthViewModel(NoxApi(SessionStore(context)), SessionStore(context)) as T })
    val state by model.ui.collectAsState()
    androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) { MaterialTheme(colorScheme = NoxColors) {
        Surface(Modifier.fillMaxSize()) { if (state.screen == Screen.HOME) MainShell(state, model) else Box(Modifier.padding(20.dp)) {
            when (state.screen) {
                Screen.WELCOME -> Welcome(state, model)
                Screen.CAPTCHA -> CaptchaScreen(state, model)
                Screen.CONTACT -> Contact(state, model)
                Screen.RECOVER -> Recover(state, model)
                Screen.OTP -> Otp(state, model)
                Screen.RECOVERY_CODE -> RecoveryCode(state, model)
                Screen.ACCOUNT -> AccountScreen(state, model)
                Screen.SETTINGS -> Settings(state, model)
                Screen.LINK -> Link(state, model)
                Screen.HOME -> Unit
            }
            if (state.loading) CircularProgressIndicator(Modifier.align(Alignment.TopCenter).padding(8.dp))
            state.message?.let { Text(it, color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp), textAlign = TextAlign.Center) }
        } }
    } }
}
@Composable private fun Frame(title: String, body: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) { Spacer(Modifier.height(34.dp)); Text("NØX", style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black); Text(title, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(vertical = 18.dp)); body() }
@Composable private fun Action(text: String, enabled: Boolean = true, click: () -> Unit) = Button(onClick = click, enabled = enabled, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(14.dp)) { Text(text) }
@Composable private fun Welcome(s: UiState, vm: AuthViewModel) = Frame("خوش آمدی") {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    Text("پیشرفتت در حساب NØX نگهداری می‌شود.", textAlign = TextAlign.Center, modifier = Modifier.padding(bottom = 18.dp))
    Action("شروع به‌عنوان مهمان") { vm.openCaptcha() }
    Action("ورود با ایمیل", s.methods.email) { vm.openCaptcha("EMAIL") }
    Action("ورود با شماره موبایل", s.methods.phone) { vm.openCaptcha("PHONE") }
    Action("ورود با Google", s.methods.google) { scope.launch { try { vm.google(requestGoogleIdToken(context)) } catch (_: Exception) { vm.navigate(Screen.SETTINGS) } } }
    OutlinedButton(onClick = { vm.navigate(Screen.RECOVER) }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text("بازیابی حساب") }
    TextButton(onClick = { vm.navigate(Screen.SETTINGS) }) { Text("تنظیم آدرس سرور") }
}
@Composable private fun CaptchaScreen(s: UiState, vm: AuthViewModel) = Frame("تأیید تصویری") {
    val c = s.captcha
    val context = LocalContext.current
    val loader = remember(context) { ImageLoader.Builder(context).components { add(SvgDecoder.Factory()) }.build() }
    if (c == null) { Text("در حال دریافت چالش…") } else { Text(c.prompt, textAlign = TextAlign.Center, style = MaterialTheme.typography.titleLarge); Spacer(Modifier.height(16.dp)); c.options.chunked(2).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { row.forEach { option -> Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(22.dp)).clickable { vm.answer(option.id) }) { AsyncImage(model = option.imageUrl, imageLoader = loader, contentDescription = "گزینهٔ چالش", modifier = Modifier.fillMaxSize()) } } }; Spacer(Modifier.height(10.dp)) }; TextButton(onClick = vm::retryCaptcha) { Text("چالش تازه") } }
}
@Composable private fun Contact(s: UiState, vm: AuthViewModel) = Frame(if (s.otpChannel == "EMAIL") "ورود با ایمیل" else "ورود با شماره") { var destination by remember { mutableStateOf("") }; Text(if (s.otpChannel == "EMAIL") "ایمیل خود را وارد کن." else "شمارهٔ موبایل ایران را وارد کن.", textAlign = TextAlign.Center); Field(if (s.otpChannel == "EMAIL") "ایمیل" else "شماره موبایل", destination) { destination = it }; Action("ارسال کد", destination.isNotBlank()) { vm.requestOtp(s.otpChannel, destination) }; TextButton(onClick = { vm.navigate(Screen.WELCOME) }) { Text("انصراف") } }
@Composable private fun Recover(s: UiState, vm: AuthViewModel) = Frame("بازیابی حساب") { var id by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }; Text("شناسهٔ حساب به‌تنهایی کافی نیست؛ کد بازیابی‌ات را هم وارد کن.", textAlign = TextAlign.Center); Field("شناسه حساب", id) { id = it }; Field("کد بازیابی", code) { code = it }; Action("بازیابی", id.isNotBlank() && code.isNotBlank()) { vm.recover(id, code) }; TextButton(onClick = { vm.navigate(Screen.WELCOME) }) { Text("بازگشت") } }
@Composable private fun Otp(s: UiState, vm: AuthViewModel) = Frame("کد تأیید") { var code by remember { mutableStateOf("") }; Text("کد شش‌رقمی ارسال‌شده به ${s.otpDestination} را وارد کن.", textAlign = TextAlign.Center); Field("کد تأیید", code) { code = it }; Action("تأیید", code.length == 6) { if (s.afterCaptcha == "LINK") vm.linkVerify(code) else vm.verifyOtp(code) }; TextButton(onClick = { if (s.afterCaptcha == "LINK") vm.linkRequest(s.otpChannel, s.otpDestination) else vm.requestOtp(s.otpChannel, s.otpDestination) }) { Text("ارسال دوباره") } }
@Composable private fun RecoveryCode(s: UiState, vm: AuthViewModel) = Frame("کد بازیابی") { Text("این کد فقط همین حالا نمایش داده می‌شود. آن را در جای امن نگه دار و با کسی به اشتراک نگذار.", textAlign = TextAlign.Center); Text(s.recoveryCode.orEmpty(), style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.tertiary, modifier = Modifier.padding(20.dp)); Action("کد را ذخیره کردم") { vm.enterHome() } }
@Composable private fun AccountScreen(s: UiState, vm: AuthViewModel) = Frame("حساب من") { val a = s.account; Text("شناسهٔ کاربری: @${a?.username.orEmpty()}"); Text("شناسهٔ بازیابی حساب: ${a?.code.orEmpty()}", color = MaterialTheme.colorScheme.secondary); Text(if (a?.guest == true) "حساب مهمان" else "حساب دائمی", color = MaterialTheme.colorScheme.secondary); a?.guestExpiry?.let { Text("انقضای مهمان: $it", modifier = Modifier.padding(8.dp)) }; if (a?.guest == true) Action("اتصال روش ورود") { vm.navigate(Screen.LINK) }; Action("تعویض کد بازیابی") { vm.rotate() }; Action("به‌روزرسانی وضعیت") { vm.refreshAccount() }; TextButton(onClick = { vm.navigate(Screen.HOME) }) { Text("بازگشت") }; TextButton(onClick = vm::logout) { Text("خروج") } }
@Composable private fun Link(s: UiState, vm: AuthViewModel) = Frame("اتصال روش ورود") { var value by remember { mutableStateOf("") }; var email by remember { mutableStateOf(true) }; Text("اطلاعات حساب مهمان حفظ می‌شود. اگر این روش برای حساب دیگری باشد، ادغام انجام نمی‌شود.", textAlign = TextAlign.Center); Row { FilterChip(selected = email, onClick = { email = true }, label = { Text("ایمیل") }); Spacer(Modifier.width(8.dp)); FilterChip(selected = !email, onClick = { email = false }, label = { Text("موبایل") }) }; Field(if (email) "ایمیل" else "شماره موبایل", value) { value = it }; Action("ارسال کد") { vm.linkRequest(if (email) "EMAIL" else "PHONE", value) }; TextButton(onClick = { vm.navigate(Screen.ACCOUNT) }) { Text("بازگشت") } }
@Composable private fun Settings(s: UiState, vm: AuthViewModel) {
    val context = LocalContext.current
    val store = remember(context) { SessionStore(context) }
    Frame("تنظیمات اتصال") {
        var url by remember { mutableStateOf(store.baseUrl()) }
        Text("برای امنیت، در نسخهٔ منتشرشده فقط HTTPS استفاده کن.", textAlign = TextAlign.Center)
        Field("آدرس API", url) { url = it }
        Action("ذخیره و بررسی") { vm.settings(url) }
        Text("Google Sign-In به Web client ID در Google Cloud و GOOGLE_CLIENT_IDS در سرور نیاز دارد.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(10.dp))
        TextButton(onClick = { vm.navigate(if (s.account != null) Screen.HOME else Screen.WELCOME) }) { Text("بازگشت") }
    }
}
@Composable private fun Field(label: String, value: String, change: (String) -> Unit) = OutlinedTextField(value, change, Modifier.fillMaxWidth().padding(vertical = 6.dp), label = { Text(label) }, singleLine = true)
