package ir.nox.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel

private val TABS = listOf(
    Triple("HOME", R.drawable.ic_home, "خانه"),
    Triple("GAMES", R.drawable.ic_gamepad, "بازی‌ها"),
    Triple("CHAT", R.drawable.ic_nox_chat, "چت"),
    Triple("CLANS", R.drawable.ic_shield, "کلن"),
    Triple("PROFILE", R.drawable.ic_user, "پروفایل"),
)

@Composable fun MainShell(state: UiState, auth: AuthViewModel) {
    val appContext = LocalContext.current.applicationContext
    val main: MainViewModel = viewModel(
        key = state.account?.code ?: "none",
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(NoxApi(SessionStore(appContext))) as T
        },
    )
    val ms by main.ui.collectAsState()
    var page by rememberSaveable { mutableStateOf("HOME") }
    var selectedUsername by rememberSaveable { mutableStateOf("") }
    var selectedConversationId by rememberSaveable { mutableStateOf("") }
    val isTab = TABS.any { it.first == page }

    BackHandler(enabled = page != "HOME") { page = "HOME" }
    LaunchedEffect(Unit) { main.loadUnread() }
    LaunchedEffect(page) {
        main.clearMessage()
        when (page) {
            "WALLET" -> main.loadWallet()
            "RANKING" -> main.loadRanking()
            "CHAT" -> main.loadChats()
            "FRIENDS" -> main.loadFriends()
            "STORE" -> main.loadStore()
            "CHAT_THREAD" -> if (selectedConversationId.isNotBlank()) main.loadMessages(selectedConversationId)
            "USER_PROFILE" -> if (selectedUsername.isNotBlank()) main.loadProfile(selectedUsername)
            "NOTIFS" -> main.loadNotifs()
        }
    }

    NoxBackground {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp)) {
                when (page) {
                    "HOME" -> HomePage(ms.myProfile ?: state.profile, ms.unread) { page = it }
                    "GAMES" -> GamesPage()
                    "CHAT" -> ChatPage(ms) { id -> selectedConversationId = id; page = "CHAT_THREAD" }
                    "FRIENDS" -> FriendsPage(ms, main) { username -> selectedUsername = username; page = "USER_PROFILE" }
                    "CHAT_THREAD" -> ChatThreadPage(ms, selectedConversationId, main) { page = "CHAT" }
                    "CLANS" -> SoonPage("کلن‌ها", R.drawable.ic_shield, "ساخت و پیوستن به کلن‌ها به‌زودی اضافه می‌شود.")
                    "STORE" -> StorePage(ms, main) { page = "HOME" }
                    "PROFILE" -> ProfilePage(ms.myProfile ?: state.profile) { page = it }
                    "EDIT_PROFILE" -> EditProfilePage(ms.myProfile ?: state.profile, auth) { page = "PROFILE" }
                    "USER_PROFILE" -> UserProfilePage(ms.viewedProfile, main, { page = "CHAT" }) { username -> main.startConversation(username) { id -> selectedConversationId = id; page = "CHAT_THREAD" } }
                    "WALLET" -> WalletPage(ms, main) { page = "HOME" }
                    "RANKING" -> RankingPage(ms, { page = "HOME" }, { kind -> main.loadRanking(kind) }) { username -> selectedUsername = username; page = "USER_PROFILE" }
                    "NOTIFS" -> NotifsPage(ms, main) { page = "HOME" }
                    "SETTINGS_MENU" -> SettingsMenuPage(auth) { page = "HOME" }
                }
                ms.message?.let { Text(it, color = NoxGold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) }
                state.message?.let { Text(it, color = NoxPink, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) }
                if (ms.loading) Text("در حال دریافت…", color = NoxMuted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 12.dp))
            }
            if (isTab) BottomBar(page) { page = it }
        }
    }
}

@Composable private fun BottomBar(current: String, select: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF100A20)).padding(vertical = 8.dp)) {
        TABS.forEach { (key, icon, label) ->
            val on = key == current
            Column(Modifier.weight(1f).clickable { select(key) }.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                NIcon(icon, tint = if (on) NoxPurple else NoxMuted, size = 24.dp)
                Text(label, fontSize = 11.sp, color = if (on) NoxPurple else NoxMuted, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

@Composable private fun IconPill(icon: Int, badge: Int = 0, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(NoxCard).border(1.dp, NoxPurple.copy(alpha = 0.5f), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        NIcon(icon, size = 20.dp)
        if (badge > 0) Box(Modifier.align(Alignment.TopEnd).size(16.dp).clip(CircleShape).background(NoxPink), contentAlignment = Alignment.Center) {
            Text(if (badge > 9) "9+" else badge.toString(), fontSize = 9.sp, color = Color.White)
        }
    }
}

@Composable private fun PageHeader(title: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) { IconPill(R.drawable.ic_back, 0, onBack); Spacer(Modifier.width(10.dp)) }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable private fun Coins(amount: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        NIcon(R.drawable.ic_coins, tint = NoxGold, size = 18.dp)
        Text(" ${fmt(amount)}", color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun Gap(h: Int = 12) = Spacer(Modifier.height(h.dp))

@Composable private fun HomePage(p: Profile?, unread: Int, go: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("NØX", style = MaterialTheme.typography.headlineMedium, color = NoxPurple, fontWeight = FontWeight.Black)
        Spacer(Modifier.weight(1f))
        IconPill(R.drawable.ic_bell, unread) { go("NOTIFS") }
        Spacer(Modifier.width(8.dp))
        IconPill(R.drawable.ic_settings) { go("SETTINGS_MENU") }
    }
    Gap(14)
    GlowCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(p?.displayName ?: "?", 64.dp, p?.avatarUrl, if (p?.equippedFrameId != null) NoxGold else null)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p?.displayName.orEmpty(), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color.White)
                Text("سطح ${p?.level ?: 1}", color = NoxBlue, fontWeight = FontWeight.Bold)
            }
        }
        Gap(10)
        XpBar(if (p == null) 0f else if (p.maxLevel) 1f else if (p.xpNext > 0) p.xpInto.toFloat() / p.xpNext else 0f)
        Text(
            if (p == null) "" else if (p.maxLevel) "حداکثر سطح" else "${fmt(p.xpInto)} / ${fmt(p.xpNext)} XP",
            fontSize = 12.sp, color = NoxMuted, modifier = Modifier.padding(top = 4.dp),
        )
        Gap(10)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatPill(R.drawable.ic_coins, fmt(p?.coins ?: 0), Modifier.weight(1f), NoxGold)
            StatPill(R.drawable.ic_trophy, fmt(p?.trophies ?: 0), Modifier.weight(1f), NoxGold)
        }
    }
    Gap()
    GlowCard(Modifier.fillMaxWidth()) {
        Text("به دنیای NØX خوش آمدی!", fontWeight = FontWeight.Bold, color = Color.White, style = MaterialTheme.typography.titleMedium)
        Text("بازی کن، دوست پیدا کن و در رتبه‌بندی بالا برو.", color = NoxMuted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp))
        NeonButton("رفتن به بازی‌ها", Modifier.fillMaxWidth()) { go("GAMES") }
    }
    Gap()
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Tile(R.drawable.ic_gamepad, "بازی‌ها", Modifier.weight(1f)) { go("GAMES") }
        Tile(R.drawable.ic_nox_chat, "چت", Modifier.weight(1f)) { go("CHAT") }
        Tile(R.drawable.ic_shield, "کلن‌ها", Modifier.weight(1f)) { go("CLANS") }
        Tile(R.drawable.ic_store, "فروشگاه", Modifier.weight(1f)) { go("STORE") }
    }
    Gap()
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Tile(R.drawable.ic_coins, "کیف پول", Modifier.weight(1f)) { go("WALLET") }
        Tile(R.drawable.ic_trophy, "رتبه‌بندی", Modifier.weight(1f)) { go("RANKING") }
    }
}

@Composable private fun Tile(icon: Int, label: String, modifier: Modifier, onClick: () -> Unit) {
    GlowCard(modifier, onClick, Alignment.CenterHorizontally) {
        NIcon(icon, tint = NoxPurple, size = 28.dp)
        Text(label, fontSize = 12.sp, color = Color.White, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable private fun GamesPage() {
    PageHeader("بازی‌ها")
    Text("بازی‌ها هنوز فعال نشده‌اند؛ این فهرست نمونهٔ ظاهر نهایی است.", color = NoxMuted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
    listOf(
        Triple(R.drawable.ic_car, "Speed Rush", "مسابقهٔ سرعت"),
        Triple(R.drawable.ic_gem, "Clash Cards", "نبرد کارتی"),
        Triple(R.drawable.ic_star, "Word Hunt", "شکار کلمه"),
        Triple(R.drawable.ic_ghost, "Mafia Night", "مافیا"),
    ).forEach { (icon, name, desc) ->
        GlowCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NIcon(icon, tint = NoxPurple, size = 36.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(desc, color = NoxMuted, fontSize = 12.sp)
                }
                Pill("به‌زودی", NoxGold)
            }
        }
    }
}

@Composable private fun SoonPage(title: String, icon: Int, text: String, onBack: (() -> Unit)? = null) {
    PageHeader(title, onBack)
    GlowCard(Modifier.fillMaxWidth(), align = Alignment.CenterHorizontally) {
        NIcon(icon, tint = NoxPurple, size = 56.dp)
        Text(text, color = NoxMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable private fun TabPill(text: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier.clip(shape).background(if (on) Brush.horizontalGradient(listOf(NoxPurple, NoxPink)) else Brush.horizontalGradient(listOf(NoxCard, NoxCard))).clickable(onClick = onClick).padding(vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable private fun FriendsPage(ms: MainState, main: MainViewModel, openProfile: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var username by remember { mutableStateOf("") }
    PageHeader("دوستان")
    GlowCard(Modifier.fillMaxWidth()) {
        Text("افزودن دوست", fontWeight = FontWeight.Bold, color = Color.White)
        OutlinedTextField(username, { username = it }, label = { Text("نام کاربری") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        NeonButton("ارسال درخواست", Modifier.fillMaxWidth(), enabled = username.isNotBlank()) { main.sendRequest(username.trim().lowercase()); username = "" }
    }
    Gap()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TabPill("دوستان (${ms.friends.size})", tab == 0, Modifier.weight(1f)) { tab = 0 }
        TabPill("درخواست‌ها (${ms.requests.size})", tab == 1, Modifier.weight(1f)) { tab = 1 }
    }
    Gap()
    if (tab == 0) {
        if (ms.friends.isEmpty()) Text("هنوز دوستی نداری.", color = NoxMuted)
        ms.friends.forEach { f ->
            GlowCard(Modifier.fillMaxWidth().padding(bottom = 8.dp), onClick = { openProfile(f.username) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(f.name, 44.dp); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text(f.name, fontWeight = FontWeight.Bold, color = Color.White); Text("@${f.username}", color = NoxMuted, fontSize = 12.sp) }
                    Pill("سطح ${f.level}", NoxBlue)
                }
            }
        }
    } else {
        if (ms.requests.isEmpty()) Text("درخواست جدیدی نداری.", color = NoxMuted)
        ms.requests.forEach { r ->
            GlowCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(r.name, 44.dp); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text(r.name, fontWeight = FontWeight.Bold, color = Color.White); Text("@${r.username}", color = NoxMuted, fontSize = 12.sp) }
                }
                Gap(8)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("پذیرفتن", Modifier.weight(1f)) { main.respond(r.id, true) }
                    TextButton(onClick = { main.respond(r.id, false) }, modifier = Modifier.weight(1f)) { Text("رد کردن", color = NoxMuted) }
                }
            }
        }
    }
}

@Composable private fun ProfilePage(p: Profile?, go: (String) -> Unit) {
    PageHeader("پروفایل")
    GlowCard(Modifier.fillMaxWidth(), align = Alignment.CenterHorizontally, accentColor = if (p?.equippedThemeId != null) Color(0xFF537DFF) else null) {
        Avatar(p?.displayName ?: "?", 88.dp, p?.avatarUrl, if (p?.equippedFrameId != null) NoxGold else null)
        Text(p?.displayName.orEmpty(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(top = 10.dp))
        p?.equippedTitleName?.let { Pill(it, NoxGold, Modifier.padding(top = 6.dp)) }
        p?.equippedBadgeName?.let { Pill(it, NoxPurple, Modifier.padding(top = 6.dp)) }
        if (!p?.username.isNullOrBlank()) Text("@${p?.username}", color = NoxMuted, fontSize = 13.sp)
        Text("سطح ${p?.level ?: 1}", color = NoxBlue, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
        if (!p?.bio.isNullOrBlank()) Text(p?.bio.orEmpty(), color = NoxMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
    Gap()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatPill(R.drawable.ic_trophy, fmt(p?.trophies ?: 0), Modifier.weight(1f), NoxGold)
        StatPill(R.drawable.ic_check_circle, fmt(p?.wins ?: 0), Modifier.weight(1f), NoxGreen)
        StatPill(R.drawable.ic_gamepad, fmt(p?.matches ?: 0), Modifier.weight(1f), NoxBlue)
    }
    Gap()
    NeonButton("شخصی‌سازی پروفایل و فروشگاه", Modifier.fillMaxWidth().padding(bottom = 10.dp)) { go("STORE") }
    MenuRow(R.drawable.ic_user, "ویرایش نام، بیو و عکس", "هر تغییر هزینهٔ سکه دارد") { go("EDIT_PROFILE") }
    MenuRow(R.drawable.ic_coins, "کیف پول") { go("WALLET") }
    MenuRow(R.drawable.ic_users, "دوستان") { go("FRIENDS") }
    MenuRow(R.drawable.ic_trophy, "رتبه‌بندی") { go("RANKING") }
    MenuRow(R.drawable.ic_bell, "اعلان‌ها") { go("NOTIFS") }
    MenuRow(R.drawable.ic_settings, "تنظیمات") { go("SETTINGS_MENU") }
}

@Composable private fun EditProfilePage(p: Profile?, auth: AuthViewModel, back: () -> Unit) {
    var name by remember(p?.displayName) { mutableStateOf(p?.displayName.orEmpty()) }
    var bio by remember(p?.bio) { mutableStateOf(p?.bio.orEmpty()) }
    var avatarUrl by remember(p?.avatarUrl) { mutableStateOf(p?.avatarUrl.orEmpty()) }
    val cost = (if (name.trim() != p?.displayName.orEmpty()) 250 else 0) + (if (bio.trim() != p?.bio.orEmpty()) 100 else 0) + (if (avatarUrl.trim() != p?.avatarUrl.orEmpty()) 200 else 0)
    PageHeader("ویرایش پروفایل", back)
    GlowCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(name.ifBlank { "?" }, 64.dp, avatarUrl)
            Spacer(Modifier.width(12.dp))
            Column { Text("عکس پروفایل", color = Color.White, fontWeight = FontWeight.Bold); Text("فعلاً از آواتار رنگی با حرف اول نام استفاده می‌شود.", color = NoxMuted, fontSize = 12.sp) }
        }
        OutlinedTextField(name, { name = it }, label = { Text("نام نمایشی") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 14.dp))
        OutlinedTextField(avatarUrl, { avatarUrl = it }, label = { Text("آدرس تصویر پروفایل") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        OutlinedTextField(bio, { bio = it }, label = { Text("بیو") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        Text("هزینهٔ تغییر نام: ۲۵۰ سکه • بیو: ۱۰۰ سکه • عکس: ۲۰۰ سکه", color = NoxGold, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
        NeonButton(if (cost == 0) "ذخیرهٔ تغییرات" else "پرداخت ${fmt(cost)} سکه و ذخیره", Modifier.fillMaxWidth().padding(top = 8.dp), enabled = name.trim().isNotBlank() && (p?.coins ?: 0) >= cost) { auth.updateProfile(name.trim(), bio.trim(), avatarUrl.trim()); back() }
    }
}

@Composable private fun ChatPage(ms: MainState, openConversation: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    PageHeader("پیام‌ها")
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF21133A), Color(0xFF151027))))
            .border(1.dp, NoxPurple.copy(alpha = 0.35f), RoundedCornerShape(18.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(NoxPurple.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            NIcon(R.drawable.ic_nox_chat, tint = NoxPurple)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("اتاق گفتگوی NØX", color = Color.White, fontWeight = FontWeight.Bold)
            Text("گفتگو با دوستان و پیام‌های ناتس", color = NoxMuted, fontSize = 12.sp)
        }
        Pill("${ms.conversations.size}", NoxBlue)
    }
    OutlinedTextField(
        value = query, onValueChange = { query = it }, singleLine = true,
        label = { Text("جست‌وجوی گفتگو") }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp),
    )
    val visibleConversations = ms.conversations.filter {
        query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) || it.username.contains(query.trim().removePrefix("@"), ignoreCase = true)
    }
    if (visibleConversations.isEmpty() && !ms.loading) GlowCard(Modifier.fillMaxWidth().padding(top = 4.dp), align = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp).clip(CircleShape).background(NoxPurple.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            NIcon(R.drawable.ic_nox_chat, tint = NoxPurple, size = 30.dp)
        }
        Text(if (query.isBlank()) "هنوز گفتگویی نداری" else "گفتگویی پیدا نشد", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Text(if (query.isBlank()) "از پروفایل یک دوست گفتگو را شروع کن؛ پیام‌های ناتس هم اینجا می‌آیند." else "نام یا شناسهٔ کاربر را بررسی کن.", color = NoxMuted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
    }
    visibleConversations.forEach { c ->
        GlowCard(Modifier.fillMaxWidth().padding(bottom = 9.dp), onClick = { openConversation(c.id) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box {
                    Avatar(c.name, 50.dp)
                    Box(Modifier.size(12.dp).align(Alignment.BottomEnd).clip(CircleShape).background(NoxGreen).border(2.dp, NoxCard, CircleShape))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(c.name, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                        Text("سطح ${c.level}", color = NoxBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("@${c.username}", color = NoxPurple, fontSize = 11.sp, modifier = Modifier.padding(top = 1.dp))
                    Text(c.preview, color = NoxMuted, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
                }
                Spacer(Modifier.width(8.dp))
                NIcon(R.drawable.ic_nox_chat, tint = NoxPurple, size = 19.dp)
            }
        }
    }
}

private fun storeTypeLabel(type: String) = when (type) {
    "PROFILE_FRAME" -> "قاب پروفایل"
    "AVATAR_DECORATION" -> "تزئین آواتار"
    "TITLE" -> "عنوان"
    "BADGE" -> "نشان"
    "THEME" -> "تم پروفایل"
    else -> "آیتم"
}

@Composable private fun StorePage(ms: MainState, main: MainViewModel, back: () -> Unit) {
    PageHeader("شخصی‌سازی و فروشگاه", back)
    GlowCard(Modifier.fillMaxWidth(), align = Alignment.CenterHorizontally) {
        Text("موجودی سکه", color = NoxMuted)
        Coins(ms.myProfile?.coins ?: 0, NoxGold)
        Text("سکه‌ها برای تغییر مشخصات و خرید آیتم‌های ظاهری استفاده می‌شوند.", color = NoxMuted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
    Gap()
    GlowCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) { NIcon(R.drawable.ic_coins, tint = NoxGold); Spacer(Modifier.width(8.dp)); Text("خرید سکه با پول واقعی", color = Color.White, fontWeight = FontWeight.Bold) }
        Text("اتصال پرداخت هنوز پیکربندی نشده؛ خرید واقعی پس از اتصال درگاه فروشگاه فعال می‌شود.", color = NoxMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
    Gap()
    Text("آیتم‌های پروفایل", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
    if (ms.storeItems.isEmpty() && !ms.loading) Text("فعلاً آیتمی در فروشگاه نیست.", color = NoxMuted)
    ms.storeItems.forEach { item ->
        val owned = ms.inventory.any { it.itemId == item.id }
        val equippedId = when (item.type) {
            "PROFILE_FRAME" -> ms.myProfile?.equippedFrameId
            "TITLE" -> ms.myProfile?.equippedTitleId
            "BADGE" -> ms.myProfile?.equippedBadgeId
            "THEME" -> ms.myProfile?.equippedThemeId
            else -> null
        }
        val canEquip = item.type in setOf("PROFILE_FRAME", "TITLE", "BADGE", "THEME")
        val equipped = equippedId == item.id
        GlowCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { NIcon(if (item.type == "PROFILE_FRAME") R.drawable.ic_user else R.drawable.ic_star, tint = NoxPurple, size = 28.dp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(item.name, color = Color.White, fontWeight = FontWeight.Bold); Text(storeTypeLabel(item.type) + " • " + item.description, color = NoxMuted, fontSize = 12.sp) }; Pill(item.rarity, NoxGold) }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Coins(item.price, NoxGold)
                Spacer(Modifier.weight(1f))
                if (owned && canEquip) NeonButton(if (equipped) "برداشتن" else "استفاده", enabled = true) { main.equipItem(item.type, if (equipped) null else item.sku) }
                else if (!owned) NeonButton("خرید", enabled = (ms.myProfile?.coins ?: 0) >= item.price) { main.buyItem(item.sku) }
                else Pill("در مالکیت شما", NoxGreen)
            }
        }
    }
}

@Composable private fun ChatThreadPage(ms: MainState, id: String, main: MainViewModel, back: () -> Unit) {
    var draft by rememberSaveable(id) { mutableStateOf("") }
    val conversation = ms.conversations.firstOrNull { it.id == id }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("‹", color = NoxPurple, fontSize = 30.sp, modifier = Modifier.clickable(onClick = back).padding(horizontal = 10.dp))
        Avatar(conversation?.name ?: "N", 42.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(conversation?.name ?: "گفتگو", color = Color.White, fontWeight = FontWeight.Bold)
            Text(conversation?.let { "@${it.username} • سطح ${it.level}" } ?: "گفتگوی خصوصی", color = NoxMuted, fontSize = 11.sp)
        }
        NIcon(R.drawable.ic_nox_chat, tint = NoxPurple)
    }
    if (ms.chatMessages.isEmpty() && !ms.loading) GlowCard(Modifier.fillMaxWidth(), align = Alignment.CenterHorizontally) {
        NIcon(R.drawable.ic_nox_chat, tint = NoxPurple, size = 34.dp)
        Text("شروع یک گفتگوی تازه", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Text("پیامت را بنویس و گفتگو را شروع کن.", color = NoxMuted, fontSize = 12.sp)
    }
    ms.chatMessages.forEach { m ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
            Column(Modifier.fillMaxWidth(0.84f), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
                Box(
                    Modifier.padding(vertical = 3.dp).clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (m.mine) 18.dp else 5.dp, bottomEnd = if (m.mine) 5.dp else 18.dp))
                        .background(if (m.mine) Brush.linearGradient(listOf(Color(0xFF6739A3), Color(0xFF3A245F))) else Brush.linearGradient(listOf(Color(0xFF201832), Color(0xFF171124))))
                        .border(1.dp, (if (m.mine) NoxPurple else NoxBlue).copy(alpha = 0.25f), RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = if (m.mine) 18.dp else 5.dp, bottomEnd = if (m.mine) 5.dp else 18.dp))
                        .padding(horizontal = 13.dp, vertical = 10.dp),
                ) { Text(m.body, color = Color.White) }
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF120D20)).border(1.dp, NoxPurple.copy(alpha = 0.3f), RoundedCornerShape(20.dp)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(draft, { draft = it.take(1000) }, label = { Text("پیام خود را بنویس…") }, modifier = Modifier.weight(1f), maxLines = 4)
        TextButton(onClick = { if (draft.isNotBlank()) { main.sendMessage(id, draft.trim()); draft = "" } }, enabled = draft.isNotBlank()) {
            Text("ارسال", color = if (draft.isNotBlank()) NoxPurple else NoxMuted, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun UserProfilePage(p: PublicProfile?, main: MainViewModel, back: () -> Unit, startChat: (String) -> Unit) {
    PageHeader("پروفایل بازیکن", back)
    if (p == null) return
    GlowCard(Modifier.fillMaxWidth(), align = Alignment.CenterHorizontally, accentColor = if (p.themeName != null) Color(0xFF537DFF) else null) {
        Avatar(p.name, 88.dp, p.avatarUrl, if (p.hasFrame) NoxGold else null); Text(p.name, style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)); Text("@${p.username}  •  سطح ${p.level}", color = NoxBlue, fontWeight = FontWeight.Bold)
        p.titleName?.let { Pill(it, NoxGold, Modifier.padding(top = 6.dp)) }
        p.badgeName?.let { Pill(it, NoxPurple, Modifier.padding(top = 6.dp)) }
        if (p.bio.isNotBlank()) Text(p.bio, color = NoxMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
    Gap(); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatPill(R.drawable.ic_trophy, fmt(p.trophies), Modifier.weight(1f), NoxGold); StatPill(R.drawable.ic_check_circle, fmt(p.wins), Modifier.weight(1f), NoxGreen); StatPill(R.drawable.ic_gamepad, fmt(p.matches), Modifier.weight(1f), NoxBlue) }
    Gap(); Text("عملکرد بازی‌ها", color = Color.White, fontWeight = FontWeight.Bold)
    if (p.gameStats.isEmpty()) Text("هنوز آمار بازی‌ای برای نمایش ثبت نشده است.", color = NoxMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    p.gameStats.forEach { game -> GlowCard(Modifier.fillMaxWidth().padding(top = 8.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { NIcon(R.drawable.ic_gamepad, tint = NoxPurple); Spacer(Modifier.width(8.dp)); Column(Modifier.weight(1f)) { Text(game.gameName, color = Color.White, fontWeight = FontWeight.Bold); Text("${game.matches} بازی  •  ${game.wins} برد", color = NoxMuted, fontSize = 12.sp) }; Pill("${game.wins} برد", NoxGold) } } }
    if (p.canRequest) NeonButton("ارسال درخواست دوستی", Modifier.fillMaxWidth().padding(top = 16.dp)) { main.requestFriend(p.username) }
    if (p.relation == "FRIENDS") NeonButton("شروع گفتگو", Modifier.fillMaxWidth().padding(top = 8.dp)) { startChat(p.username) }
    NeonButton("ارسال هدیهٔ ۱۰۰ سکه‌ای", Modifier.fillMaxWidth().padding(top = 8.dp)) { main.sendGift(p.username, 100) }
}

@Composable private fun MenuRow(icon: Int, label: String, hint: String = "", onClick: () -> Unit) {
    GlowCard(Modifier.fillMaxWidth().padding(bottom = 8.dp), onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NIcon(icon, tint = NoxPurple, size = 22.dp); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(label, color = Color.White, fontWeight = FontWeight.Bold); if (hint.isNotEmpty()) Text(hint, color = NoxMuted, fontSize = 12.sp) }
            NIcon(R.drawable.ic_chevron_left, tint = NoxMuted, size = 20.dp)
        }
    }
}

private fun kindLabel(kind: String) = when (kind) {
    "EARN" -> "درآمد"; "PURCHASE_COINS" -> "خرید سکه"; "SPEND" -> "خرج"; "PROMO" -> "هدیه"; "REFUND" -> "بازگشت وجه"; else -> kind
}

@Composable private fun WalletPage(ms: MainState, main: MainViewModel, back: () -> Unit) {
    PageHeader("کیف پول", back)
    GlowCard(Modifier.fillMaxWidth(), align = Alignment.CenterHorizontally) {
        Text("موجودی شما", color = NoxMuted)
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            NIcon(R.drawable.ic_coins, tint = NoxGold, size = 34.dp)
            Spacer(Modifier.width(8.dp))
            Text(fmt(ms.wallet?.balance ?: 0), fontSize = 34.sp, fontWeight = FontWeight.Black, color = NoxGold)
        }
        NeonButton("افزایش موجودی", Modifier.fillMaxWidth()) { main.buyCoins() }
        ms.wallet?.let { Text("کل درآمد: ${fmt(it.earned)}   |   کل خرج: ${fmt(it.spent)}", color = NoxMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
    }
    Gap()
    Text("تراکنش‌ها", fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(bottom = 8.dp))
    if (ms.txs.isEmpty()) Text("هنوز تراکنشی ثبت نشده.", color = NoxMuted)
    ms.txs.forEach { t ->
        GlowCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(kindLabel(t.kind), color = Color.White, fontWeight = FontWeight.Bold); Text(t.date, color = NoxMuted, fontSize = 12.sp) }
                Text((if (t.amount > 0) "+" else "") + fmt(t.amount), color = if (t.amount >= 0) NoxGreen else NoxPink, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun RankingPage(ms: MainState, back: () -> Unit, changeTab: (String) -> Unit, openProfile: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    PageHeader("رتبه‌بندی", back)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TabPill("ثروتمندان", tab == 0, Modifier.weight(1f)) { tab = 0; changeTab("wealth") }
        TabPill("برتر هفته", tab == 1, Modifier.weight(1f)) { tab = 1; changeTab("weekly") }
        TabPill("فصل", tab == 2, Modifier.weight(1f)) { tab = 2; changeTab("season") }
    }
    Gap(12)
    Text(if (tab == 0) "برترین بازیکنان بر اساس سکه" else if (tab == 1) "برترین‌های این هفته" else "برترین‌های فصل جاری", color = NoxMuted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
    ms.rankMe?.let { me ->
        GlowCard(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (me.rank != null) "رتبهٔ شما: #${me.rank}" else "پروفایل خصوصی است و در فهرست نمی‌آید", color = NoxGold, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Coins(me.wealth, Color.White)
            }
        }
    }
    if (ms.rank.isEmpty() && !ms.loading) Text("فهرستی برای نمایش نیست.", color = NoxMuted)
    ms.rank.forEach { r ->
        GlowCard(Modifier.fillMaxWidth().padding(bottom = 8.dp), onClick = { openProfile(r.username) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(36.dp), contentAlignment = Alignment.CenterStart) {
                    if (r.rank <= 3) NIcon(R.drawable.ic_trophy, tint = listOf(NoxGold, Color(0xFFC9CED8), Color(0xFFCD7F32))[r.rank - 1], size = 24.dp)
                    else Text(r.rank.toString(), fontSize = 16.sp, color = NoxMuted, fontWeight = FontWeight.Bold)
                }
                Avatar(r.name, 38.dp); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) { Text(r.name, color = Color.White, fontWeight = FontWeight.Bold); Text("سطح ${r.level}", color = NoxMuted, fontSize = 12.sp) }
                if (tab == 0) Coins(r.wealth, NoxGold) else Pill("${if (tab == 1) "امتیاز هفته" else "امتیاز فصل"} ${fmt(r.wealth)}", NoxGold)
            }
        }
    }
}

@Composable private fun NotifsPage(ms: MainState, main: MainViewModel, back: () -> Unit) {
    PageHeader("اعلان‌ها", back)
    if (ms.unread > 0) NeonButton("خواندن همه (${ms.unread})", Modifier.fillMaxWidth().padding(bottom = 12.dp)) { main.readAll() }
    if (ms.notifs.isEmpty() && !ms.loading) Text("اعلانی نداری.", color = NoxMuted)
    ms.notifs.forEach { n ->
        GlowCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!n.read) { Box(Modifier.size(8.dp).clip(CircleShape).background(NoxPink)); Spacer(Modifier.width(8.dp)) }
                Text(n.title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(n.date, color = NoxMuted, fontSize = 11.sp)
            }
            if (n.body.isNotBlank()) Text(n.body, color = NoxMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable private fun SettingsMenuPage(auth: AuthViewModel, back: () -> Unit) {
    PageHeader("تنظیمات", back)
    MenuRow(R.drawable.ic_user, "حساب کاربری", "شناسه، اتصال روش ورود، کد بازیابی") { auth.navigate(Screen.ACCOUNT) }
    MenuRow(R.drawable.ic_link, "آدرس سرور", "تغییر آدرس بک‌اند") { auth.navigate(Screen.SETTINGS) }
    Gap(8)
    TextButton(onClick = auth::logout, modifier = Modifier.fillMaxWidth()) { Text("خروج از حساب", color = NoxPink) }
}
