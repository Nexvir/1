package ir.nox.app

object InputValidation {
    fun otp(value: String) = value.matches(Regex("\\d{6}"))
    fun email(value: String) = value.trim().matches(Regex("[^@\\s]+@[^@\\s]+\\.[^@\\s]+"))
    fun phone(value: String) = value.trim().matches(Regex("(\\+98|0098|98|0)?9\\d{9}"))
    fun recovery(account: String, code: String) = account.trim().length >= 3 && code.trim().length >= 10
}
