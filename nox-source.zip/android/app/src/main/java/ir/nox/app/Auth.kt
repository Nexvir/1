package ir.nox.app

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Profile(val displayName: String, val level: Int, val xp: Int, val trophies: Int, val coins: Int, val matches: Int, val wins: Int, val username: String = "", val bio: String = "", val xpInto: Int = 0, val xpNext: Int = 0, val maxLevel: Boolean = false, val avatarUrl: String = "", val equippedFrameId: String? = null, val equippedTitleId: String? = null, val equippedBadgeId: String? = null, val equippedThemeId: String? = null, val equippedFrameName: String? = null, val equippedTitleName: String? = null, val equippedBadgeName: String? = null, val equippedThemeName: String? = null)
data class WalletSummary(val balance: Int, val earned: Int, val spent: Int)
data class Tx(val id: String, val amount: Int, val kind: String, val date: String)
data class RankItem(val rank: Int, val name: String, val username: String, val level: Int, val wealth: Int)
data class RankMe(val rank: Int?, val wealth: Int)
data class Friend(val id: String, val name: String, val username: String, val level: Int)
data class FriendReq(val id: String, val name: String, val username: String, val level: Int)
data class PublicProfile(val id: String, val name: String, val username: String, val level: Int, val bio: String, val trophies: Int, val matches: Int, val wins: Int, val relation: String, val canRequest: Boolean, val avatarUrl: String = "", val gameStats: List<GameAchievement> = emptyList(), val hasFrame: Boolean = false, val titleName: String? = null, val badgeName: String? = null, val themeName: String? = null)
data class GameAchievement(val gameName: String, val matches: Int, val wins: Int)
data class StoreItem(val id: String, val sku: String, val type: String, val name: String, val description: String, val price: Int, val rarity: String, val stackable: Boolean)
data class InventoryEntry(val itemId: String, val sku: String, val type: String, val quantity: Int)
data class Conversation(val id: String, val name: String, val username: String, val level: Int, val preview: String)
data class ChatMessage(val id: String, val body: String, val mine: Boolean)
data class Notif(val id: String, val title: String, val body: String, val date: String, val read: Boolean)
private fun JSONArray.objs(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
data class Tokens(val accessToken: String, val refreshToken: String)
data class Account(val code: String, val guest: Boolean, val username: String = "", val linked: List<String> = emptyList(), val guestExpiry: String? = null)
data class AuthMethods(val guest: Boolean = true, val email: Boolean = false, val phone: Boolean = false, val google: Boolean = false, val captchaRequired: Boolean = true)
data class Captcha(val id: String, val prompt: String, val options: List<CaptchaOption>)
data class CaptchaOption(val id: String, val imageUrl: String)
data class ApiFailure(val code: String, override val message: String, val retryAfter: Int? = null) : Exception(message)

/** Encrypted at rest; no recovery code or OTP is ever persisted. */
class SessionStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(context, "nox.session",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun baseUrl() = prefs.getString("base_url", BuildConfig.DEFAULT_API_URL)!!.trimEnd('/')
    fun setBaseUrl(value: String) = prefs.edit().putString("base_url", value.trim().trimEnd('/')).apply()
    fun tokens() = prefs.getString("access", null)?.let { a -> prefs.getString("refresh", null)?.let { Tokens(a, it) } }
    fun save(tokens: Tokens) = prefs.edit().putString("access", tokens.accessToken).putString("refresh", tokens.refreshToken).apply()
    fun clear() = prefs.edit().remove("access").remove("refresh").apply()
}

class NoxApi(private val store: SessionStore) {
    private suspend fun call(path: String, method: String = "GET", body: JSONObject? = null, auth: Boolean = false): JSONObject = withContext(Dispatchers.IO) {
        fun request(token: String?): Pair<Int, String> {
            val connection = (URL(store.baseUrl() + path).openConnection() as HttpURLConnection).apply {
                requestMethod = method; connectTimeout = 12_000; readTimeout = 15_000
                setRequestProperty("Accept", "application/json")
                if (token != null) setRequestProperty("Authorization", "Bearer $token")
                // Fastify rejects POST requests with the platform's default form content type.
                // Even body-less API actions (such as creating a CAPTCHA challenge) are JSON.
                if (method != "GET") {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    outputStream.use { it.write((body ?: JSONObject()).toString().toByteArray()) }
                }
            }
            val status = connection.responseCode
            val text = (if (status in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            return status to text
        }
        try {
            var response = request(if (auth) store.tokens()?.accessToken else null)
            if (auth && response.first == 401 && refresh()) response = request(store.tokens()?.accessToken)
            val json = response.second.takeIf { it.isNotBlank() }?.let(::JSONObject) ?: JSONObject()
            if (response.first !in 200..299) {
                val error = json.optJSONObject("error")
                val message = error?.optString("messageFa").takeUnless { it.isNullOrBlank() } ?: error?.optString("message") ?: "خطای سرور"
                throw ApiFailure(error?.optString("code", "HTTP_${response.first}") ?: "HTTP_${response.first}", message, error?.optJSONObject("details")?.optInt("retryAfterSeconds"))
            }
            json
        } catch (e: ApiFailure) { throw e } catch (e: IOException) { throw ApiFailure("NETWORK", "اتصال برقرار نشد؛ اینترنت و آدرس سرور را بررسی کن.") }
    }
    private fun refresh(): Boolean = try {
        val refresh = store.tokens()?.refreshToken ?: return false
        val c = (URL(store.baseUrl() + "/v1/auth/refresh").openConnection() as HttpURLConnection).apply { requestMethod = "POST"; doOutput = true; setRequestProperty("Content-Type", "application/json"); outputStream.use { it.write(JSONObject().put("refreshToken", refresh).toString().toByteArray()) } }
        val json = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("tokens")
        store.save(Tokens(json.getString("accessToken"), json.getString("refreshToken"))); true
    } catch (_: Exception) { store.clear(); false }
    suspend fun methods(): AuthMethods { val j = call("/v1/auth/methods"); return AuthMethods(j.getJSONObject("guest").getBoolean("available"), j.getJSONObject("email").getBoolean("available"), j.getJSONObject("phone").getBoolean("available"), j.getJSONObject("google").getBoolean("available"), j.getJSONObject("antibot").getBoolean("required")) }
    suspend fun captcha(): Captcha { val j = call("/v1/captcha/challenges", "POST"); val o = j.getJSONArray("options"); return Captcha(j.getString("id"), j.getString("prompt"), (0 until o.length()).map { i -> o.getJSONObject(i).let { CaptchaOption(it.getString("id"), absoluteImage(it.getString("imageUrl"))) } }) }
    private fun absoluteImage(path: String) = if (path.startsWith("http")) path else store.baseUrl() + path
    suspend fun answerCaptcha(id: String, option: String) = call("/v1/captcha/challenges/$id/answer", "POST", JSONObject().put("optionId", option)).getString("pass")
    suspend fun guest(pass: String?) = session(call("/v1/auth/guest", "POST", JSONObject().apply { if (pass != null) put("captchaPass", pass) }), true)
    suspend fun guestWithCode(pass: String?): Pair<Account, String> { val j = call("/v1/auth/guest", "POST", JSONObject().apply { if (pass != null) put("captchaPass", pass) }); return session(j, true) to j.getString("recoveryCode") }
    suspend fun recover(code: String, recovery: String) = session(call("/v1/auth/recover", "POST", JSONObject().put("accountCode", code).put("recoveryCode", recovery)), false)
    suspend fun requestOtp(channel: String, destination: String, pass: String?) { call("/v1/auth/otp/request", "POST", JSONObject().put("channel", channel).put("destination", destination).apply { if (pass != null) put("captchaPass", pass) }) }
    suspend fun verifyOtp(channel: String, destination: String, otp: String, pass: String?) = session(call("/v1/auth/otp/verify", "POST", JSONObject().put("channel", channel).put("destination", destination).put("code", otp).apply { if (pass != null) put("captchaPass", pass) }), false)
    suspend fun google(idToken: String, pass: String?) = session(call("/v1/auth/google", "POST", JSONObject().put("idToken", idToken).apply { if (pass != null) put("captchaPass", pass) }), false)
    suspend fun account(): Account { val j = call("/v1/auth/account", auth = true); return Account(j.getString("accountCode"), j.getBoolean("isGuest"), j.optString("username"), (0 until j.getJSONArray("linked").length()).map { j.getJSONArray("linked").getJSONObject(it).getString("provider") }, j.optJSONObject("guestExpiry")?.optString("expiresAt")) }
    suspend fun me(): Profile { val j = call("/v1/users/me", auth = true); val p = j.getJSONObject("profile"); val pr = p.getJSONObject("progress"); val st = p.getJSONObject("stats"); val equipped = p.optJSONObject("equipped"); return Profile(p.getString("displayName"), pr.optInt("level", 1), pr.optInt("xp", 0), p.optInt("trophies", 0), j.getJSONObject("wallet").optInt("balance", 0), st.optInt("totalMatches", 0), st.optInt("wins", 0), j.optString("username"), p.optString("bio", "").takeUnless { p.isNull("bio") }.orEmpty(), pr.optInt("xpIntoLevel", 0), pr.optInt("xpForNextLevel", 0), pr.optBoolean("isMaxLevel", false), p.optString("avatarUrl", "").takeUnless { p.isNull("avatarUrl") }.orEmpty(), equipped?.optString("frameId")?.takeUnless { it == "null" }, equipped?.optString("titleId")?.takeUnless { it == "null" }, equipped?.optString("badgeId")?.takeUnless { it == "null" }, equipped?.optString("themeId")?.takeUnless { it == "null" }, equipped?.optString("frameName")?.takeUnless { it == "null" }, equipped?.optString("titleName")?.takeUnless { it == "null" }, equipped?.optString("badgeName")?.takeUnless { it == "null" }, equipped?.optString("themeName")?.takeUnless { it == "null" }) }
    suspend fun updateProfile(name: String, bio: String, avatarUrl: String): Int { val j = call("/v1/users/me/profile", "PATCH", JSONObject().put("displayName", name).put("bio", bio.ifBlank { JSONObject.NULL }).put("avatarUrl", avatarUrl.ifBlank { JSONObject.NULL }), true); return j.optJSONObject("customization")?.optInt("charged", 0) ?: 0 }
    suspend fun publicProfile(username: String): PublicProfile { val j = call("/v1/users/$username", auth = true); val u = j.getJSONObject("user"); val p = j.optJSONObject("profile"); val st = p?.optJSONObject("stats"); val equipped = p?.optJSONObject("equipped"); return PublicProfile(u.getString("id"), u.getString("displayName"), u.getString("username"), u.optInt("level", 1), p?.optString("bio", "") ?: "", p?.optInt("trophies", 0) ?: 0, st?.optInt("totalMatches", 0) ?: 0, st?.optInt("wins", 0) ?: 0, j.getJSONObject("relation").optString("state"), j.optBoolean("canSendFriendRequest"), u.optString("avatarUrl", "").takeUnless { u.isNull("avatarUrl") }.orEmpty(), p?.optJSONArray("gameStats")?.objs()?.map { GameAchievement(it.optString("gameName"), it.optInt("matches"), it.optInt("wins")) } ?: emptyList(), equipped?.isNull("frameId") == false, equipped?.optString("titleName")?.takeUnless { it == "null" }, equipped?.optString("badgeName")?.takeUnless { it == "null" }, equipped?.optString("themeName")?.takeUnless { it == "null" }) }
    suspend fun wallet(): WalletSummary { val j = call("/v1/wallet", auth = true); return WalletSummary(j.optInt("balance"), j.optInt("earnedTotal"), j.optInt("spentTotal")) }
    suspend fun transactions(): List<Tx> = call("/v1/wallet/transactions?limit=30", auth = true).getJSONArray("items").objs().map { Tx(it.getString("id"), it.getInt("amount"), it.optString("kind"), it.optString("createdAt").take(10)) }
    suspend fun leaderboard(kind: String): Pair<List<RankItem>, RankMe?> { val j = call("/v1/leaderboards/$kind?limit=30", auth = true); val items = j.getJSONArray("items").objs().map { RankItem(it.getInt("rank"), it.getString("displayName"), it.getString("username"), it.optInt("level", 1), it.optInt("score", it.optInt("wealth", 0))) }; val me = j.optJSONObject("me")?.let { RankMe(if (it.isNull("rank")) null else it.getInt("rank"), it.optInt("score", it.optInt("wealth", 0))) }; return items to me }
    suspend fun friends(): List<Friend> = call("/v1/friends?limit=50", auth = true).getJSONArray("items").objs().map { Friend(it.getString("id"), it.getString("displayName"), it.getString("username"), it.optInt("level", 1)) }
    suspend fun friendRequests(): List<FriendReq> = call("/v1/friends/requests?direction=incoming", auth = true).getJSONArray("items").objs().map { val u = it.getJSONObject("user"); FriendReq(it.getString("id"), u.getString("displayName"), u.getString("username"), u.optInt("level", 1)) }
    suspend fun sendFriendRequest(username: String) { call("/v1/friends/requests", "POST", JSONObject().put("username", username), true) }
    suspend fun respondFriendRequest(id: String, accept: Boolean) { call("/v1/friends/requests/$id/" + (if (accept) "accept" else "reject"), "POST", auth = true) }
    suspend fun conversations(): List<Conversation> = call("/v1/chat/conversations", auth = true).getJSONArray("items").objs().map { val o = it.getJSONObject("other"); Conversation(it.getString("id"), o.getString("displayName"), o.getString("username"), o.optInt("level", 1), it.optJSONObject("preview")?.optString("body", "شروع گفتگو") ?: "شروع گفتگو") }
    suspend fun startConversation(username: String): String = call("/v1/chat/conversations", "POST", JSONObject().put("username", username), true).getString("id")
    suspend fun messages(id: String): List<ChatMessage> = call("/v1/chat/$id/messages", auth = true).getJSONArray("items").objs().map { ChatMessage(it.getString("id"), it.getString("body"), it.optBoolean("mine")) }
    suspend fun sendMessage(id: String, body: String) { call("/v1/chat/$id/messages", "POST", JSONObject().put("body", body).put("clientMsgId", java.util.UUID.randomUUID().toString()), true) }
    suspend fun notifications(): List<Notif> = call("/v1/notifications?limit=30", auth = true).getJSONArray("items").objs().map { Notif(it.getString("id"), it.optString("title"), it.optString("body"), it.optString("createdAt").take(10), !it.isNull("readAt")) }
    suspend fun unreadCount(): Int = call("/v1/notifications/unread-count", auth = true).optInt("count")
    suspend fun readAllNotifications() { call("/v1/notifications/read-all", "POST", auth = true) }
    suspend fun buyCoins() { call("/v1/wallet/coin-purchases", "POST", auth = true) }
    suspend fun sendGift(username: String, amount: Int) { call("/v1/wallet/gifts", "POST", JSONObject().put("username", username).put("amount", amount), true) }
    suspend fun storeItems(): List<StoreItem> = call("/v1/store", auth = true).getJSONArray("items").objs().map { StoreItem(it.getString("id"), it.getString("sku"), it.getString("type"), it.getString("name"), it.optString("description"), it.optInt("price"), it.optString("rarity"), it.optBoolean("stackable")) }
    suspend fun inventory(): List<InventoryEntry> = call("/v1/store/inventory", auth = true).getJSONArray("items").objs().map { InventoryEntry(it.getString("itemId"), it.getString("sku"), it.getString("type"), it.optInt("quantity", 1)) }
    suspend fun buyStoreItem(sku: String, key: String) { call("/v1/store/purchase", "POST", JSONObject().put("sku", sku).put("idempotencyKey", key), true) }
    suspend fun equipStoreItem(type: String, sku: String?) { call("/v1/store/equip", "POST", JSONObject().put("type", type).put("sku", sku ?: JSONObject.NULL), true) }
    suspend fun rotate() = call("/v1/auth/recovery-code/rotate", "POST", auth = true).getString("recoveryCode")
    suspend fun linkOtpRequest(channel: String, destination: String) { call("/v1/auth/link/otp/request", "POST", JSONObject().put("channel", channel).put("destination", destination), true) }
    suspend fun linkOtpVerify(channel: String, destination: String, code: String) { call("/v1/auth/link/otp/verify", "POST", JSONObject().put("channel", channel).put("destination", destination).put("code", code), true) }
    suspend fun linkGoogle(idToken: String) { call("/v1/auth/link/google", "POST", JSONObject().put("idToken", idToken), true) }
    private fun session(j: JSONObject, guest: Boolean): Account { val t = j.getJSONObject("tokens"); store.save(Tokens(t.getString("accessToken"), t.getString("refreshToken"))); val a = j.getJSONObject("account"); return Account(a.getString("accountCode"), a.optBoolean("isGuest", guest), a.optString("username")) }
}
