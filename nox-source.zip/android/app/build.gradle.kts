plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "ir.nox.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.nox.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        buildConfigField("String", "DEFAULT_API_URL", "\"http://10.0.2.2:3000\"")
        val googleClientId = providers.gradleProperty("NOX_GOOGLE_WEB_CLIENT_ID").orElse("").get().replace("\\", "\\\\").replace("\"", "\\\"")
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"$googleClientId\"")
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

kotlin { jvmToolchain(17) }

dependencies {
    implementation(libs.androidx.core)
    implementation(libs.activity.compose)
    implementation(libs.lifecycle.runtime)
    implementation(libs.lifecycle.viewmodel)
    implementation(libs.navigation.compose)
    implementation(libs.coroutines.android)
    implementation(libs.security.crypto)
    implementation(libs.credential.manager)
    implementation(libs.credential.play.services)
    implementation(libs.googleid)
    implementation(libs.coil.compose)
    implementation(libs.coil.svg)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.tooling.preview)
    implementation(libs.compose.material)
    debugImplementation(libs.compose.tooling)
    testImplementation("junit:junit:4.13.2")
}
