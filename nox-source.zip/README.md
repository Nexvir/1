# NØX — social gaming platform

Android social gaming app (Kotlin / Jetpack Compose, Persian RTL first) with a
Node.js + TypeScript + PostgreSQL backend. The project is built in milestones.
This file only claims what has actually been built and run.

## Status

| Area | Status |
|---|---|
| Backend: auth, profiles, friends, blocks, wallet ledger, wealth leaderboard, notifications | Implemented (milestone 1) |
| Account system: guest + recovery code, phone/e-mail OTP, Google, linking, picture CAPTCHA, 9-month guest cleanup job | Implemented in the API, 130 tests passing in total. SMS/e-mail/Google need external configuration; see `backend/docs/AUTH.md` (no Android UI yet) |
| Database schema (31 tables), constraints, indexes | Implemented, applied to PostgreSQL 16 |
| Clans + clan chat, private chat, WebSocket layer | Not started (milestone 2) |
| XP / trophy ledgers, match lifecycle, game plugin registry | Not started (milestone 3) |
| Weekly league / season periods and snapshots | Not started (milestone 3) |
| Store, inventory, purchases | Not started (milestone 4) |
| Reports / moderation endpoints | Not started (milestone 2) |
| OpenAPI spec | Not started (milestone 4) |
| Android app | Initial authentication milestone implemented in `android/`: Compose/Material 3 Persian UI, picture challenge, guest + recovery, e-mail/phone OTP, Google Credential Manager integration, linking, secure session storage and account status. Android SDK is not installed here, so no APK has been built in this environment. |

## Requirements

- Node.js 20+ (built with 22)
- PostgreSQL 14+ (built with 16)
- For the Android milestone later: JDK 17+, Android Studio / Android SDK

## Backend setup (Windows PowerShell)

```powershell
cd backend
Copy-Item .env.example .env        # then edit DATABASE_URL, JWT_ACCESS_SECRET and SERVER_PEPPER
npm install
npx prisma generate
npx prisma migrate deploy          # applies prisma/migrations
$env:DEMO_SEED_PASSWORD = "choose-a-password"
npm run db:seed                    # optional: 5 clearly flagged demo accounts
npm run dev                        # http://localhost:3000/health
```

Create the database and a separate test database first (psql):

```sql
CREATE ROLE nox LOGIN PASSWORD 'your-password' CREATEDB;
CREATE DATABASE nox OWNER nox;
CREATE DATABASE nox_test OWNER nox;
```

Generate JWT_ACCESS_SECRET / SERVER_PEPPER: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

## Tests

```powershell
cd backend
npm run typecheck
npm test
```

Tests run against a real PostgreSQL database named `*_test` (set `TEST_DATABASE_URL`
to override) and **truncate all tables**; the harness refuses to run against any
database whose name does not end in `_test`. Apply the migration to it first.

## Architecture (milestone 1)

```
backend/
  prisma/schema.prisma        data model (source of truth for the Prisma client)
  prisma/migrations/          SQL migrations (+ constraints Prisma cannot express)
  src/config.ts               validated env configuration
  src/errors.ts               AppError + consistent { error: { code, message } } responses
  src/auth/                   argon2id passwords, JWT access tokens, rotating refresh tokens
  src/modules/<feature>/      service.ts (business rules) + routes.ts (HTTP + validation)
  tests/                      vitest integration tests (real DB)
```

Key rules enforced server-side:

- **Auth**: argon2id; short-lived access JWT; opaque refresh tokens stored only as
  SHA-256 hashes, rotated on use; replay of a rotated token revokes all sessions.
  Authorization reads live DB state, so suspension takes effect immediately.
- **Economy**: every coin change is a `WalletTransaction` ledger row written in the
  same DB transaction as the balance update. Idempotency keys make replays no-ops.
  `UPDATE ... WHERE balance + amount >= 0` plus `CHECK (balance >= 0)` prevent
  negative balances and concurrent double-spends. Amounts are integers.
  Clients have no endpoint that can add coins.
- **Friends**: a partial unique index allows one PENDING request per unordered user
  pair, so duplicate and contradictory (A→B and B→A) requests are impossible even
  under races. Friendships are stored once, ordered, behind a CHECK constraint.
- **Privacy**: profile visibility (public / friends / private), request policy,
  stats visibility. Blocked users cannot see or contact the blocker. Private-profile
  players are excluded from search and leaderboards. Emails are never in public payloads.
- **Wealth leaderboard**: wealth = current coin balance (`WEALTH_DEFINITION`, only
  `balance` implemented). Independent of trophies/XP; never reset by periods.
  Indexed on `Wallet.balance`; paginated (page size ≤ 50).
- **Level curve** is configuration (`LEVEL_BASE_XP`, `LEVEL_GROWTH`, `LEVEL_MAX`),
  computed on the backend; clients only render the returned progress.

## Known limitations

- `prisma/migrations/20261015000000_init/migration.sql` was **written by hand**
  because Prisma's schema-engine could not be downloaded in the authoring
  environment. It was applied successfully to PostgreSQL 16 and the app and tests run
  against it, but it has not been diffed by Prisma. On a machine with network access
  run, and fix any drift it reports:
  `npx prisma migrate diff --from-migrations prisma/migrations --to-schema-datamodel prisma/schema.prisma --shadow-database-url <url> --exit-code`
- The Prisma client uses the Rust-free `engineType = "client"` + `@prisma/adapter-pg`.
  (Needed here because engine binaries were blocked; it also works normally elsewhere.)
- Coin purchases and premium are intentionally unavailable: no payment provider is
  integrated (`POST /v1/wallet/coin-purchases` returns 501).
- Avatars: no upload/selection yet (`avatarUrl` is read-only and null for now).
- Username search is a prefix match; add a trigram index if the user base grows large.
- Rate limits use the in-memory store (single instance). Use a shared store (Redis) when scaling out.

## Next milestones

2. Clans (roles, invitations / join requests, settings), clan chat and private chat
   over WebSocket with server-side authorization, pagination, rate limits, reports.
3. Mini-game registry + match lifecycle, server-authoritative XP/trophy ledgers,
   weekly league and season periods with immutable snapshots and a safe rotation job.
4. Store / inventory / purchases, OpenAPI spec, notifications for live events.
5. Android app (Compose, RTL), starting with auth, home, profile, friends, clans, chat.

## Android authentication client

See [`android/README.md`](android/README.md) for Windows setup, backend/API URL configuration,
debug APK commands, external provider configuration and the manual end-to-end test plan. The
emulator default is `http://10.0.2.2:3000`; release builds require an HTTPS API.

## Guest cleanup job

`npm run job:guest-cleanup -- --dry-run` lists what would be deleted; without the flag it deletes. The server also runs it hourly unless `JOBS_ENABLED=false`.
