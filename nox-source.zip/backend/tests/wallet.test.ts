import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { changeWallet } from '../src/modules/wallet/service';
import { AppError } from '../src/errors';
import { bearer, createTestContext, registerUser, resetDb, type TestContext } from './helpers';

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext();
});
afterAll(async () => ctx.close());
beforeEach(async () => resetDb(ctx.prisma));

/** Ledger must always explain the wallet exactly. */
async function expectConsistent(userId: string) {
  const wallet = await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId } });
  const entries = await ctx.prisma.walletTransaction.findMany({ where: { userId }, orderBy: { createdAt: 'asc' } });
  const sum = entries.reduce((s, e) => s + e.amount, 0);
  expect(wallet.balance).toBe(sum);
  expect(wallet.balance).toBeGreaterThanOrEqual(0);
  expect(wallet.earnedTotal + wallet.purchasedTotal + wallet.promoTotal - wallet.spentTotal).toBe(wallet.balance);
}

describe('wallet ledger', () => {
  it('credits and debits with a ledger row each and separate totals', async () => {
    const u = await registerUser(ctx, 'alice'); // +500 promo
    await changeWallet(ctx.prisma, { userId: u.id, amount: 250, kind: 'EARN', source: 'match_reward', idempotencyKey: 'earn-0001-alice' });
    await changeWallet(ctx.prisma, { userId: u.id, amount: -300, kind: 'SPEND', source: 'store_purchase', idempotencyKey: 'spend-0001-alice' });

    const wallet = await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId: u.id } });
    expect(wallet).toMatchObject({ balance: 450, earnedTotal: 250, promoTotal: 500, spentTotal: 300, purchasedTotal: 0 });
    await expectConsistent(u.id);

    const history = await ctx.app.inject({ method: 'GET', url: '/v1/wallet/transactions?limit=2', headers: bearer(u) });
    expect(history.json().items).toHaveLength(2);
    expect(history.json().nextCursor).toBeTruthy();
    const page2 = await ctx.app.inject({ method: 'GET', url: `/v1/wallet/transactions?limit=2&cursor=${history.json().nextCursor}`, headers: bearer(u) });
    expect(page2.json().items).toHaveLength(1);
    expect(page2.json().nextCursor).toBeNull();
  });

  it('refuses to overspend and records nothing for the failed attempt', async () => {
    const u = await registerUser(ctx, 'alice');
    await expect(
      changeWallet(ctx.prisma, { userId: u.id, amount: -501, kind: 'SPEND', source: 'store_purchase', idempotencyKey: 'spend-too-much' }),
    ).rejects.toMatchObject({ code: 'INSUFFICIENT_FUNDS' });
    expect(await ctx.prisma.walletTransaction.count({ where: { userId: u.id } })).toBe(1);
    await expectConsistent(u.id);
  });

  it('rejects invalid amounts and inconsistent kinds', async () => {
    const u = await registerUser(ctx, 'alice');
    const bad = [
      { amount: 0, kind: 'EARN' as const },
      { amount: 1.5, kind: 'EARN' as const },
      { amount: -5, kind: 'EARN' as const },
      { amount: 5, kind: 'SPEND' as const },
      { amount: Number.NaN, kind: 'EARN' as const },
    ];
    for (const [i, b] of bad.entries()) {
      await expect(
        changeWallet(ctx.prisma, { userId: u.id, ...b, source: 'test', idempotencyKey: `bad-input-${i}-alice` }),
      ).rejects.toBeInstanceOf(AppError);
    }
    await expectConsistent(u.id);
  });

  it('is idempotent: replaying the same key applies the change once', async () => {
    const u = await registerUser(ctx, 'alice');
    const input = { userId: u.id, amount: 100, kind: 'EARN' as const, source: 'daily_mission', idempotencyKey: 'mission-2026-10-15-alice' };
    const first = await changeWallet(ctx.prisma, input);
    const second = await changeWallet(ctx.prisma, input);
    expect(first.replayed).toBe(false);
    expect(second.replayed).toBe(true);
    expect(second.transactionId).toBe(first.transactionId);
    expect((await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId: u.id } })).balance).toBe(600);

    // Same key, different operation = client bug, not a replay.
    await expect(changeWallet(ctx.prisma, { ...input, amount: 999 })).rejects.toMatchObject({ code: 'IDEMPOTENCY_KEY_REUSED' });
    await expectConsistent(u.id);
  });

  it('is idempotent under concurrent replays of the same key', async () => {
    const u = await registerUser(ctx, 'alice');
    const input = { userId: u.id, amount: 40, kind: 'EARN' as const, source: 'daily_mission', idempotencyKey: 'concurrent-replay-alice' };
    const results = await Promise.all(Array.from({ length: 6 }, () => changeWallet(ctx.prisma, input)));
    expect(results.filter((r) => !r.replayed)).toHaveLength(1);
    expect((await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId: u.id } })).balance).toBe(540);
    await expectConsistent(u.id);
  });

  it('never goes negative under concurrent spending (no double-spend race)', async () => {
    const u = await registerUser(ctx, 'alice'); // balance 500
    // 12 parallel attempts to spend 100 each: exactly 5 may succeed.
    const results = await Promise.allSettled(
      Array.from({ length: 12 }, (_, i) =>
        changeWallet(ctx.prisma, { userId: u.id, amount: -100, kind: 'SPEND', source: 'store_purchase', idempotencyKey: `race-spend-${i}-alice` }),
      ),
    );
    const ok = results.filter((r) => r.status === 'fulfilled');
    const failed = results.filter((r) => r.status === 'rejected') as PromiseRejectedResult[];
    expect(ok).toHaveLength(5);
    expect(failed).toHaveLength(7);
    expect(failed.every((f) => (f.reason as AppError).code === 'INSUFFICIENT_FUNDS')).toBe(true);

    const wallet = await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId: u.id } });
    expect(wallet.balance).toBe(0);
    expect(wallet.spentTotal).toBe(500);
    await expectConsistent(u.id);
  });

  it('the database itself rejects a negative balance', async () => {
    const u = await registerUser(ctx, 'alice');
    await expect(ctx.prisma.$executeRawUnsafe(`UPDATE "Wallet" SET "balance" = -1 WHERE "userId" = '${u.id}'`)).rejects.toThrow();
  });

  it('exposes no way for a client to credit coins', async () => {
    const u = await registerUser(ctx, 'alice');
    const purchase = await ctx.app.inject({ method: 'POST', url: '/v1/wallet/coin-purchases', headers: bearer(u), payload: { amount: 1000 } });
    expect(purchase.statusCode).toBe(501);
    expect(purchase.json().error.code).toBe('PAYMENTS_UNAVAILABLE');

    for (const method of ['POST', 'PUT', 'PATCH'] as const) {
      const res = await ctx.app.inject({ method, url: '/v1/wallet', headers: bearer(u), payload: { balance: 999999 } });
      expect(res.statusCode).toBe(404);
    }
    // Profile updates cannot smuggle in economy / progression fields.
    const smuggle = await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(u), payload: { xp: 99999, trophies: 99999 } });
    expect(smuggle.statusCode).toBe(400);
  });
});
