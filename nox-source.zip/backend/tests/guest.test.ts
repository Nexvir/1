import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { normalizeRecoveryCode } from '../src/auth/codes';
import { changeWallet } from '../src/modules/wallet/service';
import { bearer, createGuest, createTestContext, getPass, registerUser, resetDb, type TestContext } from './helpers';

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext();
});
afterAll(async () => ctx.close());
beforeEach(async () => resetDb(ctx.prisma));

const recover = (accountCode: string, recoveryCode: string) =>
  ctx.app.inject({ method: 'POST', url: '/v1/auth/recover', payload: { accountCode, recoveryCode } });

describe('guest account', () => {
  it('creates a unique account with a recovery code and server-side progress', async () => {
    const g = await createGuest(ctx);
    expect(g.accountCode).toMatch(/^NX-[0-9A-Z]{8}$/);
    expect(g.recoveryCode).toMatch(/^([0-9A-Z]{5}-){3}[0-9A-Z]{5}$/);
    expect(g.body.recoveryWarningFa).toContain('جای امن');
    expect(g.body.account.isGuest).toBe(true);

    const row = await ctx.prisma.user.findUniqueOrThrow({ where: { id: g.id }, include: { profile: true, wallet: true } });
    expect(row.isGuest).toBe(true);
    expect(row.email).toBeNull();
    expect(row.passwordHash).toBeNull();
    expect(row.profile?.level).toBe(1);
    expect(row.wallet?.balance).toBe(500); // progress lives on the server from the first second

    // A guest can use the API straight away.
    const me = await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: bearer(g) });
    expect(me.statusCode).toBe(200);
    expect(me.json().email).toBeNull();

    // Two guests never collide.
    const g2 = await createGuest(ctx);
    expect(g2.accountCode).not.toBe(g.accountCode);
    expect(g2.recoveryCode).not.toBe(g.recoveryCode);
  });

  it('never stores the recovery code in plain text (database or logs of events)', async () => {
    const g = await createGuest(ctx);
    const plain = normalizeRecoveryCode(g.recoveryCode)!;
    const row = await ctx.prisma.user.findUniqueOrThrow({ where: { id: g.id } });
    expect(row.recoveryCodeHash).toMatch(/^[0-9a-f]{64}$/);

    const dump = JSON.stringify({
      users: await ctx.prisma.user.findMany(),
      events: await ctx.prisma.securityEvent.findMany(),
      audit: await ctx.prisma.auditLog.findMany(),
      throttle: await ctx.prisma.authThrottle.findMany(),
      captcha: await ctx.prisma.captchaChallenge.findMany(),
    });
    expect(dump).not.toContain(plain);
    expect(dump).not.toContain(g.recoveryCode);
  });

  it('cannot sign in with a password (it has none) and gets the generic error', async () => {
    const g = await createGuest(ctx);
    const username = g.body.account.username as string;
    const res = await ctx.app.inject({ method: 'POST', url: '/v1/auth/login', payload: { identifier: username, password: 'whatever-123' } });
    expect(res.statusCode).toBe(401);
    expect(res.json().error.code).toBe('INVALID_CREDENTIALS');
  });

  it('guest sessions last long (no password to fall back on), normal ones stay short', async () => {
    const g = await createGuest(ctx);
    const u = await registerUser(ctx, 'normal_user');
    const day = 86_400_000;
    const ttl = async (token: string) => {
      const row = await ctx.prisma.refreshToken.findFirstOrThrow({ where: { revokedAt: null, tokenHash: (await import('../src/auth/tokens')).hashToken(token) } });
      return Math.round((row.expiresAt.getTime() - Date.now()) / day);
    };
    expect(await ttl(g.refreshToken)).toBe(270);
    expect(await ttl(u.refreshToken)).toBe(30);
  });
});

describe('account recovery', () => {
  it('restores the SAME account with all progress and opens a new session', async () => {
    const g = await createGuest(ctx);
    const username = g.body.account.username as string;

    // Build up progress: XP / level / trophies, coins, a friend, a clan, an item.
    await ctx.prisma.userProfile.update({ where: { userId: g.id }, data: { xp: 700, level: 4, trophies: 130, wins: 9 } });
    await changeWallet(ctx.prisma, { userId: g.id, amount: 250, kind: 'EARN', source: 'test', idempotencyKey: 'recover-earn-0001' });
    const friend = await registerUser(ctx, 'old_friend');
    const req = await ctx.app.inject({ method: 'POST', url: '/v1/friends/requests', headers: bearer(friend), payload: { username } });
    await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${req.json().id}/accept`, headers: bearer(g) });
    const clan = await ctx.prisma.clan.create({ data: { name: 'Shadow Legion', tag: 'SHADOW' } });
    await ctx.prisma.clanMembership.create({ data: { clanId: clan.id, userId: g.id, role: 'MEMBER' } });
    const item = await ctx.prisma.storeItem.create({ data: { sku: 'frame-neon', type: 'PROFILE_FRAME', name: 'Neon', price: 100 } });
    await ctx.prisma.userInventory.create({ data: { userId: g.id, itemId: item.id } });

    const usersBefore = await ctx.prisma.user.count();
    // "Reinstall": the old device's session is gone; the player only has ID + code.
    const res = await recover(g.accountCode, g.recoveryCode);
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body.account).toMatchObject({ id: g.id, accountCode: g.accountCode, isGuest: true });

    // No new account; everything is still there.
    expect(await ctx.prisma.user.count()).toBe(usersBefore);
    const me = await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: { authorization: `Bearer ${body.tokens.accessToken}` } });
    expect(me.json()).toMatchObject({ id: g.id });
    // The server derives the level from lifetime XP with its configured curve (700 XP = level 5).
    expect(me.json().profile.progress).toMatchObject({ xp: 700, level: 5 });
    expect(me.json().profile.trophies).toBe(130);
    expect(me.json().wallet.balance).toBe(750);
    const friends = await ctx.app.inject({ method: 'GET', url: '/v1/friends', headers: { authorization: `Bearer ${body.tokens.accessToken}` } });
    expect(friends.json().items.map((f: { username: string }) => f.username)).toEqual(['old_friend']);
    expect(await ctx.prisma.clanMembership.count({ where: { userId: g.id, clanId: clan.id } })).toBe(1);
    expect(await ctx.prisma.userInventory.count({ where: { userId: g.id, itemId: item.id } })).toBe(1);

    // Every older session of the account was closed by the recovery; exactly one new one exists.
    const sessions = await ctx.prisma.refreshToken.findMany({ where: { userId: g.id } });
    expect(sessions.filter((s) => s.revokedAt === null)).toHaveLength(1);
    expect(sessions.filter((s) => s.revokedAt !== null)).toHaveLength(1);
  });

  it('the new session survives when the old token is simply not used again', async () => {
    const g = await createGuest(ctx);
    const res = await recover(g.accountCode, g.recoveryCode);
    const refreshed = await ctx.app.inject({ method: 'POST', url: '/v1/auth/refresh', payload: { refreshToken: res.json().tokens.refreshToken } });
    expect(refreshed.statusCode).toBe(200);
  });

  it('the account ID alone is not enough', async () => {
    const g = await createGuest(ctx);
    const noCode = await ctx.app.inject({ method: 'POST', url: '/v1/auth/recover', payload: { accountCode: g.accountCode } });
    expect(noCode.statusCode).toBe(400);
    const wrong = await recover(g.accountCode, 'AAAAA-BBBBB-CCCCC-DDDDD');
    expect(wrong.statusCode).toBe(401);
    expect(wrong.json().error.code).toBe('INVALID_RECOVERY');
    expect(wrong.json().error.messageFa).toContain('درست نیست');
    expect(wrong.body).not.toContain(g.id); // nothing about the account leaks
    // Someone else's code does not work either.
    const other = await createGuest(ctx);
    expect((await recover(g.accountCode, other.recoveryCode)).statusCode).toBe(401);
  });

  it('accepts the code however the player types it', async () => {
    const g = await createGuest(ctx);
    const compact = g.recoveryCode.replace(/-/g, '').toLowerCase();
    expect((await recover(g.accountCode.toLowerCase(), compact)).statusCode).toBe(200);
    expect((await recover(` ${g.accountCode.replace('-', '')} `, ` ${g.recoveryCode} `)).statusCode).toBe(200);
    const bad = await recover('NX-12', 'not-a-valid-code');
    expect(bad.statusCode).toBe(400);
    expect(bad.json().error.code).toBe('INVALID_RECOVERY_FORMAT');
  });

  it('answers identically for accounts that do not exist (no enumeration)', async () => {
    const g = await createGuest(ctx);
    const real = await recover(g.accountCode, 'AAAAA-BBBBB-CCCCC-DDDDD');
    const ghost = await recover('NX-ZZZZZZZZ', 'AAAAA-BBBBB-CCCCC-DDDDD');
    expect(real.statusCode).toBe(ghost.statusCode);
    expect(real.json()).toEqual(ghost.json());
  });

  it('locks temporarily after repeated failures, even for the right code, then escalates', async () => {
    const g = await createGuest(ctx);
    for (let i = 0; i < 5; i++) expect((await recover(g.accountCode, 'AAAAA-BBBBB-CCCCC-DDDDD')).statusCode).toBe(401);

    const locked = await recover(g.accountCode, g.recoveryCode); // correct code, but locked
    expect(locked.statusCode).toBe(429);
    expect(locked.json().error.code).toBe('RECOVERY_LOCKED');
    expect(locked.json().error.messageFa).toContain('صبر');
    expect(locked.headers['retry-after']).toBeDefined();
    expect(locked.json().error.details.retryAfterSeconds).toBeGreaterThan(14 * 60);
    expect(locked.json().error.details.retryAfterSeconds).toBeLessThanOrEqual(15 * 60);

    // Lock expires -> the right code works again and the counter resets.
    const key = (await ctx.prisma.authThrottle.findFirstOrThrow()).key;
    await ctx.prisma.authThrottle.update({ where: { key }, data: { lockedUntil: new Date(Date.now() - 1000) } });
    const g2 = await createGuest(ctx);
    // Escalation: failures continue from 5 -> the next block of 5 locks for 30 minutes.
    for (let i = 0; i < 5; i++) expect((await recover(g.accountCode, 'AAAAA-BBBBB-CCCCC-DDDDD')).statusCode).toBe(401);
    const second = await recover(g.accountCode, g.recoveryCode);
    expect(second.statusCode).toBe(429);
    expect(second.json().error.details.retryAfterSeconds).toBeGreaterThan(29 * 60);

    await ctx.prisma.authThrottle.update({ where: { key }, data: { lockedUntil: new Date(Date.now() - 1000) } });
    expect((await recover(g.accountCode, g.recoveryCode)).statusCode).toBe(200);
    expect(await ctx.prisma.authThrottle.count({ where: { key } })).toBe(0);
    expect(g2.id).not.toBe(g.id);
  });

  it('a lock on one account does not affect other accounts', async () => {
    const a = await createGuest(ctx);
    const b = await createGuest(ctx);
    for (let i = 0; i < 5; i++) await recover(a.accountCode, 'AAAAA-BBBBB-CCCCC-DDDDD');
    expect((await recover(b.accountCode, b.recoveryCode)).statusCode).toBe(200);
  });

  it('non-existent account codes lock exactly like real ones', async () => {
    for (let i = 0; i < 5; i++) expect((await recover('NX-ZZZZZZZZ', 'AAAAA-BBBBB-CCCCC-DDDDD')).statusCode).toBe(401);
    const locked = await recover('NX-ZZZZZZZZ', 'AAAAA-BBBBB-CCCCC-DDDDD');
    expect(locked.statusCode).toBe(429);
    expect(locked.json().error.code).toBe('RECOVERY_LOCKED');
  });

  it('limits failed attempts per network as well', async () => {
    const limited = await createTestContext({ env: { RECOVERY_FAILED_PER_IP_15_MIN: '4' } });
    try {
      await resetDb(limited.prisma);
      for (let i = 0; i < 4; i++) {
        const r = await limited.app.inject({ method: 'POST', url: '/v1/auth/recover', payload: { accountCode: `NX-AAAAAAA${i}`, recoveryCode: 'AAAAA-BBBBB-CCCCC-DDDDD' } });
        expect(r.statusCode).toBe(401);
      }
      const blocked = await limited.app.inject({ method: 'POST', url: '/v1/auth/recover', payload: { accountCode: 'NX-AAAAAAA9', recoveryCode: 'AAAAA-BBBBB-CCCCC-DDDDD' } });
      expect(blocked.statusCode).toBe(429);
      expect(blocked.json().error.code).toBe('RECOVERY_IP_LIMIT');
    } finally {
      await limited.close();
    }
  });

  it('suspended accounts cannot be recovered into', async () => {
    const g = await createGuest(ctx);
    await ctx.prisma.user.update({ where: { id: g.id }, data: { status: 'SUSPENDED' } });
    const res = await recover(g.accountCode, g.recoveryCode);
    expect(res.statusCode).toBe(403);
    expect(res.json().error.code).toBe('ACCOUNT_SUSPENDED');
  });

  it('records security events without secrets', async () => {
    const g = await createGuest(ctx);
    await recover(g.accountCode, 'AAAAA-BBBBB-CCCCC-DDDDD');
    await recover(g.accountCode, g.recoveryCode);
    const types = (await ctx.prisma.securityEvent.findMany()).map((e) => e.type);
    expect(types).toEqual(expect.arrayContaining(['GUEST_CREATED', 'ACCOUNT_CREATED', 'RECOVERY_FAILED', 'RECOVERY_SUCCEEDED']));
    const dump = JSON.stringify(await ctx.prisma.securityEvent.findMany());
    expect(dump).not.toContain('127.0.0.1'); // raw IPs are never stored
  });
});

describe('recovery code rotation', () => {
  it('issues a new code and invalidates the old one', async () => {
    const g = await createGuest(ctx);
    const rotated = await ctx.app.inject({ method: 'POST', url: '/v1/auth/recovery-code/rotate', headers: bearer(g) });
    expect(rotated.statusCode).toBe(200);
    const fresh = rotated.json().recoveryCode as string;
    expect(fresh).toMatch(/^([0-9A-Z]{5}-){3}[0-9A-Z]{5}$/);
    expect(fresh).not.toBe(g.recoveryCode);
    expect(rotated.headers['cache-control']).toBe('no-store');

    expect((await recover(g.accountCode, g.recoveryCode)).statusCode).toBe(401); // old code is dead
    expect((await recover(g.accountCode, fresh)).statusCode).toBe(200);
  });

  it('requires a signed-in session and clears a pending lock', async () => {
    const g = await createGuest(ctx);
    expect((await ctx.app.inject({ method: 'POST', url: '/v1/auth/recovery-code/rotate' })).statusCode).toBe(401);

    for (let i = 0; i < 5; i++) await recover(g.accountCode, 'AAAAA-BBBBB-CCCCC-DDDDD');
    const rotated = await ctx.app.inject({ method: 'POST', url: '/v1/auth/recovery-code/rotate', headers: bearer(g) });
    expect((await recover(g.accountCode, rotated.json().recoveryCode)).statusCode).toBe(200);
  });
});

describe('account status', () => {
  it('shows the ID, no linked methods and the guest deadline', async () => {
    const g = await createGuest(ctx);
    const res = await ctx.app.inject({ method: 'GET', url: '/v1/auth/account', headers: bearer(g) });
    expect(res.statusCode).toBe(200);
    const b = res.json();
    expect(b).toMatchObject({ id: g.id, accountCode: g.accountCode, isGuest: true, hasRecoveryCode: true, linked: [] });
    expect(b.guestExpiry.warning).toBe(false);
    const months = (new Date(b.guestExpiry.expiresAt).getTime() - Date.now()) / (30.4 * 86_400_000);
    expect(months).toBeGreaterThan(8.8);
    expect(months).toBeLessThan(9.2);
    expect(res.body).not.toContain('recoveryCodeHash');
  });

  it('is hidden from other people: public profiles, search and leaderboards never expose the account code', async () => {
    const g = await createGuest(ctx);
    const viewer = await registerUser(ctx, 'viewer_one');
    const username = g.body.account.username as string;
    const profile = await ctx.app.inject({ method: 'GET', url: `/v1/users/${username}`, headers: bearer(viewer) });
    const search = await ctx.app.inject({ method: 'GET', url: '/v1/users/search?q=guest', headers: bearer(viewer) });
    const wealth = await ctx.app.inject({ method: 'GET', url: '/v1/leaderboards/wealth', headers: bearer(viewer) });
    for (const r of [profile, search, wealth]) {
      expect(r.statusCode).toBe(200);
      expect(r.body).not.toContain(g.accountCode);
      expect(r.body).not.toContain('recovery');
    }
    expect(search.json().items.map((u: { username: string }) => u.username)).toContain(username);
    void getPass;
  });
});
