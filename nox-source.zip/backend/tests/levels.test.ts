import { describe, expect, it } from 'vitest';
import { buildLevelTable, levelFromXp, levelProgress } from '../src/modules/progression/levels';

describe('level curve (configurable)', () => {
  const table = buildLevelTable({ baseXp: 100, growth: 1.5, maxLevel: 5 });

  it('builds cumulative thresholds from config', () => {
    // 100, 150, 225, 337.5 -> 338 (rounded), cumulative
    expect(table.thresholds).toEqual([0, 100, 250, 475, 813]);
  });

  it('derives the level from lifetime XP, clamped to the max level', () => {
    expect(levelFromXp(table, 0)).toBe(1);
    expect(levelFromXp(table, 99)).toBe(1);
    expect(levelFromXp(table, 100)).toBe(2);
    expect(levelFromXp(table, 474)).toBe(3);
    expect(levelFromXp(table, 813)).toBe(5);
    expect(levelFromXp(table, 10_000_000)).toBe(5);
  });

  it('reports progress inside the current level', () => {
    expect(levelProgress(table, 130)).toEqual({ level: 2, xp: 130, xpIntoLevel: 30, xpForNextLevel: 150, isMaxLevel: false });
    expect(levelProgress(table, 900)).toMatchObject({ level: 5, xpForNextLevel: 0, isMaxLevel: true });
  });

  it('changing configuration changes the curve without touching callers', () => {
    const easy = buildLevelTable({ baseXp: 10, growth: 1, maxLevel: 4 });
    expect(easy.thresholds).toEqual([0, 10, 20, 30]);
  });
});
