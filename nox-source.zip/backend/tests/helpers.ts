import type { FastifyInstance } from 'fastify';
import type { PrismaClient } from '@prisma/client';
import { buildApp } from '../src/app';
import type { Deliveries, OtpSender } from '../src/auth/delivery';
import type { GoogleVerifier } from '../src/auth/google';
import { loadConfig, type AppConfig } from '../src/config';
import { createPrisma } from '../src/db';

export interface TestContext {
  app: FastifyInstance;
  prisma: PrismaClient;
  config: AppConfig;
  outbox: Outbox;
  close: () => Promise<void>;
}

/** In-memory SMS / e-mail sender that records what would have been delivered. */
export class Outbox {
  readonly email: { to: string; code: string }[] = [];
  readonly sms: { to: string; code: string }[] = [];
  failNext = false;

  readonly deliveries: Deliveries = {
    email: this.sender(this.email),
    sms: this.sender(this.sms),
  };

  private sender(box: { to: string; code: string }[]): OtpSender {
    return {
      send: async (to, code) => {
        if (this.failNext) {
          this.failNext = false;
          throw new Error('provider down');
        }
        box.push({ to, code });
      },
    };
  }

  lastSms(): { to: string; code: string } {
    const m = this.sms[this.sms.length - 1];
    if (!m) throw new Error('no SMS was sent');
    return m;
  }

  lastEmail(): { to: string; code: string } {
    const m = this.email[this.email.length - 1];
    if (!m) throw new Error('no e-mail was sent');
    return m;
  }
}

export interface ContextOptions {
  /** Environment overrides, e.g. { ACCOUNT_CREATE_PER_IP_HOUR: '3' }. */
  env?: Record<string, string>;
  deliveries?: Deliveries;
  /** Use the senders built from the configuration (real SMTP / Kavenegar adapters) instead of the outbox. */
  realDeliveries?: boolean;
  googleVerifier?: GoogleVerifier | null;
}

export async function createTestContext(opts: ContextOptions = {}): Promise<TestContext> {
  const config = loadConfig({ ...process.env, ...(opts.env ?? {}) });
  const dbName = new URL(config.databaseUrl).pathname.replace('/', '');
  if (!dbName.endsWith('_test')) {
    throw new Error(`Refusing to run tests against non-test database "${dbName}"`);
  }
  const prisma = createPrisma(config.databaseUrl);
  const outbox = new Outbox();
  const app = await buildApp({
    config,
    prisma,
    deliveries: opts.realDeliveries ? undefined : (opts.deliveries ?? outbox.deliveries),
    googleVerifier: opts.googleVerifier ?? null,
  });
  await app.ready();
  return {
    app,
    prisma,
    config,
    outbox,
    close: async () => {
      await app.close();
      await prisma.$disconnect();
    },
  };
}

/** Empties every table (CASCADE follows foreign keys). Test database only. */
export async function resetDb(prisma: PrismaClient): Promise<void> {
  await prisma.$executeRawUnsafe(
    `TRUNCATE TABLE "User", "Clan", "MiniGame", "StoreItem", "WeeklyLeague", "Season",
       "OtpCode", "CaptchaChallenge", "AuthThrottle", "SecurityEvent",
       "AccountDeletionRecord", "DeletedAccountLedgerEntry" RESTART IDENTITY CASCADE`,
  );
}

export interface TestUser {
  id: string;
  username: string;
  accessToken: string;
  refreshToken: string;
}

export const TEST_PASSWORD = 'correct-horse-battery';

/**
 * Solves a real challenge through the public API. The correct answer is read from the
 * database (a client can never see it), which is exactly what a test needs to do.
 */
export async function getPass(ctx: Pick<TestContext, 'app' | 'prisma'>): Promise<string> {
  const created = await ctx.app.inject({ method: 'POST', url: '/v1/captcha/challenges' });
  if (created.statusCode !== 201) throw new Error(`challenge failed: ${created.statusCode} ${created.body}`);
  const id = created.json().id as string;
  const row = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id } });
  const answered = await ctx.app.inject({ method: 'POST', url: `/v1/captcha/challenges/${id}/answer`, payload: { optionId: row.correctToken } });
  if (answered.statusCode !== 200) throw new Error(`answer failed: ${answered.statusCode} ${answered.body}`);
  return answered.json().pass as string;
}

export async function registerUser(
  ctx: Pick<TestContext, 'app' | 'prisma'>,
  username: string,
  extra: Record<string, unknown> = {},
): Promise<TestUser> {
  const res = await ctx.app.inject({
    method: 'POST',
    url: '/v1/auth/register',
    payload: { username, email: `${username}@example.test`, password: TEST_PASSWORD, captchaPass: await getPass(ctx), ...extra },
  });
  if (res.statusCode !== 201) throw new Error(`register failed: ${res.statusCode} ${res.body}`);
  const body = res.json();
  return {
    id: body.user.id,
    username: body.user.username,
    accessToken: body.tokens.accessToken,
    refreshToken: body.tokens.refreshToken,
  };
}

export function bearer(user: { accessToken: string }) {
  return { authorization: `Bearer ${user.accessToken}` };
}

export async function createGuest(ctx: Pick<TestContext, 'app' | 'prisma'>) {
  const res = await ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: await getPass(ctx) } });
  if (res.statusCode !== 201) throw new Error(`guest failed: ${res.statusCode} ${res.body}`);
  const b = res.json();
  return {
    id: b.account.id as string,
    accountCode: b.account.accountCode as string,
    recoveryCode: b.recoveryCode as string,
    accessToken: b.tokens.accessToken as string,
    refreshToken: b.tokens.refreshToken as string,
    body: b,
  };
}
