import { createServer, type Server } from 'node:http';
import { createSign, generateKeyPairSync } from 'node:crypto';
import type { AddressInfo } from 'node:net';
import { OAuth2Client } from 'google-auth-library';
import { SMTPServer } from 'smtp-server';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { KavenegarSmsSender, SmtpEmailSender } from '../src/auth/delivery';
import { GoogleIdTokenVerifier } from '../src/auth/google';
import { createTestContext, getPass, resetDb } from './helpers';

const cleanups: (() => Promise<void>)[] = [];
afterAll(async () => {
  for (const c of cleanups) await c();
});

async function startSmtp(opts: { starttls?: boolean } = {}) {
  const messages: string[] = [];
  const server = new SMTPServer({
    authOptional: true,
    disabledCommands: opts.starttls ? [] : ['STARTTLS', 'AUTH'],
    onData(stream, _s, cb) {
      let data = '';
      stream.on('data', (c) => (data += c));
      stream.on('end', () => {
        messages.push(data);
        cb();
      });
    },
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  cleanups.push(() => new Promise<void>((r) => server.close(() => r())));
  return { port: (server.server.address() as AddressInfo).port, messages };
}

async function startKavenegar(status = 200) {
  const calls: { url: string; body: string; method: string }[] = [];
  const server: Server = createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      calls.push({ url: req.url ?? '', body, method: req.method ?? '' });
      res.setHeader('content-type', 'application/json');
      res.end(JSON.stringify({ return: { status, message: status === 200 ? 'تایید شد' : 'خطا' }, entries: [] }));
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  cleanups.push(() => new Promise<void>((r) => server.close(() => r())));
  return { baseUrl: `http://127.0.0.1:${(server.address() as AddressInfo).port}`, calls };
}

/** Finds the 6-digit code in a raw MIME message, decoding quoted-printable / base64 parts. */
function extractCode(raw: string): string | undefined {
  const parts = [raw];
  for (const m of raw.matchAll(/Content-Transfer-Encoding: base64\r?\n\r?\n([A-Za-z0-9+/=\r\n]+)/gi)) parts.push(Buffer.from(m[1]!.replace(/\s/g, ''), 'base64').toString('utf8'));
  for (const p of [...parts]) parts.push(p.replace(/=\r?\n/g, '').replace(/=([0-9A-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16))));
  for (const p of parts) {
    const hit = /Your N.{1,12}X sign-in code: (\d{6})/.exec(p);
    if (hit) return hit[1];
  }
  return undefined;
}

const smtpEnv = (port: number, extra: Record<string, string> = {}) => ({
  SMTP_HOST: '127.0.0.1', SMTP_PORT: String(port), SMTP_FROM: 'NØX <no-reply@example.test>', ...extra,
});

describe('SMTP e-mail delivery (real SMTP server on localhost)', () => {
  it('delivers the code by e-mail end to end', async () => {
    const smtp = await startSmtp();
    const ctx = await createTestContext({ env: smtpEnv(smtp.port, { SMTP_REQUIRE_TLS: 'false' }), realDeliveries: true });
    try {
      await resetDb(ctx.prisma);
      const pass = await getPass(ctx);
      const res = await ctx.app.inject({ method: 'POST', url: '/v1/auth/otp/request', payload: { channel: 'EMAIL', destination: 'player@example.com', captchaPass: pass } });
      expect(res.statusCode).toBe(200);
      expect(smtp.messages).toHaveLength(1);
      const code = extractCode(smtp.messages[0]!);
      expect(code).toBeDefined();
      const ok = await ctx.app.inject({ method: 'POST', url: '/v1/auth/otp/verify', payload: { channel: 'EMAIL', destination: 'player@example.com', code, captchaPass: pass } });
      expect(ok.statusCode).toBe(201);
    } finally {
      await ctx.close();
    }
  });

  it('refuses to send in plaintext when TLS is required (default)', async () => {
    const smtp = await startSmtp();
    const ctx = await createTestContext({ env: smtpEnv(smtp.port), realDeliveries: true });
    try {
      await resetDb(ctx.prisma);
      const res = await ctx.app.inject({ method: 'POST', url: '/v1/auth/otp/request', payload: { channel: 'EMAIL', destination: 'player@example.com', captchaPass: await getPass(ctx) } });
      expect(res.statusCode).toBe(502);
      expect(res.json().error.code).toBe('DELIVERY_FAILED');
      expect(smtp.messages).toHaveLength(0);
      expect(await ctx.prisma.otpCode.count()).toBe(0);
    } finally {
      await ctx.close();
    }
  });

  it('reports failure when the SMTP server is unreachable', async () => {
    const sender = new SmtpEmailSender({ host: '127.0.0.1', port: 1, secure: false, requireTLS: false, user: null, pass: null, from: 'a@example.test' });
    await expect(sender.send('x@example.com', '123456', 300)).rejects.toThrow();
  });
});

describe('Kavenegar SMS adapter (local mock of the documented API)', () => {
  const cfg = (baseUrl: string) => ({ provider: 'kavenegar' as const, apiKey: 'test-api-key', template: 'nox-otp', baseUrl });

  it('posts the code in the body (never the URL) in local Iranian format', async () => {
    const mock = await startKavenegar();
    await new KavenegarSmsSender(cfg(mock.baseUrl)).send('+989123456789', '482913');
    expect(mock.calls).toHaveLength(1);
    const call = mock.calls[0]!;
    expect(call.method).toBe('POST');
    expect(call.url).toBe('/v1/test-api-key/verify/lookup.json');
    expect(call.url).not.toContain('482913');
    const body = new URLSearchParams(call.body);
    expect(body.get('receptor')).toBe('09123456789');
    expect(body.get('token')).toBe('482913');
    expect(body.get('template')).toBe('nox-otp');
  });

  it('throws on a provider error status, so no success is ever faked', async () => {
    const mock = await startKavenegar(418);
    await expect(new KavenegarSmsSender(cfg(mock.baseUrl)).send('+989123456789', '123456')).rejects.toThrow();
  });

  it('delivers through the real adapter end to end', async () => {
    const mock = await startKavenegar();
    const ctx = await createTestContext({
      env: { SMS_PROVIDER: 'kavenegar', KAVENEGAR_API_KEY: 'k', KAVENEGAR_TEMPLATE: 't', KAVENEGAR_BASE_URL: mock.baseUrl },
      realDeliveries: true,
    });
    try {
      await resetDb(ctx.prisma);
      const pass = await getPass(ctx);
      expect((await ctx.app.inject({ method: 'POST', url: '/v1/auth/otp/request', payload: { channel: 'PHONE', destination: '09123456789', captchaPass: pass } })).statusCode).toBe(200);
      const code = new URLSearchParams(mock.calls[0]!.body).get('token');
      const ok = await ctx.app.inject({ method: 'POST', url: '/v1/auth/otp/verify', payload: { channel: 'PHONE', destination: '09123456789', code, captchaPass: pass } });
      expect(ok.statusCode).toBe(201);
    } finally {
      await ctx.close();
    }
  });
});

describe('Google ID token verification (real library, locally generated signing key)', () => {
  const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
  const other = generateKeyPairSync('rsa', { modulusLength: 2048 });
  const AUD = 'nox-client-id.apps.googleusercontent.com';
  const b64 = (o: object) => Buffer.from(JSON.stringify(o)).toString('base64url');

  function token(claims: Record<string, unknown>, key = privateKey) {
    const now = Math.floor(Date.now() / 1000);
    const head = b64({ alg: 'RS256', typ: 'JWT', kid: 'k1' });
    const payload = b64({ iss: 'https://accounts.google.com', aud: AUD, sub: '1122334455', iat: now, exp: now + 3600, ...claims });
    const sig = createSign('RSA-SHA256').update(`${head}.${payload}`).sign(key).toString('base64url');
    return `${head}.${payload}.${sig}`;
  }

  const client = new OAuth2Client();
  (client as any).getFederatedSignonCertsAsync = async () => ({
    certs: { k1: publicKey.export({ type: 'spki', format: 'pem' }).toString() },
    format: 'PEM',
  });
  const verifier = new GoogleIdTokenVerifier([AUD], client);

  it('accepts a valid token and returns only the verified subject', async () => {
    expect(await verifier.verify(token({ email: 'ignored@example.com', name: 'Ignored' }))).toEqual({ sub: '1122334455' });
  });

  it('rejects wrong audience, expired, wrong issuer, forged signature and garbage', async () => {
    const past = Math.floor(Date.now() / 1000) - 7200;
    await expect(verifier.verify(token({ aud: 'someone-elses-app' }))).rejects.toThrow();
    await expect(verifier.verify(token({ iat: past - 3600, exp: past }))).rejects.toThrow();
    await expect(verifier.verify(token({ iss: 'https://evil.example.com' }))).rejects.toThrow();
    await expect(verifier.verify(token({}, other.privateKey))).rejects.toThrow();
    await expect(verifier.verify('not.a.jwt')).rejects.toThrow();
  });
});
