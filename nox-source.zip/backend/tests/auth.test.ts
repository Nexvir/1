import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { TEST_PASSWORD, bearer, createTestContext, getPass, registerUser, resetDb, type TestContext } from './helpers';

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext();
});
afterAll(async () => ctx.close());
beforeEach(async () => resetDb(ctx.prisma));

describe('authentication', () => {
  it('registers a user with profile, wallet and a ledgered welcome bonus', async () => {
    const user = await registerUser(ctx, 'ShadowKing');
    expect(user.username).toBe('shadowking'); // normalized

    const row = await ctx.prisma.user.findUniqueOrThrow({ where: { id: user.id }, include: { profile: true, wallet: true } });
    expect(row.passwordHash).toMatch(/^\$argon2id\$/);
    expect(row.passwordHash).not.toContain(TEST_PASSWORD);
    expect(row.profile?.level).toBe(1);
    expect(row.wallet?.balance).toBe(500);
    expect(row.wallet?.promoTotal).toBe(500);

    const ledger = await ctx.prisma.walletTransaction.findMany({ where: { userId: user.id } });
    expect(ledger).toHaveLength(1);
    expect(ledger[0]).toMatchObject({ amount: 500, kind: 'PROMO', source: 'welcome_bonus', balanceAfter: 500 });
  });

  it('rejects duplicate username or email (case-insensitive)', async () => {
    await registerUser(ctx, 'sara_blue');
    const dupName = await ctx.app.inject({
      method: 'POST',
      url: '/v1/auth/register',
      payload: { username: 'SARA_BLUE', email: 'other@example.test', password: TEST_PASSWORD, captchaPass: await getPass(ctx) },
    });
    expect(dupName.statusCode).toBe(409);
    expect(dupName.json().error.code).toBe('ACCOUNT_EXISTS');

    const dupEmail = await ctx.app.inject({
      method: 'POST',
      url: '/v1/auth/register',
      payload: { username: 'someone_else', email: 'SARA_BLUE@example.test', password: TEST_PASSWORD, captchaPass: await getPass(ctx) },
    });
    expect(dupEmail.statusCode).toBe(409);
  });

  it('validates input', async () => {
    const res = await ctx.app.inject({
      method: 'POST',
      url: '/v1/auth/register',
      payload: { username: 'a', email: 'not-an-email', password: 'short' },
    });
    expect(res.statusCode).toBe(400);
    expect(res.json().error.code).toBe('VALIDATION_ERROR');
    expect(res.json().error.details.length).toBeGreaterThanOrEqual(3);
  });

  it('logs in with username or email and gives identical errors for bad user / bad password', async () => {
    await registerUser(ctx, 'rexhunter');

    const byName = await ctx.app.inject({ method: 'POST', url: '/v1/auth/login', payload: { identifier: 'RexHunter', password: TEST_PASSWORD } });
    expect(byName.statusCode).toBe(200);
    const byEmail = await ctx.app.inject({ method: 'POST', url: '/v1/auth/login', payload: { identifier: 'rexhunter@example.test', password: TEST_PASSWORD } });
    expect(byEmail.statusCode).toBe(200);

    const badPass = await ctx.app.inject({ method: 'POST', url: '/v1/auth/login', payload: { identifier: 'rexhunter', password: 'wrong-password' } });
    const noUser = await ctx.app.inject({ method: 'POST', url: '/v1/auth/login', payload: { identifier: 'ghost_user', password: 'wrong-password' } });
    expect(badPass.statusCode).toBe(401);
    expect(noUser.statusCode).toBe(401);
    expect(badPass.json()).toEqual(noUser.json());
  });

  it('protects routes and never exposes secrets', async () => {
    const anon = await ctx.app.inject({ method: 'GET', url: '/v1/users/me' });
    expect(anon.statusCode).toBe(401);
    const forged = await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: { authorization: 'Bearer not.a.jwt' } });
    expect(forged.statusCode).toBe(401);

    const user = await registerUser(ctx, 'armanxp');
    const me = await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: bearer(user) });
    expect(me.statusCode).toBe(200);
    expect(me.body).not.toContain('passwordHash');
    expect(me.json().wallet.balance).toBe(500);
  });

  it('rotates refresh tokens and revokes every session when an old one is replayed', async () => {
    const user = await registerUser(ctx, 'nika_storm');
    const first = await ctx.app.inject({ method: 'POST', url: '/v1/auth/refresh', payload: { refreshToken: user.refreshToken } });
    expect(first.statusCode).toBe(200);
    const rotated = first.json().tokens.refreshToken as string;
    expect(rotated).not.toBe(user.refreshToken);

    // Replaying the consumed token is treated as theft...
    const replay = await ctx.app.inject({ method: 'POST', url: '/v1/auth/refresh', payload: { refreshToken: user.refreshToken } });
    expect(replay.statusCode).toBe(401);
    // ...and kills the legitimately rotated token too.
    const afterTheft = await ctx.app.inject({ method: 'POST', url: '/v1/auth/refresh', payload: { refreshToken: rotated } });
    expect(afterTheft.statusCode).toBe(401);
  });

  it('logout revokes the refresh token', async () => {
    const user = await registerUser(ctx, 'logout_user');
    const out = await ctx.app.inject({ method: 'POST', url: '/v1/auth/logout', payload: { refreshToken: user.refreshToken } });
    expect(out.statusCode).toBe(204);
    const res = await ctx.app.inject({ method: 'POST', url: '/v1/auth/refresh', payload: { refreshToken: user.refreshToken } });
    expect(res.statusCode).toBe(401);
  });

  it('blocks suspended accounts immediately, even with a valid access token', async () => {
    const user = await registerUser(ctx, 'bad_actor');
    await ctx.prisma.user.update({ where: { id: user.id }, data: { status: 'SUSPENDED', suspendedAt: new Date() } });

    const api = await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: bearer(user) });
    expect(api.statusCode).toBe(403);
    expect(api.json().error.code).toBe('ACCOUNT_SUSPENDED');

    const login = await ctx.app.inject({ method: 'POST', url: '/v1/auth/login', payload: { identifier: 'bad_actor', password: TEST_PASSWORD } });
    expect(login.statusCode).toBe(403);
    const refresh = await ctx.app.inject({ method: 'POST', url: '/v1/auth/refresh', payload: { refreshToken: user.refreshToken } });
    expect(refresh.statusCode).toBe(403);
  });
});
