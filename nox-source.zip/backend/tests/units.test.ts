import { describe, expect, it } from 'vitest';
import {
  generateAccountCode,
  generateOtpCode,
  generateRecoveryCode,
  hmacHex,
  normalizeAccountCode,
  normalizeRecoveryCode,
  safeEqual,
} from '../src/auth/codes';
import { maskEmail, maskPhone, normalizePhone } from '../src/auth/contact';
import { addMonthsUtc, guestExpiry } from '../src/modules/accounts/activity';
import { loadConfig } from '../src/config';
import { recoveryLockMinutes } from '../src/modules/accounts/recovery';

const config = loadConfig({
  DATABASE_URL: 'postgresql://x',
  JWT_ACCESS_SECRET: 'x'.repeat(40),
  SERVER_PEPPER: 'y'.repeat(40),
});

describe('codes', () => {
  it('generates well-formed, unambiguous, unique identifiers', () => {
    const accounts = new Set<string>();
    const recoveries = new Set<string>();
    for (let i = 0; i < 2000; i++) {
      const a = generateAccountCode();
      const r = generateRecoveryCode();
      expect(a).toMatch(/^NX-[0-9A-HJKMNP-TV-Z]{8}$/);
      expect(r).toMatch(/^[0-9A-HJKMNP-TV-Z]{5}(-[0-9A-HJKMNP-TV-Z]{5}){3}$/);
      accounts.add(a);
      recoveries.add(r);
    }
    expect(accounts.size).toBe(2000);
    expect(recoveries.size).toBe(2000);
  });

  it('normalizes recovery codes typed by hand', () => {
    expect(normalizeRecoveryCode('7k2m9-qxd4f-8h3jn-v6prt')).toBe('7K2M9QXD4F8H3JNV6PRT');
    expect(normalizeRecoveryCode(' 7K2M9 QXD4F 8H3JN V6PRT ')).toBe('7K2M9QXD4F8H3JNV6PRT');
    // look-alike characters: O -> 0, I/L -> 1
    expect(normalizeRecoveryCode('OOOOO-IIIII-LLLLL-0000O')).toBe('00000111111111100000');
    expect(normalizeRecoveryCode('too-short')).toBeNull();
    expect(normalizeRecoveryCode('7K2M9-QXD4F-8H3JN-V6PRT-EXTRA')).toBeNull();
    expect(normalizeRecoveryCode('7K2M9-QXD4F-8H3JN-V6P!T')).toBeNull();
  });

  it('normalizes account codes', () => {
    expect(normalizeAccountCode('nx-7k2m9qxd')).toBe('NX-7K2M9QXD');
    expect(normalizeAccountCode('NX7K2M9QXD')).toBe('NX-7K2M9QXD');
    expect(normalizeAccountCode(' NX-7K2M9QXD ')).toBe('NX-7K2M9QXD');
    expect(normalizeAccountCode('7K2M9QXD')).toBeNull();
    expect(normalizeAccountCode('NX-123')).toBeNull();
  });

  it('one-time codes are 6 digits and hmac helpers are domain separated', () => {
    for (let i = 0; i < 500; i++) expect(generateOtpCode()).toMatch(/^\d{6}$/);
    const a = hmacHex('pepper-pepper-pepper-pepper-pepper', 'otp', 'v');
    expect(a).toMatch(/^[0-9a-f]{64}$/);
    expect(a).not.toBe(hmacHex('pepper-pepper-pepper-pepper-pepper', 'recovery', 'v'));
    expect(safeEqual(a, a)).toBe(true);
    expect(safeEqual(a, a.slice(0, -1) + (a.endsWith('0') ? '1' : '0'))).toBe(false);
    expect(safeEqual(a, 'short')).toBe(false);
  });
});

describe('phone / e-mail helpers', () => {
  it('normalizes Iranian and international numbers to E.164', () => {
    expect(normalizePhone('09123456789')).toBe('+989123456789');
    expect(normalizePhone('0912 345 6789')).toBe('+989123456789');
    expect(normalizePhone('۰۹۱۲۳۴۵۶۷۸۹')).toBe('+989123456789');
    expect(normalizePhone('٠٩١٢٣٤٥٦٧٨٩')).toBe('+989123456789');
    expect(normalizePhone('+98 912-345-6789')).toBe('+989123456789');
    expect(normalizePhone('00989123456789')).toBe('+989123456789');
    expect(normalizePhone('+14155552671')).toBe('+14155552671');
  });

  it('rejects malformed numbers and non-mobile Iranian numbers', () => {
    for (const bad of ['', '123', 'abcdefghijk', '09123', '+989123', '02112345678', '+982112345678', '++989123456789']) {
      expect(normalizePhone(bad)).toBeNull();
    }
  });

  it('masks contact details', () => {
    expect(maskPhone('+989123456789')).toBe('+9891***6789');
    expect(maskEmail('player@example.com')).toBe('p***@example.com');
  });
});

describe('guest inactivity arithmetic', () => {
  it('adds months in UTC with end-of-month clamping (same as PostgreSQL)', () => {
    expect(addMonthsUtc(new Date('2026-01-31T10:00:00Z'), 1).toISOString()).toBe('2026-02-28T10:00:00.000Z');
    expect(addMonthsUtc(new Date('2028-01-31T10:00:00Z'), 1).toISOString()).toBe('2028-02-29T10:00:00.000Z');
    expect(addMonthsUtc(new Date('2026-06-15T12:00:00Z'), 9).toISOString()).toBe('2027-03-15T12:00:00.000Z');
    expect(addMonthsUtc(new Date('2026-05-31T00:00:00Z'), 9).toISOString()).toBe('2027-02-28T00:00:00.000Z');
  });

  it('computes expiry from the last activity, warns in the final 30 days, exempts non-guests', () => {
    const last = new Date('2026-01-10T00:00:00Z');
    const young = guestExpiry(config, { isGuest: true, lastActivityAt: last }, new Date('2026-05-01T00:00:00Z'))!;
    expect(young.expiresAt.toISOString()).toBe('2026-10-10T00:00:00.000Z');
    expect(young.warning).toBe(false);

    const soon = guestExpiry(config, { isGuest: true, lastActivityAt: last }, new Date('2026-09-20T00:00:00Z'))!;
    expect(soon.warning).toBe(true);
    expect(soon.daysLeft).toBe(20);

    const late = guestExpiry(config, { isGuest: true, lastActivityAt: last }, new Date('2026-12-01T00:00:00Z'))!;
    expect(late).toMatchObject({ warning: true, daysLeft: 0 });

    expect(guestExpiry(config, { isGuest: false, lastActivityAt: last })).toBeNull();
  });

  it('recovery lock escalates: 15 min, 30 min, 60 min ... capped at 24 h', () => {
    expect([5, 10, 15, 20].map((n) => recoveryLockMinutes(config, n))).toEqual([15, 30, 60, 120]);
    expect(recoveryLockMinutes(config, 500)).toBe(24 * 60);
  });
});

describe('configuration', () => {
  const base = { DATABASE_URL: 'postgresql://x', JWT_ACCESS_SECRET: 'x'.repeat(40), SERVER_PEPPER: 'y'.repeat(40) };

  it('reports e-mail / SMS / Google as unconfigured by default', () => {
    const c = loadConfig(base);
    expect(c.smtp).toBeNull();
    expect(c.sms).toBeNull();
    expect(c.googleClientIds).toEqual([]);
  });

  it('refuses unsafe or incomplete settings', () => {
    expect(() => loadConfig({ ...base, SERVER_PEPPER: 'short' })).toThrow(/SERVER_PEPPER/);
    expect(() => loadConfig({ ...base, SMTP_HOST: 'smtp.example.test' })).toThrow(/SMTP_FROM/);
    expect(() => loadConfig({ ...base, SMS_PROVIDER: 'kavenegar' })).toThrow(/KAVENEGAR/);
    expect(() => loadConfig({ ...base, SMS_PROVIDER: 'twilio' })).toThrow(/unsupported/);
    expect(() => loadConfig({ ...base, NODE_ENV: 'production', ANTIBOT_ENABLED: 'false' })).toThrow(/ANTIBOT_ENABLED/);
    expect(() => loadConfig({ ...base, NODE_ENV: 'production', SERVER_PEPPER: 'REPLACE_ME'.padEnd(40, 'x') })).toThrow(/placeholder/);
  });
});
