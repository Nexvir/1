import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { changeWallet } from '../src/modules/wallet/service';
import { bearer, createTestContext, registerUser, resetDb, type TestContext, type TestUser } from './helpers';

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext();
});
afterAll(async () => ctx.close());
beforeEach(async () => resetDb(ctx.prisma));

async function setBalance(user: TestUser, target: number) {
  const w = await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId: user.id } });
  const delta = target - w.balance;
  if (delta === 0) return;
  await changeWallet(ctx.prisma, {
    userId: user.id,
    amount: delta,
    kind: delta > 0 ? 'EARN' : 'SPEND',
    source: 'test_setup',
    idempotencyKey: `setup-${user.id}-${target}`,
  });
}

describe('wealth leaderboard', () => {
  it('ranks by spendable balance, paginates, and reports my own rank', async () => {
    const names = ['u1', 'u2', 'u3', 'u4', 'u5'];
    const users: TestUser[] = [];
    for (const n of names) users.push(await registerUser(ctx, `player_${n}`));
    const balances = [100, 900, 500, 900, 700];
    for (const [i, u] of users.entries()) await setBalance(u, balances[i]!);

    const res = await ctx.app.inject({ method: 'GET', url: '/v1/leaderboards/wealth?limit=50', headers: bearer(users[2]!) });
    expect(res.statusCode).toBe(200);
    const body = res.json();
    expect(body.definition).toBe('balance');
    expect(body.items.map((i: { wealth: number }) => i.wealth)).toEqual([900, 900, 700, 500, 100]);
    expect(body.items.map((i: { rank: number }) => i.rank)).toEqual([1, 2, 3, 4, 5]);
    expect(body.me).toEqual({ rank: 4, wealth: 500, listed: true });
    expect(JSON.stringify(body)).not.toContain('email');

    const page = await ctx.app.inject({ method: 'GET', url: '/v1/leaderboards/wealth?limit=2&offset=2', headers: bearer(users[0]!) });
    expect(page.json().items.map((i: { rank: number }) => i.rank)).toEqual([3, 4]);
    expect(page.json().me.rank).toBe(5);
  });

  it('does not list suspended players or players with a private profile', async () => {
    const rich = await registerUser(ctx, 'rich_private');
    const bad = await registerUser(ctx, 'rich_banned');
    const viewer = await registerUser(ctx, 'viewer');
    await setBalance(rich, 5000);
    await setBalance(bad, 6000);
    await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(rich), payload: { visibility: 'PRIVATE' } });
    await ctx.prisma.user.update({ where: { id: bad.id }, data: { status: 'SUSPENDED' } });

    const res = await ctx.app.inject({ method: 'GET', url: '/v1/leaderboards/wealth', headers: bearer(viewer) });
    expect(res.json().items.map((i: { username: string }) => i.username)).toEqual(['viewer']);

    const mine = await ctx.app.inject({ method: 'GET', url: '/v1/leaderboards/wealth', headers: bearer(rich) });
    expect(mine.json().me).toEqual({ rank: null, wealth: 5000, listed: false });
  });

  it('is not affected by trophies or XP', async () => {
    const a = await registerUser(ctx, 'trophy_hog');
    const b = await registerUser(ctx, 'coin_hog');
    await ctx.prisma.userProfile.update({ where: { userId: a.id }, data: { trophies: 9999, xp: 99999 } });
    await setBalance(b, 800);
    const res = await ctx.app.inject({ method: 'GET', url: '/v1/leaderboards/wealth', headers: bearer(a) });
    expect(res.json().items[0].username).toBe('coin_hog');
  });
});

describe('profiles, privacy and search', () => {
  it('returns level progress for the owner and respects profile visibility for others', async () => {
    const owner = await registerUser(ctx, 'shadowking');
    const stranger = await registerUser(ctx, 'stranger');
    const friend = await registerUser(ctx, 'buddy');
    await ctx.prisma.userProfile.update({ where: { userId: owner.id }, data: { xp: 130, trophies: 320 } });

    const me = await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: bearer(owner) });
    expect(me.json().profile.progress).toMatchObject({ level: 2, xpIntoLevel: 30, isMaxLevel: false });

    // PUBLIC (default): strangers see the profile and may send a request.
    const pub = await ctx.app.inject({ method: 'GET', url: '/v1/users/shadowking', headers: bearer(stranger) });
    expect(pub.json().restricted).toBe(false);
    expect(pub.json().profile.trophies).toBe(320);
    expect(pub.json().canSendFriendRequest).toBe(true);
    expect(JSON.stringify(pub.json())).not.toContain('example.test'); // no email leak

    // FRIENDS only.
    await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(owner), payload: { visibility: 'FRIENDS' } });
    const hidden = await ctx.app.inject({ method: 'GET', url: '/v1/users/shadowking', headers: bearer(stranger) });
    expect(hidden.json().restricted).toBe(true);
    expect(hidden.json().profile).toBeNull();
    expect(hidden.json().user.username).toBe('shadowking');

    const req = await ctx.app.inject({ method: 'POST', url: '/v1/friends/requests', headers: bearer(friend), payload: { username: 'shadowking' } });
    await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${req.json().id}/accept`, headers: bearer(owner) });
    const visible = await ctx.app.inject({ method: 'GET', url: '/v1/users/shadowking', headers: bearer(friend) });
    expect(visible.json().restricted).toBe(false);
    expect(visible.json().relation.state).toBe('FRIENDS');

    // Hiding stats hides only stats.
    await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(owner), payload: { visibility: 'PUBLIC', showStats: false } });
    const noStats = await ctx.app.inject({ method: 'GET', url: '/v1/users/shadowking', headers: bearer(stranger) });
    expect(noStats.json().profile.stats).toBeNull();
    expect(noStats.json().profile.trophies).toBe(320);
  });

  it('searches by username prefix, excluding self, private profiles and blocked users', async () => {
    const me = await registerUser(ctx, 'searcher');
    await registerUser(ctx, 'nova_one');
    await registerUser(ctx, 'nova_two');
    const priv = await registerUser(ctx, 'nova_secret');
    const blocked = await registerUser(ctx, 'nova_blocked');
    await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(priv), payload: { visibility: 'PRIVATE' } });
    await ctx.app.inject({ method: 'POST', url: '/v1/blocks', headers: bearer(me), payload: { userId: blocked.id } });

    const res = await ctx.app.inject({ method: 'GET', url: '/v1/users/search?q=NOVA', headers: bearer(me) });
    expect(res.json().items.map((u: { username: string }) => u.username)).toEqual(['nova_one', 'nova_two']);

    const short = await ctx.app.inject({ method: 'GET', url: '/v1/users/search?q=n', headers: bearer(me) });
    expect(short.statusCode).toBe(400);
  });

  it('rejects unknown or economy-related profile fields and unknown users', async () => {
    const me = await registerUser(ctx, 'alice');
    const bad = await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(me), payload: { level: 99 } });
    expect(bad.statusCode).toBe(400);
    const empty = await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(me), payload: {} });
    expect(empty.statusCode).toBe(400);
    const none = await ctx.app.inject({ method: 'GET', url: '/v1/users/nobody_here', headers: bearer(me) });
    expect(none.statusCode).toBe(404);
  });
});
