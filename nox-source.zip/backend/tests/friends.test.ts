import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { bearer, createTestContext, registerUser, resetDb, type TestContext, type TestUser } from './helpers';

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext();
});
afterAll(async () => ctx.close());
beforeEach(async () => resetDb(ctx.prisma));

const send = (from: TestUser, toUsername: string) =>
  ctx.app.inject({ method: 'POST', url: '/v1/friends/requests', headers: bearer(from), payload: { username: toUsername } });

describe('friend requests', () => {
  it('sends, accepts and lists a friendship (stored once, in canonical order)', async () => {
    const a = await registerUser(ctx, 'alice');
    const b = await registerUser(ctx, 'bobby');

    const res = await send(a, 'bobby');
    expect(res.statusCode).toBe(201);
    const requestId = res.json().id as string;

    const incoming = await ctx.app.inject({ method: 'GET', url: '/v1/friends/requests?direction=incoming', headers: bearer(b) });
    expect(incoming.json().items).toHaveLength(1);
    expect(incoming.json().items[0].user.username).toBe('alice');

    // The receiver got a notification; the sender cannot accept their own request.
    const notif = await ctx.prisma.notification.findMany({ where: { userId: b.id } });
    expect(notif.map((n) => n.type)).toContain('FRIEND_REQUEST');
    const selfAccept = await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${requestId}/accept`, headers: bearer(a) });
    expect(selfAccept.statusCode).toBe(404);

    const accept = await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${requestId}/accept`, headers: bearer(b) });
    expect(accept.statusCode).toBe(200);

    const friendsOfA = await ctx.app.inject({ method: 'GET', url: '/v1/friends', headers: bearer(a) });
    const friendsOfB = await ctx.app.inject({ method: 'GET', url: '/v1/friends', headers: bearer(b) });
    expect(friendsOfA.json().items.map((f: { username: string }) => f.username)).toEqual(['bobby']);
    expect(friendsOfB.json().items.map((f: { username: string }) => f.username)).toEqual(['alice']);
    expect(await ctx.prisma.friendship.count()).toBe(1);

    // Accepting twice is rejected.
    const again = await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${requestId}/accept`, headers: bearer(b) });
    expect(again.statusCode).toBe(409);
  });

  it('prevents duplicate and contradictory (reverse) requests and requests to friends or self', async () => {
    const a = await registerUser(ctx, 'alice');
    const b = await registerUser(ctx, 'bobby');

    expect((await send(a, 'bobby')).statusCode).toBe(201);
    const dup = await send(a, 'bobby');
    expect(dup.statusCode).toBe(409);
    expect(dup.json().error.code).toBe('REQUEST_ALREADY_SENT');

    const reverse = await send(b, 'alice');
    expect(reverse.statusCode).toBe(409);
    expect(reverse.json().error.code).toBe('REQUEST_ALREADY_RECEIVED');
    expect(reverse.json().error.details.requestId).toBeTruthy();

    const self = await send(a, 'alice');
    expect(self.statusCode).toBe(400);
    expect(await ctx.prisma.friendRequest.count()).toBe(1);

    await ctx.app.inject({
      method: 'POST',
      url: `/v1/friends/requests/${reverse.json().error.details.requestId}/accept`,
      headers: bearer(b),
    });
    const already = await send(a, 'bobby');
    expect(already.statusCode).toBe(409);
    expect(already.json().error.code).toBe('ALREADY_FRIENDS');
  });

  it('lets only one of many simultaneous identical requests through (DB-level guarantee)', async () => {
    const a = await registerUser(ctx, 'alice');
    await registerUser(ctx, 'bobby');

    const results = await Promise.all(Array.from({ length: 8 }, () => send(a, 'bobby')));
    const created = results.filter((r) => r.statusCode === 201);
    const rejected = results.filter((r) => r.statusCode === 409);
    expect(created).toHaveLength(1);
    expect(rejected).toHaveLength(7);
    expect(await ctx.prisma.friendRequest.count({ where: { status: 'PENDING' } })).toBe(1);
  });

  it('lets only one of two simultaneous opposite requests through', async () => {
    const a = await registerUser(ctx, 'alice');
    const b = await registerUser(ctx, 'bobby');
    const results = await Promise.all([send(a, 'bobby'), send(b, 'alice'), send(a, 'bobby'), send(b, 'alice')]);
    expect(results.filter((r) => r.statusCode === 201)).toHaveLength(1);
    expect(await ctx.prisma.friendRequest.count({ where: { status: 'PENDING' } })).toBe(1);
  });

  it('supports reject, cancel and re-requesting afterwards, and removing a friend', async () => {
    const a = await registerUser(ctx, 'alice');
    const b = await registerUser(ctx, 'bobby');

    const first = await send(a, 'bobby');
    const reject = await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${first.json().id}/reject`, headers: bearer(b) });
    expect(reject.json().status).toBe('REJECTED');

    const second = await send(a, 'bobby');
    expect(second.statusCode).toBe(201);
    const cancel = await ctx.app.inject({ method: 'DELETE', url: `/v1/friends/requests/${second.json().id}`, headers: bearer(a) });
    expect(cancel.statusCode).toBe(204);

    const third = await send(a, 'bobby');
    await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${third.json().id}/accept`, headers: bearer(b) });
    const remove = await ctx.app.inject({ method: 'DELETE', url: `/v1/friends/${b.id}`, headers: bearer(a) });
    expect(remove.statusCode).toBe(204);
    expect(await ctx.prisma.friendship.count()).toBe(0);
    const removeAgain = await ctx.app.inject({ method: 'DELETE', url: `/v1/friends/${b.id}`, headers: bearer(a) });
    expect(removeAgain.statusCode).toBe(404);
  });

  it('honours the "nobody can send me requests" privacy setting', async () => {
    const a = await registerUser(ctx, 'alice');
    const b = await registerUser(ctx, 'bobby');
    const patch = await ctx.app.inject({ method: 'PATCH', url: '/v1/users/me/profile', headers: bearer(b), payload: { requestPolicy: 'NOBODY' } });
    expect(patch.statusCode).toBe(200);
    const res = await send(a, 'bobby');
    expect(res.statusCode).toBe(403);
    expect(res.json().error.code).toBe('REQUESTS_DISABLED');
  });
});

describe('blocking', () => {
  it('removes the friendship and cancels pending requests, and hides the blocker', async () => {
    const a = await registerUser(ctx, 'alice');
    const b = await registerUser(ctx, 'bobby');
    const c = await registerUser(ctx, 'carol');

    const req = await send(a, 'bobby');
    await ctx.app.inject({ method: 'POST', url: `/v1/friends/requests/${req.json().id}/accept`, headers: bearer(b) });
    await send(c, 'alice');

    const block = await ctx.app.inject({ method: 'POST', url: '/v1/blocks', headers: bearer(a), payload: { userId: b.id } });
    expect(block.statusCode).toBe(204);
    expect(await ctx.prisma.friendship.count()).toBe(0);

    // Blocked user cannot see or request the blocker.
    const profile = await ctx.app.inject({ method: 'GET', url: '/v1/users/alice', headers: bearer(b) });
    expect(profile.statusCode).toBe(404);
    const request = await send(b, 'alice');
    expect(request.statusCode).toBe(404);

    // Blocker is told to unblock first and sees the block in their relation state.
    const mine = await send(a, 'bobby');
    expect(mine.statusCode).toBe(409);
    expect(mine.json().error.code).toBe('YOU_BLOCKED_THIS_USER');
    const rel = await ctx.app.inject({ method: 'GET', url: '/v1/users/bobby', headers: bearer(a) });
    expect(rel.json().relation.state).toBe('BLOCKED_BY_ME');

    // Blocking one user does not disturb unrelated pending requests.
    expect(await ctx.prisma.friendRequest.count({ where: { status: 'PENDING', senderId: c.id } })).toBe(1);

    const unblock = await ctx.app.inject({ method: 'DELETE', url: `/v1/blocks/${b.id}`, headers: bearer(a) });
    expect(unblock.statusCode).toBe(204);
    expect((await send(a, 'bobby')).statusCode).toBe(201);
  });

  it('cannot block yourself', async () => {
    const a = await registerUser(ctx, 'alice');
    const res = await ctx.app.inject({ method: 'POST', url: '/v1/blocks', headers: bearer(a), payload: { userId: a.id } });
    expect(res.statusCode).toBe(400);
  });
});
