import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { ICONS, compatible } from '../src/modules/antibot/icons';
import type { StoredOption } from '../src/modules/antibot/service';
import { TEST_PASSWORD, createGuest, createTestContext, getPass, resetDb, type TestContext } from './helpers';

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext();
});
afterAll(async () => ctx.close());
beforeEach(async () => resetDb(ctx.prisma));

const newChallenge = () => ctx.app.inject({ method: 'POST', url: '/v1/captcha/challenges' });
const answer = (id: string, optionId: string) =>
  ctx.app.inject({ method: 'POST', url: `/v1/captcha/challenges/${id}/answer`, payload: { optionId } });

describe('NØX picture challenge', () => {
  it('hands the client everything it needs to render, and nothing that reveals the answer', async () => {
    const res = await newChallenge();
    expect(res.statusCode).toBe(201);
    const c = res.json();
    expect(c).toMatchObject({ locale: 'fa', direction: 'rtl' });
    expect(c.prompt).toMatch(/[؀-ۿ]/); // Persian instruction
    expect(c.options).toHaveLength(6); // big 2x3 grid for small phones
    expect(new Set(c.options.map((o: { id: string }) => o.id)).size).toBe(6);

    const text = res.body;
    for (const forbidden of ['correct', 'icon', 'color', 'answer']) expect(text).not.toContain(forbidden);
    // Neither option ids nor image URLs name the object shown.
    for (const key of Object.keys(ICONS)) expect(text).not.toContain(`${key}.png`);
    for (const o of c.options) expect(o.imageUrl).toMatch(/\/images\/[A-Za-z0-9_-]{8,64}\.png$/);
    expect(res.headers['cache-control']).toBe('no-store');
  });

  it('serves local PNG pictures with safe headers, and unknown pictures 404', async () => {
    const c = (await newChallenge()).json();
    const img = await ctx.app.inject({ method: 'GET', url: c.options[0].imageUrl });
    expect(img.statusCode).toBe(200);
    expect(img.headers['content-type']).toContain('image/png');
    expect(img.headers['content-security-policy']).toContain("default-src 'none'");
    expect([...img.rawPayload.subarray(0, 8)]).toEqual([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]); // a real PNG

    for (const url of [
      `/v1/captcha/challenges/${c.id}/images/AAAAAAAAAAAA.png`,
      `/v1/captcha/challenges/nope/images/${c.options[0].id}.png`,
    ]) expect((await ctx.app.inject({ method: 'GET', url })).statusCode).toBe(404);
    expect((await ctx.app.inject({ method: 'GET', url: `/v1/captcha/challenges/${c.id}/images/../../x.png` })).statusCode).toBeGreaterThanOrEqual(400);
  });

  it('every generated challenge of every kind has exactly one correct picture', async () => {
    const kinds = new Set<string>();
    for (let i = 0; i < 80; i++) {
      const id = (await newChallenge()).json().id as string;
      const row = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id } });
      const options = row.options as unknown as StoredOption[];
      kinds.add(row.kind);

      expect(options).toHaveLength(6);
      expect(new Set(options.map((o) => o.token)).size).toBe(6);
      const correct = options.find((o) => o.token === row.correctToken)!;
      expect(correct).toBeDefined();

      if (row.kind === 'FIND_TOY' || row.kind === 'FIND_OBJECT') {
        expect(ICONS[correct.icon]!.group).toBe(row.kind === 'FIND_TOY' ? 'toy' : 'object');
        expect(row.prompt).toBe(`${ICONS[correct.icon]!.fa} رو پیدا کن!`);
        expect(options.filter((o) => o.icon === correct.icon)).toHaveLength(1);
        for (const o of options) expect(compatible(o.icon, correct.icon)).toBe(true);
      } else if (row.kind === 'ODD_ONE_OUT') {
        expect(row.prompt).toBe('شکل متفاوت رو انتخاب کن!');
        expect(options.filter((o) => o.icon === correct.icon)).toHaveLength(1);
        const others = options.filter((o) => o.token !== correct.token);
        expect(new Set(others.map((o) => o.icon)).size).toBe(1);
        expect(others[0]!.icon).not.toBe(correct.icon);
      } else {
        expect(row.kind).toBe('FOLLOW_INSTRUCTION');
        expect(row.prompt).toBe(`${ICONS[correct.icon]!.fa} رو انتخاب کن!`);
        expect(options.filter((o) => o.icon === correct.icon)).toHaveLength(1);
        // All six look alike (one category) and no two names can be confused.
        expect(new Set(options.map((o) => ICONS[o.icon]!.category)).size).toBe(1);
        for (const o of options) expect(compatible(o.icon, correct.icon)).toBe(true);
      }
    }
    // All four challenge types are actually produced.
    expect([...kinds].sort()).toEqual(['FIND_OBJECT', 'FIND_TOY', 'FOLLOW_INSTRUCTION', 'ODD_ONE_OUT']);
  });

  it('identical icons never share the same image bytes', async () => {
    for (let i = 0; i < 60; i++) {
      const c = (await newChallenge()).json();
      const row = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: c.id } });
      if (row.kind !== 'ODD_ONE_OUT') continue;
      const options = row.options as unknown as StoredOption[];
      const common = options.filter((o) => o.token !== row.correctToken);
      const imgs = await Promise.all(common.slice(0, 2).map((o) => ctx.app.inject({ method: 'GET', url: `/v1/captcha/challenges/${c.id}/images/${o.token}.png` })));
      expect(imgs[0]!.rawPayload.equals(imgs[1]!.rawPayload)).toBe(false);
      return;
    }
    throw new Error('no ODD_ONE_OUT challenge produced in 60 tries');
  });

  it('a correct answer yields a pass; the answer is checked on the server only', async () => {
    const c = (await newChallenge()).json();
    const row = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: c.id } });
    const res = await answer(c.id, row.correctToken);
    expect(res.statusCode).toBe(200);
    expect(res.json()).toMatchObject({ passed: true, expiresInSeconds: 600 });
    expect(res.json().pass.length).toBeGreaterThan(40);

    const after = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: c.id } });
    expect(after.solved).toBe(true);
    expect(after.passHash).toMatch(/^[0-9a-f]{64}$/);
    expect(after.passHash).not.toContain(res.json().pass); // only an HMAC is stored
  });

  it('a wrong answer burns the challenge: no pass, no second guess, a fresh challenge is available', async () => {
    const c = (await newChallenge()).json();
    const row = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: c.id } });
    const wrong = c.options.find((o: { id: string }) => o.id !== row.correctToken).id;

    const bad = await answer(c.id, wrong);
    expect(bad.statusCode).toBe(422);
    expect(bad.json().error.code).toBe('CAPTCHA_WRONG');
    expect(bad.json().error.messageFa).toContain('چالش جدید');

    const retry = await answer(c.id, row.correctToken); // cannot guess again on the same challenge
    expect(retry.statusCode).toBe(409);
    expect(retry.json().error.code).toBe('CAPTCHA_ALREADY_ANSWERED');
    expect((await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: c.id } })).passHash).toBeNull();

    expect((await newChallenge()).statusCode).toBe(201); // "get a new challenge after a mistake"
  });

  it('rejects unknown, expired and forged answers; only one of many parallel answers wins', async () => {
    expect((await answer('does-not-exist', 'x'.repeat(16))).statusCode).toBe(404);

    const expired = (await newChallenge()).json();
    const eRow = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: expired.id } });
    await ctx.prisma.captchaChallenge.update({ where: { id: expired.id }, data: { expiresAt: new Date(Date.now() - 1000) } });
    const late = await answer(expired.id, eRow.correctToken);
    expect(late.statusCode).toBe(422);
    expect(late.json().error.code).toBe('CAPTCHA_EXPIRED');

    const c = (await newChallenge()).json();
    const row = await ctx.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: c.id } });
    const results = await Promise.all(Array.from({ length: 6 }, () => answer(c.id, row.correctToken)));
    expect(results.filter((r) => r.statusCode === 200)).toHaveLength(1);
    expect(await ctx.prisma.captchaChallenge.count({ where: { id: c.id, solved: true } })).toBe(1);
  });
});

describe('passes (one-time permission to continue sign-up)', () => {
  it('sign-up is refused without a pass or with an invalid one', async () => {
    const none = await ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: {} });
    expect(none.statusCode).toBe(400);
    expect(none.json().error.code).toBe('CAPTCHA_REQUIRED');

    const forged = await ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: 'f'.repeat(43) } });
    expect(forged.statusCode).toBe(422);
    expect(forged.json().error.code).toBe('INVALID_CAPTCHA_PASS');

    // A challenge that was never solved yields no usable pass.
    const c = (await newChallenge()).json();
    const unsolved = await ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: c.id.padEnd(43, 'x') } });
    expect(unsolved.statusCode).toBe(422);
    expect(await ctx.prisma.user.count()).toBe(0);
  });

  it('is single use: the server consumes it when the account is created', async () => {
    const pass = await getPass(ctx);
    const first = await ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: pass } });
    expect(first.statusCode).toBe(201);
    const replay = await ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: pass } });
    expect(replay.statusCode).toBe(422);
    expect(replay.json().error.code).toBe('INVALID_CAPTCHA_PASS');
    expect(await ctx.prisma.user.count()).toBe(1);
  });

  it('only one of many simultaneous sign-ups with the same pass succeeds', async () => {
    const pass = await getPass(ctx);
    const results = await Promise.all(
      Array.from({ length: 6 }, () => ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: pass } })),
    );
    expect(results.filter((r) => r.statusCode === 201)).toHaveLength(1);
    expect(await ctx.prisma.user.count()).toBe(1);
  });

  it('expires quickly', async () => {
    const pass = await getPass(ctx);
    await ctx.prisma.captchaChallenge.updateMany({ where: { solved: true }, data: { passExpiresAt: new Date(Date.now() - 1000) } });
    const res = await ctx.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: pass } });
    expect(res.statusCode).toBe(422);
  });

  it('is not wasted by a failed sign-up: it still works for a retry (e.g. username taken)', async () => {
    const mk = async (username: string, pass: string) =>
      ctx.app.inject({ method: 'POST', url: '/v1/auth/register', payload: { username, email: `${username}@example.test`, password: TEST_PASSWORD, captchaPass: pass } });
    expect((await mk('taken_name', await getPass(ctx))).statusCode).toBe(201);

    const pass = await getPass(ctx);
    const clash = await mk('taken_name', pass);
    expect(clash.statusCode).toBe(409);
    const retry = await mk('free_name', pass);
    expect(retry.statusCode).toBe(201);
    expect((await mk('another_one', pass)).statusCode).toBe(422); // now it is used up
  });

  it('the legacy password sign-up also requires a pass', async () => {
    const res = await ctx.app.inject({
      method: 'POST',
      url: '/v1/auth/register',
      payload: { username: 'nopass', email: 'nopass@example.test', password: TEST_PASSWORD },
    });
    expect(res.statusCode).toBe(400);
    expect(res.json().error.code).toBe('CAPTCHA_REQUIRED');
  });
});

describe('abuse controls', () => {
  it('stops handing out challenges after repeated wrong answers from one network', async () => {
    const limited = await createTestContext({ env: { CAPTCHA_FAIL_LIMIT_PER_10_MIN: '3' } });
    try {
      await resetDb(limited.prisma);
      for (let i = 0; i < 3; i++) {
        const c = (await limited.app.inject({ method: 'POST', url: '/v1/captcha/challenges' })).json();
        const row = await limited.prisma.captchaChallenge.findUniqueOrThrow({ where: { id: c.id } });
        const wrong = c.options.find((o: { id: string }) => o.id !== row.correctToken).id;
        expect((await limited.app.inject({ method: 'POST', url: `/v1/captcha/challenges/${c.id}/answer`, payload: { optionId: wrong } })).statusCode).toBe(422);
      }
      const blocked = await limited.app.inject({ method: 'POST', url: '/v1/captcha/challenges' });
      expect(blocked.statusCode).toBe(429);
      expect(blocked.json().error.code).toBe('TOO_MANY_CAPTCHA_FAILURES');
      expect(blocked.headers['retry-after']).toBeDefined();
      expect(blocked.json().error.messageFa).toContain('صبر');
    } finally {
      await limited.close();
    }
  });

  it('caps new accounts per network per hour, for every sign-up method', async () => {
    const limited = await createTestContext({ env: { ACCOUNT_CREATE_PER_IP_HOUR: '3' } });
    try {
      await resetDb(limited.prisma);
      for (let i = 0; i < 3; i++) await createGuest(limited);
      const pass = await getPass(limited);
      const blocked = await limited.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: { captchaPass: pass } });
      expect(blocked.statusCode).toBe(429);
      expect(blocked.json().error.code).toBe('TOO_MANY_ACCOUNTS');
      expect(await limited.prisma.user.count()).toBe(3);
      // The pass was not burned by the refusal.
      expect(await limited.prisma.captchaChallenge.count({ where: { solved: true, passConsumedAt: null } })).toBe(1);

      const legacy = await limited.app.inject({
        method: 'POST',
        url: '/v1/auth/register',
        payload: { username: 'late_comer', email: 'late@example.test', password: TEST_PASSWORD, captchaPass: pass },
      });
      expect(legacy.statusCode).toBe(429);
    } finally {
      await limited.close();
    }
  });

  it('can be switched off for development only (never in production)', async () => {
    const open = await createTestContext({ env: { ANTIBOT_ENABLED: 'false' } });
    try {
      await resetDb(open.prisma);
      const res = await open.app.inject({ method: 'POST', url: '/v1/auth/guest', payload: {} });
      expect(res.statusCode).toBe(201);
    } finally {
      await open.close();
    }
  });
});
