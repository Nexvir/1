import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import type { GoogleVerifier } from '../src/auth/google';
import { changeWallet } from '../src/modules/wallet/service';
import {
  Outbox,
  bearer,
  createGuest,
  createTestContext,
  getPass,
  registerUser,
  resetDb,
  type TestContext,
} from './helpers';

const fakeGoogle: GoogleVerifier = {
  async verify(token: string) {
    if (token.startsWith('good-')) return { sub: token.slice(5) };
    throw new Error('not a valid google token');
  },
};
const gToken = (sub: string) => `good-${sub}`.padEnd(30, '0');
const gSub = (sub: string) => gToken(sub).slice(5);

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext({ googleVerifier: fakeGoogle });
});
afterAll(async () => ctx.close());
beforeEach(async () => {
  await resetDb(ctx.prisma);
  ctx.outbox.sms.length = 0;
  ctx.outbox.email.length = 0;
});

const otpRequest = (channel: 'PHONE' | 'EMAIL', destination: string, captchaPass?: string) =>
  ctx.app.inject({ method: 'POST', url: '/v1/auth/otp/request', payload: { channel, destination, captchaPass } });
const otpVerify = (channel: 'PHONE' | 'EMAIL', destination: string, code: string, captchaPass?: string) =>
  ctx.app.inject({ method: 'POST', url: '/v1/auth/otp/verify', payload: { channel, destination, code, captchaPass } });

/** Full phone flow: solve challenge, request code, verify. */
async function phoneLogin(phone: string) {
  const pass = await getPass(ctx);
  expect((await otpRequest('PHONE', phone, pass)).statusCode).toBe(200);
  return otpVerify('PHONE', phone, ctx.outbox.lastSms().code, pass);
}

describe('methods', () => {
  it('reports honestly which methods are available', async () => {
    const res = await ctx.app.inject({ method: 'GET', url: '/v1/auth/methods' });
    expect(res.json()).toMatchObject({
      guest: { available: true },
      google: { available: true },
      email: { available: true },
      phone: { available: true },
      antibot: { required: true },
    });

    const bare = await createTestContext({ deliveries: { email: null, sms: null }, googleVerifier: null });
    try {
      const r = await bare.app.inject({ method: 'GET', url: '/v1/auth/methods' });
      expect(r.json()).toMatchObject({ guest: { available: true }, google: { available: false }, email: { available: false }, phone: { available: false } });
    } finally {
      await bare.close();
    }
  });

  it('never fakes success when SMS / e-mail / Google are not configured', async () => {
    const bare = await createTestContext({ deliveries: { email: null, sms: null }, googleVerifier: null });
    try {
      await resetDb(bare.prisma);
      const pass = await getPass(bare);
      const sms = await bare.app.inject({ method: 'POST', url: '/v1/auth/otp/request', payload: { channel: 'PHONE', destination: '09123456789', captchaPass: pass } });
      expect(sms.statusCode).toBe(503);
      expect(sms.json().error.code).toBe('SMS_NOT_CONFIGURED');
      expect(sms.json().error.messageFa).toContain('در دسترس نیست');
      const mail = await bare.app.inject({ method: 'POST', url: '/v1/auth/otp/request', payload: { channel: 'EMAIL', destination: 'a@example.test', captchaPass: pass } });
      expect(mail.json().error.code).toBe('EMAIL_NOT_CONFIGURED');
      const google = await bare.app.inject({ method: 'POST', url: '/v1/auth/google', payload: { idToken: gToken('x') } });
      expect(google.statusCode).toBe(503);
      expect(google.json().error.code).toBe('GOOGLE_NOT_CONFIGURED');

      // Nothing was created or consumed.
      expect(await bare.prisma.otpCode.count()).toBe(0);
      expect(await bare.prisma.user.count()).toBe(0);
      expect(await bare.prisma.captchaChallenge.count({ where: { passConsumedAt: { not: null }, passOtpSends: { gt: 0 } } })).toBe(0);
    } finally {
      await bare.close();
    }
  });
});

describe('phone sign-in / sign-up', () => {
  it('creates the account on first verified code and signs into the SAME one afterwards', async () => {
    const first = await phoneLogin('0912 345 6789');
    expect(first.statusCode).toBe(201);
    expect(first.json()).toMatchObject({ isNewAccount: true, account: { isGuest: false } });
    expect(ctx.outbox.sms[0]!.to).toBe('+989123456789'); // normalized before sending
    expect(ctx.outbox.sms[0]!.code).toMatch(/^\d{6}$/);

    const second = await phoneLogin('+98 912 345 6789');
    expect(second.statusCode).toBe(200);
    expect(second.json().isNewAccount).toBe(false);
    expect(second.json().account.id).toBe(first.json().account.id);
    expect(await ctx.prisma.user.count()).toBe(1); // no duplicate account
    expect(await ctx.prisma.authIdentity.count()).toBe(1);

    const me = await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: { authorization: `Bearer ${second.json().tokens.accessToken}` } });
    expect(me.json().wallet.balance).toBe(500);
  });

  it('requires a solved picture challenge before any SMS is sent', async () => {
    const none = await otpRequest('PHONE', '09123456789');
    expect(none.statusCode).toBe(400);
    expect(none.json().error.code).toBe('CAPTCHA_REQUIRED');
    const forged = await otpRequest('PHONE', '09123456789', 'f'.repeat(43));
    expect(forged.statusCode).toBe(422);
    expect(ctx.outbox.sms).toHaveLength(0);
    expect(await ctx.prisma.otpCode.count()).toBe(0);
  });

  it('rejects malformed numbers with a friendly message', async () => {
    const res = await otpRequest('PHONE', '12345', await getPass(ctx));
    expect(res.statusCode).toBe(400);
    expect(res.json().error.code).toBe('INVALID_PHONE');
    expect(res.json().error.messageFa).toContain('09123456789');
  });

  it('replies identically whether or not an account exists (no enumeration)', async () => {
    await phoneLogin('09123456789');
    const known = await otpRequest('PHONE', '09123456789', await getPass(ctx));
    const unknown = await otpRequest('PHONE', '09350000000', await getPass(ctx));
    expect(known.statusCode).toBe(unknown.statusCode);
    expect(known.json()).toEqual(unknown.json());
  });

  it('stores only HMACs of the code and the number', async () => {
    const pass = await getPass(ctx);
    await otpRequest('PHONE', '09123456789', pass);
    const { code } = ctx.outbox.lastSms();
    const row = await ctx.prisma.otpCode.findFirstOrThrow();
    expect(row.codeHash).toMatch(/^[0-9a-f]{64}$/);
    expect(row.destinationHash).toMatch(/^[0-9a-f]{64}$/);
    const dump = JSON.stringify({ otp: await ctx.prisma.otpCode.findMany(), events: await ctx.prisma.securityEvent.findMany() });
    expect(dump).not.toContain(code);
    expect(dump).not.toContain('9123456789');
  });

  it('a wrong code fails, the right one still works, and the code is single use', async () => {
    const pass = await getPass(ctx);
    await otpRequest('PHONE', '09123456789', pass);
    const { code } = ctx.outbox.lastSms();
    const wrong = code === '000000' ? '111111' : '000000';

    const bad = await otpVerify('PHONE', '09123456789', wrong, pass);
    expect(bad.statusCode).toBe(422);
    expect(bad.json().error.code).toBe('INVALID_OTP');
    expect(bad.json().error.messageFa).toContain('کد');

    expect((await otpVerify('PHONE', '09123456789', code, pass)).statusCode).toBe(201);
    const reuse = await otpVerify('PHONE', '09123456789', code, pass);
    expect(reuse.statusCode).toBe(422); // already used
  });

  it('allows only a few attempts per code, then even the right code is refused', async () => {
    const pass = await getPass(ctx);
    await otpRequest('PHONE', '09123456789', pass);
    const { code } = ctx.outbox.lastSms();
    const wrong = code === '000000' ? '111111' : '000000';
    for (let i = 0; i < 5; i++) expect((await otpVerify('PHONE', '09123456789', wrong, pass)).statusCode).toBe(422);

    const locked = await otpVerify('PHONE', '09123456789', code, pass);
    expect(locked.statusCode).toBe(429);
    expect(locked.json().error.code).toBe('OTP_ATTEMPTS_EXCEEDED');
    expect(await ctx.prisma.user.count()).toBe(0);
  });

  it('expires codes', async () => {
    const pass = await getPass(ctx);
    await otpRequest('PHONE', '09123456789', pass);
    await ctx.prisma.otpCode.updateMany({ data: { expiresAt: new Date(Date.now() - 1000) } });
    const res = await otpVerify('PHONE', '09123456789', ctx.outbox.lastSms().code, pass);
    expect(res.statusCode).toBe(422);
    expect(res.json().error.code).toBe('INVALID_OTP');
  });

  it('only the newest code for a number is valid', async () => {
    const pass = await getPass(ctx);
    await otpRequest('PHONE', '09123456789', pass);
    const old = ctx.outbox.lastSms().code;
    await otpRequest('PHONE', '09123456789', pass);
    const fresh = ctx.outbox.lastSms().code;
    if (old !== fresh) expect((await otpVerify('PHONE', '09123456789', old, pass)).statusCode).toBe(422);
    expect((await otpVerify('PHONE', '09123456789', fresh, pass)).statusCode).toBe(201);
  });

  it('binds a code to the picture-challenge pass that authorised it', async () => {
    const passA = await getPass(ctx);
    const passB = await getPass(ctx);
    await otpRequest('PHONE', '09123456789', passA);
    const { code } = ctx.outbox.lastSms();

    const none = await otpVerify('PHONE', '09123456789', code);
    expect(none.json().error.code).toBe('CAPTCHA_REQUIRED');
    const swapped = await otpVerify('PHONE', '09123456789', code, passB);
    expect(swapped.statusCode).toBe(422);
    expect(swapped.json().error.code).toBe('INVALID_CAPTCHA_PASS');
    expect(await ctx.prisma.user.count()).toBe(0); // nothing half-created

    expect((await otpVerify('PHONE', '09123456789', code, passA)).statusCode).toBe(201); // still redeemable
    // The pass is spent: it cannot trigger another code.
    const again = await otpRequest('PHONE', '09350000000', passA);
    expect(again.statusCode).toBe(422);
  });

  it('one pass can trigger only a few codes (no SMS pumping with a single solved puzzle)', async () => {
    const pass = await getPass(ctx);
    for (let i = 0; i < 3; i++) expect((await otpRequest('PHONE', `0912000000${i}`, pass)).statusCode).toBe(200);
    const fourth = await otpRequest('PHONE', '09120000009', pass);
    expect(fourth.statusCode).toBe(422);
    expect(fourth.json().error.code).toBe('INVALID_CAPTCHA_PASS');
    expect(ctx.outbox.sms).toHaveLength(3);
  });

  it('enforces resend cooldown, per-number and per-network hourly caps', async () => {
    const cool = await createTestContext({ env: { OTP_RESEND_COOLDOWN_SECONDS: '60' } });
    const dest = await createTestContext({ env: { OTP_MAX_PER_DESTINATION_HOUR: '2' } });
    const net = await createTestContext({ env: { OTP_MAX_PER_IP_HOUR: '2' } });
    try {
      await resetDb(ctx.prisma);
      const call = (c: TestContext, phone: string, pass: string) =>
        c.app.inject({ method: 'POST', url: '/v1/auth/otp/request', payload: { channel: 'PHONE', destination: phone, captchaPass: pass } });

      expect((await call(cool, '09123456789', await getPass(cool))).statusCode).toBe(200);
      const tooSoon = await call(cool, '09123456789', await getPass(cool));
      expect(tooSoon.statusCode).toBe(429);
      expect(tooSoon.json().error.code).toBe('OTP_COOLDOWN');
      expect(tooSoon.headers['retry-after']).toBeDefined();
      expect(cool.outbox.sms).toHaveLength(1);

      await resetDb(ctx.prisma);
      for (let i = 0; i < 2; i++) expect((await call(dest, '09123456789', await getPass(dest))).statusCode).toBe(200);
      const capped = await call(dest, '09123456789', await getPass(dest));
      expect(capped.statusCode).toBe(429);
      expect(capped.json().error.code).toBe('OTP_LIMIT_REACHED');
      expect((await call(dest, '09350000000', await getPass(dest))).statusCode).toBe(200); // other numbers unaffected

      await resetDb(ctx.prisma);
      for (const phone of ['09121111111', '09122222222']) expect((await call(net, phone, await getPass(net))).statusCode).toBe(200);
      expect((await call(net, '09123333333', await getPass(net))).statusCode).toBe(429);
    } finally {
      await cool.close();
      await dest.close();
      await net.close();
    }
  });

  it('tells the player when delivery fails and leaves no live code behind', async () => {
    ctx.outbox.failNext = true;
    const res = await otpRequest('PHONE', '09123456789', await getPass(ctx));
    expect(res.statusCode).toBe(502);
    expect(res.json().error.code).toBe('DELIVERY_FAILED');
    expect(await ctx.prisma.otpCode.count()).toBe(0);
  });

  it('keeps the phone number out of every public surface', async () => {
    const user = await phoneLogin('09123456789');
    const token = user.json().tokens.accessToken as string;
    const username = user.json().account.username as string;
    const viewer = await registerUser(ctx, 'some_viewer');

    const surfaces = [
      await ctx.app.inject({ method: 'GET', url: `/v1/users/${username}`, headers: bearer(viewer) }),
      await ctx.app.inject({ method: 'GET', url: '/v1/users/search?q=player', headers: bearer(viewer) }),
      await ctx.app.inject({ method: 'GET', url: '/v1/leaderboards/wealth', headers: bearer(viewer) }),
      await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: { authorization: `Bearer ${token}` } }),
    ];
    for (const s of surfaces) {
      expect(s.statusCode).toBe(200);
      expect(s.body).not.toContain('9123456789');
    }
    // The owner sees only a masked form.
    const account = await ctx.app.inject({ method: 'GET', url: '/v1/auth/account', headers: { authorization: `Bearer ${token}` } });
    expect(account.json().linked).toEqual([{ provider: 'PHONE', masked: '+9891***6789' }]);
  });

  it('refuses suspended accounts', async () => {
    await phoneLogin('09123456789');
    await ctx.prisma.user.updateMany({ data: { status: 'SUSPENDED' } });
    const res = await phoneLogin('09123456789');
    expect(res.statusCode).toBe(403);
    expect(res.json().error.code).toBe('ACCOUNT_SUSPENDED');
  });
});

describe('e-mail code sign-in / sign-up (passwordless)', () => {
  it('signs up and in with a code, normalizing the address', async () => {
    const pass = await getPass(ctx);
    expect((await otpRequest('EMAIL', ' Player@Example.COM ', pass)).statusCode).toBe(200);
    expect(ctx.outbox.email[0]!.to).toBe('player@example.com');
    const first = await otpVerify('EMAIL', 'player@example.com', ctx.outbox.lastEmail().code, pass);
    expect(first.statusCode).toBe(201);

    const pass2 = await getPass(ctx);
    await otpRequest('EMAIL', 'PLAYER@example.com', pass2);
    const second = await otpVerify('EMAIL', 'player@example.com', ctx.outbox.lastEmail().code, pass2);
    expect(second.statusCode).toBe(200);
    expect(second.json().account.id).toBe(first.json().account.id);
    expect(await ctx.prisma.user.count()).toBe(1);
  });

  it('rejects an invalid address and a phone code used for e-mail (channels are separate)', async () => {
    const bad = await otpRequest('EMAIL', 'not-an-email', await getPass(ctx));
    expect(bad.statusCode).toBe(400);

    const pass = await getPass(ctx);
    await otpRequest('PHONE', '09123456789', pass);
    const res = await otpVerify('EMAIL', 'a@example.test', ctx.outbox.lastSms().code, pass);
    expect(res.statusCode).toBe(422);
  });

  it('does not take over an account made with the unverified legacy e-mail/password sign-up', async () => {
    const victim = await registerUser(ctx, 'legacy_user'); // legacy_user@example.test, never verified
    const pass = await getPass(ctx);
    await otpRequest('EMAIL', 'legacy_user@example.test', pass);
    const res = await otpVerify('EMAIL', 'legacy_user@example.test', ctx.outbox.lastEmail().code, pass);
    expect(res.statusCode).toBe(201);
    expect(res.json().isNewAccount).toBe(true);
    expect(res.json().account.id).not.toBe(victim.id); // separate account, no silent merge
  });
});

describe('Google sign-in', () => {
  const google = (idToken: string, captchaPass?: string, extra: Record<string, unknown> = {}) =>
    ctx.app.inject({ method: 'POST', url: '/v1/auth/google', payload: { idToken, captchaPass, ...extra } });

  it('verifies the token on the server; creating an account needs a pass, signing in does not', async () => {
    const noPass = await google(gToken('alice'));
    expect(noPass.statusCode).toBe(400);
    expect(noPass.json().error.code).toBe('CAPTCHA_REQUIRED');

    const created = await google(gToken('alice'), await getPass(ctx));
    expect(created.statusCode).toBe(201);
    expect(created.json()).toMatchObject({ isNewAccount: true, account: { isGuest: false } });

    const again = await google(gToken('alice'));
    expect(again.statusCode).toBe(200);
    expect(again.json().account.id).toBe(created.json().account.id);
    expect(await ctx.prisma.user.count()).toBe(1);
  });

  it('rejects tokens Google would not vouch for', async () => {
    const bad = await google('forged-token-forged-token-forged', await getPass(ctx));
    expect(bad.statusCode).toBe(401);
    expect(bad.json().error.code).toBe('INVALID_GOOGLE_TOKEN');
    expect(await ctx.prisma.user.count()).toBe(0);
  });

  it('ignores identity details sent by the client; only the verified subject counts', async () => {
    const res = await google(gToken('real-subject'), await getPass(ctx), {
      sub: 'attacker-chosen-subject',
      email: 'victim@example.test',
      userId: 'someone-else',
      name: 'Admin',
    });
    expect(res.statusCode).toBe(201);
    const identity = await ctx.prisma.authIdentity.findFirstOrThrow();
    expect(identity).toMatchObject({ provider: 'GOOGLE', identifier: gSub('real-subject') });
    const user = await ctx.prisma.user.findUniqueOrThrow({ where: { id: res.json().account.id }, include: { profile: true } });
    expect(user.email).toBeNull();
    expect(user.profile?.displayName).not.toBe('Admin');
  });
});

describe('linking a permanent sign-in method to a guest account', () => {
  async function guestWithProgress() {
    const g = await createGuest(ctx);
    await ctx.prisma.userProfile.update({ where: { userId: g.id }, data: { xp: 700, trophies: 130 } });
    await changeWallet(ctx.prisma, { userId: g.id, amount: 250, kind: 'EARN', source: 'test', idempotencyKey: `link-earn-${g.id}` });
    return g;
  }

  const linkRequest = (g: { accessToken: string }, channel: 'PHONE' | 'EMAIL', destination: string) =>
    ctx.app.inject({ method: 'POST', url: '/v1/auth/link/otp/request', headers: bearer(g), payload: { channel, destination } });
  const linkVerify = (g: { accessToken: string }, channel: 'PHONE' | 'EMAIL', destination: string, code: string) =>
    ctx.app.inject({ method: 'POST', url: '/v1/auth/link/otp/verify', headers: bearer(g), payload: { channel, destination, code } });

  it('keeps the same account and all progress, creates no duplicate, and ends the guest policy', async () => {
    const g = await guestWithProgress();
    const users = await ctx.prisma.user.count();

    expect((await linkRequest(g, 'PHONE', '09123456789')).statusCode).toBe(200); // no picture challenge needed: already signed in
    const res = await linkVerify(g, 'PHONE', '09123456789', ctx.outbox.lastSms().code);
    expect(res.statusCode).toBe(200);
    expect(res.json()).toMatchObject({ linked: { provider: 'PHONE', masked: '+9891***6789' }, account: { id: g.id, accountCode: g.accountCode, isGuest: false } });

    expect(await ctx.prisma.user.count()).toBe(users); // no duplicate account
    const row = await ctx.prisma.user.findUniqueOrThrow({ where: { id: g.id }, include: { profile: true, wallet: true } });
    expect(row).toMatchObject({ id: g.id, accountCode: g.accountCode, isGuest: false });
    expect(row.guestConvertedAt).not.toBeNull();
    expect(row.profile).toMatchObject({ xp: 700, trophies: 130 });
    expect(row.wallet?.balance).toBe(750);

    // The new method signs into that same account.
    const login = await phoneLogin('09123456789');
    expect(login.statusCode).toBe(200);
    expect(login.json().account.id).toBe(g.id);

    // The recovery code still works for the same account.
    const rec = await ctx.app.inject({ method: 'POST', url: '/v1/auth/recover', payload: { accountCode: g.accountCode, recoveryCode: g.recoveryCode } });
    expect(rec.statusCode).toBe(200);

    const status = await ctx.app.inject({ method: 'GET', url: '/v1/auth/account', headers: bearer(g) });
    expect(status.json()).toMatchObject({ isGuest: false, guestExpiry: null });
    expect((await ctx.prisma.auditLog.findMany()).map((a) => a.action)).toContain('account.identity_linked');
  });

  it('links e-mail and Google the same way', async () => {
    const g = await guestWithProgress();
    await linkRequest(g, 'EMAIL', 'me@example.com');
    const mail = await linkVerify(g, 'EMAIL', 'me@example.com', ctx.outbox.lastEmail().code);
    expect(mail.json().linked).toEqual({ provider: 'EMAIL', masked: 'm***@example.com' });

    const gl = await ctx.app.inject({ method: 'POST', url: '/v1/auth/link/google', headers: bearer(g), payload: { idToken: gToken('guest-google') } });
    expect(gl.statusCode).toBe(200);
    expect(gl.json().linked.provider).toBe('GOOGLE');
    expect((await ctx.prisma.authIdentity.findMany({ where: { userId: g.id } })).map((i) => i.provider).sort()).toEqual(['EMAIL', 'GOOGLE']);
  });

  it('never merges accounts: a method that belongs to another account is refused and nothing changes', async () => {
    const owner = await phoneLogin('09123456789'); // account A owns this number
    const g = await guestWithProgress();
    const ownerId = owner.json().account.id as string;
    const before = await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId: g.id } });

    expect((await linkRequest(g, 'PHONE', '09123456789')).statusCode).toBe(200);
    const res = await linkVerify(g, 'PHONE', '09123456789', ctx.outbox.lastSms().code);
    expect(res.statusCode).toBe(409);
    expect(res.json().error.code).toBe('IDENTITY_IN_USE');
    expect(res.json().error.messageFa).toContain('ادغام');

    // Both accounts are exactly as they were.
    expect(await ctx.prisma.user.count()).toBe(2);
    const guest = await ctx.prisma.user.findUniqueOrThrow({ where: { id: g.id } });
    expect(guest.isGuest).toBe(true);
    expect(await ctx.prisma.authIdentity.count({ where: { userId: g.id } })).toBe(0);
    expect(await ctx.prisma.authIdentity.count({ where: { userId: ownerId } })).toBe(1);
    expect(await ctx.prisma.wallet.findUniqueOrThrow({ where: { userId: g.id } })).toMatchObject({ balance: before.balance });
    expect((await ctx.prisma.securityEvent.findMany()).map((e) => e.type)).toContain('IDENTITY_LINK_CONFLICT');

    // Same for Google.
    await google_link(owner.json().tokens.accessToken, 'shared-google');
    const clash = await ctx.app.inject({ method: 'POST', url: '/v1/auth/link/google', headers: bearer(g), payload: { idToken: gToken('shared-google') } });
    expect(clash.statusCode).toBe(409);
    expect(clash.json().error.code).toBe('IDENTITY_IN_USE');
  });

  async function google_link(accessToken: string, sub: string) {
    const r = await ctx.app.inject({ method: 'POST', url: '/v1/auth/link/google', headers: { authorization: `Bearer ${accessToken}` }, payload: { idToken: gToken(sub) } });
    expect(r.statusCode).toBe(200);
  }

  it('refuses a second method of the same kind and requires a signed-in session', async () => {
    const g = await guestWithProgress();
    await linkRequest(g, 'PHONE', '09123456789');
    await linkVerify(g, 'PHONE', '09123456789', ctx.outbox.lastSms().code);
    const second = await linkRequest(g, 'PHONE', '09350000000');
    expect(second.statusCode).toBe(409);
    expect(second.json().error.code).toBe('ALREADY_LINKED');

    expect((await ctx.app.inject({ method: 'POST', url: '/v1/auth/link/otp/request', payload: { channel: 'PHONE', destination: '09123456789' } })).statusCode).toBe(401);
    expect((await ctx.app.inject({ method: 'POST', url: '/v1/auth/link/google', payload: { idToken: gToken('x') } })).statusCode).toBe(401);
  });

  it("a link code can only be redeemed by the account that asked for it", async () => {
    const g = await guestWithProgress();
    const other = await createGuest(ctx);
    await linkRequest(g, 'PHONE', '09123456789');
    const code = ctx.outbox.lastSms().code;
    const stolen = await linkVerify(other, 'PHONE', '09123456789', code);
    expect(stolen.statusCode).toBe(422);
    expect(await ctx.prisma.authIdentity.count()).toBe(0);
    expect((await linkVerify(g, 'PHONE', '09123456789', code)).statusCode).toBe(200);
  });

  it('link codes are not valid for sign-in and sign-in codes are not valid for linking', async () => {
    const g = await guestWithProgress();
    await linkRequest(g, 'PHONE', '09123456789');
    const linkCode = ctx.outbox.lastSms().code;
    const pass = await getPass(ctx);
    const asLogin = await otpVerify('PHONE', '09123456789', linkCode, pass);
    expect(asLogin.statusCode).toBe(422);
    expect(await ctx.prisma.user.count()).toBe(1);
    void Outbox;
  });
});
