// Runs before every test file. Configures a throwaway environment.
// The database MUST be a dedicated test database: tests truncate every table.

process.env.NODE_ENV = 'test';
process.env.LOG_LEVEL = 'silent';
process.env.DATABASE_URL =
  process.env.TEST_DATABASE_URL ?? 'postgresql://nox:nox_dev_pw@localhost:5432/nox_test?schema=public';
process.env.JWT_ACCESS_SECRET = 'test-only-secret-test-only-secret-test-only-secret';
process.env.SERVER_PEPPER = 'test-only-pepper-test-only-pepper-test-only-pepper';
process.env.AUTH_RATE_LIMIT_MAX = '10000';
process.env.RATE_LIMIT_MAX = '100000';
process.env.WELCOME_BONUS_COINS = '500';
// Generous caps so unrelated tests never trip them; abuse tests lower them explicitly.
process.env.ACCOUNT_CREATE_PER_IP_HOUR = '100000';
process.env.CAPTCHA_FAIL_LIMIT_PER_10_MIN = '100000';
process.env.OTP_MAX_PER_IP_HOUR = '100000';
process.env.OTP_RESEND_COOLDOWN_SECONDS = '0';
process.env.RECOVERY_FAILED_PER_IP_15_MIN = '100000';
process.env.JOBS_ENABLED = 'false';
