import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { runAuthMaintenance, runGuestCleanup } from '../src/jobs/guestCleanup';
import { addMonthsUtc } from '../src/modules/accounts/activity';
import { changeWallet } from '../src/modules/wallet/service';
import { bearer, createGuest, createTestContext, getPass, registerUser, resetDb, type TestContext } from './helpers';

let ctx: TestContext;
beforeAll(async () => {
  ctx = await createTestContext();
});
afterAll(async () => ctx.close());
beforeEach(async () => resetDb(ctx.prisma));

const NOW = new Date('2026-10-15T12:00:00.000Z');
const monthsAgo = (m: number, extraDays = 0) => new Date(addMonthsUtc(NOW, -m).getTime() - extraDays * 86_400_000);

async function setActivity(userId: string, at: Date, createdAt?: Date) {
  await ctx.prisma.user.update({ where: { id: userId }, data: { lastActivityAt: at, ...(createdAt ? { createdAt } : {}) } });
}
const exists = async (id: string) => (await ctx.prisma.user.count({ where: { id } })) === 1;

describe('guest cleanup: 9-month inactivity', () => {
  it('deletes at the 9-month boundary and not a moment before', async () => {
    const before = await createGuest(ctx);
    const exact = await createGuest(ctx);
    await setActivity(before.id, new Date(addMonthsUtc(NOW, -9).getTime() + 60_000));
    await setActivity(exact.id, addMonthsUtc(NOW, -9));

    const res = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW });
    expect(res).toMatchObject({ candidates: 1, deleted: 1, failed: 0 });
    expect(await exists(before.id)).toBe(true);
    expect(await exists(exact.id)).toBe(false);
  });

  it('measures from last activity, not from creation date', async () => {
    const old = await createGuest(ctx);
    await setActivity(old.id, monthsAgo(1), monthsAgo(24)); // created 2 years ago, active last month
    const res = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW });
    expect(res.deleted).toBe(0);
    expect(await exists(old.id)).toBe(true);
  });

  it('exempts linked accounts, accounts with an identity, suspended accounts and clan owners', async () => {
    const stale = monthsAgo(12);
    const linked = await createGuest(ctx);
    await ctx.prisma.user.update({ where: { id: linked.id }, data: { isGuest: false, lastActivityAt: stale } });
    const withIdentity = await createGuest(ctx);
    await ctx.prisma.authIdentity.create({ data: { userId: withIdentity.id, provider: 'GOOGLE', identifier: 'sub-1' } });
    await setActivity(withIdentity.id, stale);
    const suspended = await createGuest(ctx);
    await ctx.prisma.user.update({ where: { id: suspended.id }, data: { status: 'SUSPENDED', lastActivityAt: stale } });
    const owner = await createGuest(ctx);
    const clan = await ctx.prisma.clan.create({ data: { name: 'Keepers', tag: 'KEEP' } });
    await ctx.prisma.clanMembership.create({ data: { clanId: clan.id, userId: owner.id, role: 'OWNER' } });
    await setActivity(owner.id, stale);
    const legacy = await registerUser(ctx, 'legacy_old'); // password account, not a guest
    await setActivity(legacy.id, stale);

    const res = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW });
    expect(res).toMatchObject({ candidates: 0, deleted: 0 });
    for (const u of [linked, withIdentity, suspended, owner, legacy]) expect(await exists(u.id)).toBe(true);
  });

  it('archives financial records, writes tombstone, audit log and security event; removes personal rows', async () => {
    const g = await createGuest(ctx);
    await changeWallet(ctx.prisma, { userId: g.id, amount: 300, kind: 'EARN', source: 'test', idempotencyKey: `cl-${g.id}` });
    await ctx.prisma.userProfile.update({ where: { userId: g.id }, data: { xp: 700 } });
    await setActivity(g.id, monthsAgo(10));

    const res = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW });
    expect(res.deleted).toBe(1);
    expect(await exists(g.id)).toBe(false);
    expect(await ctx.prisma.userProfile.count({ where: { userId: g.id } })).toBe(0);
    expect(await ctx.prisma.refreshToken.count({ where: { userId: g.id } })).toBe(0);

    const rec = await ctx.prisma.accountDeletionRecord.findFirstOrThrow({ where: { userId: g.id } });
    expect(rec).toMatchObject({ accountCode: g.accountCode, reason: 'guest_inactive' });
    expect((rec.snapshot as any).wallet.balance).toBe(800);
    expect((rec.snapshot as any).progress.xp).toBe(700);

    const ledger = await ctx.prisma.deletedAccountLedgerEntry.findMany({ where: { deletionId: rec.id } });
    expect(ledger.length).toBe(2); // welcome bonus + earn
    expect(ledger.every((l) => l.kind === 'WALLET_TRANSACTION')).toBe(true);
    expect((await ctx.prisma.auditLog.findMany()).map((a) => a.action)).toContain('account.guest_expired_deleted');
    expect(await ctx.prisma.securityEvent.count({ where: { type: 'GUEST_DELETED', userId: g.id } })).toBe(1);
    // The recovery code of a deleted account no longer works.
    const rec2 = await ctx.app.inject({ method: 'POST', url: '/v1/auth/recover', payload: { accountCode: g.accountCode, recoveryCode: g.recoveryCode } });
    expect(rec2.statusCode).toBe(401);
  });

  it('is idempotent, supports dry-run and respects the batch size', async () => {
    const a = await createGuest(ctx);
    const b = await createGuest(ctx);
    await setActivity(a.id, monthsAgo(11));
    await setActivity(b.id, monthsAgo(10));

    const dry = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW, dryRun: true });
    expect(dry).toMatchObject({ dryRun: true, candidates: 2, deleted: 0 });
    expect(await ctx.prisma.user.count()).toBe(2);

    const one = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW, batchSize: 1 });
    expect(one.deleted).toBe(1);
    expect(await exists(a.id)).toBe(false); // oldest activity first

    expect((await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW })).deleted).toBe(1);
    expect(await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW })).toMatchObject({ candidates: 0, deleted: 0 });
    expect(await ctx.prisma.accountDeletionRecord.count()).toBe(2);
  });

  it('skips an account that is locked by a concurrent request instead of deleting it', async () => {
    const g = await createGuest(ctx);
    await setActivity(g.id, monthsAgo(10));
    let result: Awaited<ReturnType<typeof runGuestCleanup>> | undefined;
    await ctx.prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT "id" FROM "User" WHERE "id" = ${g.id} FOR UPDATE`;
      result = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW });
    });
    expect(result).toMatchObject({ candidates: 1, deleted: 0, skipped: 1 });
    expect(await exists(g.id)).toBe(true);
  });

  it('keeps going when one account cannot be deleted', async () => {
    const stuck = await createGuest(ctx);
    const fine = await createGuest(ctx);
    await setActivity(stuck.id, monthsAgo(12));
    await setActivity(fine.id, monthsAgo(10));
    // Make deletion of the first fail with a constraint error.
    await ctx.prisma.$executeRawUnsafe(`ALTER TABLE "AccountDeletionRecord" ADD CONSTRAINT tmp_block CHECK ("accountCode" <> '${stuck.accountCode}') NOT VALID`);
    try {
      const res = await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW });
      expect(res).toMatchObject({ deleted: 1, failed: 1 });
      expect(await exists(stuck.id)).toBe(true);
      expect(await exists(fine.id)).toBe(false);
    } finally {
      await ctx.prisma.$executeRawUnsafe(`ALTER TABLE "AccountDeletionRecord" DROP CONSTRAINT tmp_block`);
    }
  });
});

describe('guest expiry warning and activity', () => {
  const recover = (g: { accountCode: string; recoveryCode: string }) =>
    ctx.app.inject({ method: 'POST', url: '/v1/auth/recover', payload: { accountCode: g.accountCode, recoveryCode: g.recoveryCode } });

  it('shows a warning (computed before the sign-in resets the clock) once, then not again', async () => {
    const g = await createGuest(ctx);
    // Deadline in ~10 days: inside the warning window.
    const nearDeadline = new Date(Date.now() - (addMonthsUtc(new Date(), 0).getTime() - addMonthsUtc(new Date(), -9).getTime()) + 10 * 86_400_000);
    await setActivity(g.id, nearDeadline);

    const first = await recover(g);
    expect(first.statusCode).toBe(200);
    expect(first.json().notice).toMatchObject({ type: 'GUEST_EXPIRY_WARNING' });
    expect(first.json().notice.daysLeft).toBeGreaterThan(0);
    expect(first.json().notice.messageFa).toContain('حساب')

    // The sign-in reset the clock, so the next one has no notice.
    const second = await recover({ accountCode: g.accountCode, recoveryCode: first.json().recoveryCode ?? g.recoveryCode });
    expect(second.json().notice).toBeUndefined();
    expect(await ctx.prisma.notification.count({ where: { userId: g.id, type: 'GUEST_EXPIRY_WARNING' } })).toBe(1);
    const fresh = await ctx.prisma.user.findUniqueOrThrow({ where: { id: g.id } });
    expect(Date.now() - fresh.lastActivityAt.getTime()).toBeLessThan(60_000);
  });

  it('no warning for a recently active guest or for a linked account', async () => {
    const g = await createGuest(ctx);
    const r = await recover(g);
    expect(r.json().notice).toBeUndefined();

    await ctx.prisma.user.update({ where: { id: g.id }, data: { isGuest: false, lastActivityAt: monthsAgo(12) } });
    const acct = await ctx.app.inject({ method: 'GET', url: '/v1/auth/account', headers: bearer(g) });
    expect(acct.json().guestExpiry).toBeNull();
  });

  it('authenticated API use refreshes lastActivityAt, at most once per hour', async () => {
    const g = await createGuest(ctx);
    await setActivity(g.id, monthsAgo(5));
    await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: bearer(g) });
    const t1 = (await ctx.prisma.user.findUniqueOrThrow({ where: { id: g.id } })).lastActivityAt;
    expect(Date.now() - t1.getTime()).toBeLessThan(60_000);

    await ctx.app.inject({ method: 'GET', url: '/v1/users/me', headers: bearer(g) });
    const t2 = (await ctx.prisma.user.findUniqueOrThrow({ where: { id: g.id } })).lastActivityAt;
    expect(t2.getTime()).toBe(t1.getTime()); // throttled
  });

  it('linking a method after the warning stops any deletion', async () => {
    const g = await createGuest(ctx);
    await ctx.app.inject({ method: 'POST', url: '/v1/auth/link/otp/request', headers: bearer(g), payload: { channel: 'PHONE', destination: '09123456789' } });
    const res = await ctx.app.inject({
      method: 'POST', url: '/v1/auth/link/otp/verify', headers: bearer(g),
      payload: { channel: 'PHONE', destination: '09123456789', code: ctx.outbox.lastSms().code },
    });
    expect(res.statusCode).toBe(200);
    await setActivity(g.id, monthsAgo(30));
    expect((await runGuestCleanup(ctx.prisma, ctx.config, { now: NOW })).candidates).toBe(0);
    expect(await exists(g.id)).toBe(true);
  });
});

describe('auth maintenance', () => {
  it('purges only stale short-lived rows and never security events or deletion records', async () => {
    await getPass(ctx);
    await ctx.prisma.securityEvent.create({ data: { type: 'TEST_EVENT' } });
    const eventsBefore = await ctx.prisma.securityEvent.count();
    const far = new Date(Date.now() + 3 * 86_400_000);
    const out = await runAuthMaintenance(ctx.prisma, far);
    expect(out.captchaChallenges).toBeGreaterThanOrEqual(1);
    expect(await ctx.prisma.securityEvent.count()).toBe(eventsBefore);
  });
});
