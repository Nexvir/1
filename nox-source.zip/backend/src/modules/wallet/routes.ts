import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../../auth/plugin';
import { Errors } from '../../errors';
import { getWalletSummary } from './service';
import { applyWalletChange } from './service';
import { randomUUID } from 'node:crypto';
import { blockState } from '../social/service';
import { createNotification } from '../notifications/service';

const listQuery = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(20),
  cursor: z.string().min(1).max(64).optional(),
});
const giftSchema = z.object({ username: z.string().trim().toLowerCase().min(3).max(20), amount: z.number().int().min(1).max(100_000) });

export async function walletRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: app.authenticate };

  app.get('/', auth, async (req) => getWalletSummary(app.prisma, requireAuth(req).userId));

  app.get('/transactions', auth, async (req) => {
    const { userId } = requireAuth(req);
    const q = listQuery.parse(req.query);
    const rows = await app.prisma.walletTransaction.findMany({
      where: { userId },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      take: q.limit + 1,
      ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
      select: { id: true, amount: true, kind: true, source: true, refId: true, balanceAfter: true, createdAt: true },
    });
    const page = rows.slice(0, q.limit);
    return { items: page, nextCursor: rows.length > q.limit ? (page[page.length - 1]?.id ?? null) : null };
  });

  // Real-money coin purchases need a verified payment provider, which is not integrated.
  // The endpoint exists so clients can show an honest "unavailable" state.
  app.post('/coin-purchases', auth, async () => {
    throw Errors.notImplemented(
      'PAYMENTS_UNAVAILABLE',
      'Coin purchases are not available: no payment provider is configured',
    );
  });

  app.post('/gifts', { ...auth, config: { rateLimit: { max: 30, timeWindow: '1 minute' } } }, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { username, amount } = giftSchema.parse(req.body);
    const target = await app.prisma.user.findUnique({ where: { username }, select: { id: true, status: true } });
    if (!target || target.status !== 'ACTIVE') throw Errors.notFound('USER_NOT_FOUND', 'User not found');
    if (target.id === userId) throw Errors.badRequest('CANNOT_GIFT_SELF', 'You cannot send a gift to yourself');
    const blocks = await blockState(app.prisma, userId, target.id);
    if (blocks.bBlockedA) throw Errors.notFound('USER_NOT_FOUND', 'User not found');
    if (blocks.aBlockedB) throw Errors.forbidden('USER_BLOCKED', 'You cannot send a gift to this player');
    const key = `gift:${userId}:${target.id}:${randomUUID()}`;
    await app.prisma.$transaction(async (tx) => {
      await applyWalletChange(tx, { userId, amount: -amount, kind: 'SPEND', source: 'player_gift', refId: target.id, idempotencyKey: `${key}:send` });
      await applyWalletChange(tx, { userId: target.id, amount, kind: 'PROMO', source: 'player_gift', refId: userId, idempotencyKey: `${key}:receive` });
      const sender = await tx.userProfile.findUnique({ where: { userId }, select: { displayName: true } });
      await createNotification(tx, { userId: target.id, type: 'GIFT_RECEIVED', title: 'هدیهٔ سکه دریافت کردی', body: `${sender?.displayName ?? 'یک بازیکن'} برایت ${amount} سکه فرستاد.`, data: { amount, fromUserId: userId } });
    });
    return reply.status(201).send({ sent: amount });
  });
}
