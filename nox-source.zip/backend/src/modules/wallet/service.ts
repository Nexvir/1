import { Prisma, PrismaClient, WalletTxKind } from '@prisma/client';
import type { DbClient } from '../../db';
import { Errors, isUniqueViolation } from '../../errors';

/** Largest balance a wallet may hold (keeps arithmetic safely inside Postgres int4). */
export const MAX_WALLET_BALANCE = 2_000_000_000;

export interface WalletChangeInput {
  userId: string;
  /** Signed, non-zero integer. SPEND must be negative; every other kind must be positive. */
  amount: number;
  kind: WalletTxKind;
  /** Machine-readable origin, e.g. "welcome_bonus", "match_reward", "store_purchase". */
  source: string;
  refId?: string;
  /** Replaying the same key never applies the change twice. */
  idempotencyKey: string;
}

export interface WalletChangeResult {
  transactionId: string;
  balanceAfter: number;
  replayed: boolean;
}

function validate(input: WalletChangeInput): void {
  if (!Number.isSafeInteger(input.amount) || input.amount === 0) {
    throw Errors.badRequest('INVALID_AMOUNT', 'Amount must be a non-zero integer');
  }
  if (Math.abs(input.amount) > MAX_WALLET_BALANCE) {
    throw Errors.badRequest('INVALID_AMOUNT', 'Amount is too large');
  }
  if (input.kind === 'SPEND' && input.amount > 0) {
    throw Errors.badRequest('INVALID_AMOUNT', 'SPEND entries must be negative');
  }
  if (input.kind !== 'SPEND' && input.amount < 0) {
    throw Errors.badRequest('INVALID_AMOUNT', `${input.kind} entries must be positive`);
  }
  if (input.idempotencyKey.length < 8 || input.idempotencyKey.length > 200) {
    throw Errors.badRequest('INVALID_IDEMPOTENCY_KEY', 'Idempotency key must be 8-200 characters');
  }
}

/**
 * Applies one balance change plus its ledger row inside the caller's transaction.
 *
 * Concurrency: the single UPDATE ... WHERE balance + amount >= 0 takes a row lock,
 * so concurrent spenders serialize and the guard is evaluated against the latest
 * committed balance. The CHECK (balance >= 0) constraint is a second line of defence.
 */
export async function applyWalletChange(tx: DbClient, input: WalletChangeInput): Promise<WalletChangeResult> {
  validate(input);

  const existing = await tx.walletTransaction.findUnique({ where: { idempotencyKey: input.idempotencyKey } });
  if (existing) {
    if (existing.userId !== input.userId || existing.amount !== input.amount || existing.kind !== input.kind) {
      throw Errors.conflict('IDEMPOTENCY_KEY_REUSED', 'This idempotency key was already used for a different operation');
    }
    return { transactionId: existing.id, balanceAfter: existing.balanceAfter, replayed: true };
  }

  const amount = input.amount;
  const earned = input.kind === 'EARN' ? amount : 0;
  const purchased = input.kind === 'PURCHASE_COINS' ? amount : 0;
  const promo = input.kind === 'PROMO' ? amount : 0;
  // SPEND (negative) raises spentTotal; REFUND (positive) lowers it, never below zero.
  const spentDelta = input.kind === 'SPEND' || input.kind === 'REFUND' ? -amount : 0;

  const rows = await tx.$queryRaw<{ balance: number }[]>(Prisma.sql`
    UPDATE "Wallet"
    SET "balance"        = "balance" + ${amount}::int,
        "earnedTotal"    = "earnedTotal" + ${earned}::int,
        "purchasedTotal" = "purchasedTotal" + ${purchased}::int,
        "promoTotal"     = "promoTotal" + ${promo}::int,
        "spentTotal"     = GREATEST("spentTotal" + ${spentDelta}::int, 0),
        "updatedAt"      = now()
    WHERE "userId" = ${input.userId}
      AND "balance" + ${amount}::int >= 0
      AND "balance" + ${amount}::int <= ${MAX_WALLET_BALANCE}::int
    RETURNING "balance"
  `);

  const row = rows[0];
  if (!row) {
    const wallet = await tx.wallet.findUnique({ where: { userId: input.userId }, select: { balance: true } });
    if (!wallet) throw Errors.notFound('WALLET_NOT_FOUND', 'Wallet not found');
    if (amount < 0) throw Errors.unprocessable('INSUFFICIENT_FUNDS', 'Not enough coins');
    throw Errors.unprocessable('WALLET_LIMIT_EXCEEDED', 'Wallet balance limit exceeded');
  }

  const entry = await tx.walletTransaction.create({
    data: {
      walletId: input.userId,
      userId: input.userId,
      amount,
      kind: input.kind,
      source: input.source,
      refId: input.refId ?? null,
      balanceAfter: row.balance,
      idempotencyKey: input.idempotencyKey,
    },
  });
  return { transactionId: entry.id, balanceAfter: row.balance, replayed: false };
}

/**
 * Standalone wallet change in its own transaction. If two requests race with the
 * same idempotency key, the loser rolls back and is answered as a replay.
 */
export async function changeWallet(prisma: PrismaClient, input: WalletChangeInput): Promise<WalletChangeResult> {
  try {
    return await prisma.$transaction((tx) => applyWalletChange(tx, input));
  } catch (err) {
    if (isUniqueViolation(err, 'idempotencyKey')) {
      const existing = await prisma.walletTransaction.findUnique({ where: { idempotencyKey: input.idempotencyKey } });
      if (existing && existing.userId === input.userId && existing.amount === input.amount) {
        return { transactionId: existing.id, balanceAfter: existing.balanceAfter, replayed: true };
      }
    }
    throw err;
  }
}

export async function getWalletSummary(prisma: DbClient, userId: string) {
  const wallet = await prisma.wallet.findUnique({ where: { userId } });
  if (!wallet) throw Errors.notFound('WALLET_NOT_FOUND', 'Wallet not found');
  return {
    balance: wallet.balance,
    earnedTotal: wallet.earnedTotal,
    purchasedTotal: wallet.purchasedTotal,
    spentTotal: wallet.spentTotal,
    promoTotal: wallet.promoTotal,
  };
}
