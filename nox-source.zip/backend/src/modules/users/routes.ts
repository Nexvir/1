import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../../auth/plugin';
import { Errors } from '../../errors';
import { levelProgress } from '../progression/levels';
import { PUBLIC_USER_SELECT, blockState, getRelation, toPublicUser } from '../social/service';
import { usernameSchema } from '../auth/routes';
import { applyWalletChange } from '../wallet/service';
import { randomUUID } from 'node:crypto';

export const PROFILE_EDIT_PRICES = { displayName: 250, bio: 100, avatarUrl: 200 } as const;

const updateProfileSchema = z
  .object({
    displayName: z.string().trim().min(1).max(30),
    bio: z.string().trim().max(280).nullable(),
    avatarUrl: z.string().trim().url().max(2048).nullable(),
    tags: z.array(z.string().trim().min(1).max(20)).max(5),
    visibility: z.enum(['PUBLIC', 'FRIENDS', 'PRIVATE']),
    requestPolicy: z.enum(['EVERYONE', 'NOBODY']),
    showClan: z.boolean(),
    showStats: z.boolean(),
  })
  .partial()
  .strict();

const searchSchema = z.object({
  q: z.string().trim().toLowerCase().min(2).max(20),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

export async function userRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: app.authenticate };

  async function loadMe(userId: string) {
    const user = await app.prisma.user.findUnique({
      where: { id: userId },
      include: { profile: true, wallet: true },
    });
    if (!user || !user.profile) throw Errors.notFound('USER_NOT_FOUND', 'User not found');
    const p = user.profile;
    const cosmeticRows = await app.prisma.storeItem.findMany({ where: { id: { in: [p.equippedFrameId, p.equippedTitleId, p.equippedBadgeId, p.equippedThemeId].filter((id): id is string => id !== null) } }, select: { id: true, name: true } });
    const cosmeticNames = new Map(cosmeticRows.map((item) => [item.id, item.name]));
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      createdAt: user.createdAt,
      profile: {
        displayName: p.displayName,
        avatarUrl: p.avatarUrl,
        bio: p.bio,
        tags: p.tags,
        progress: levelProgress(app.levelTable, p.xp),
        trophies: p.trophies,
        stats: { totalMatches: p.totalMatches, wins: p.wins, losses: p.losses, draws: p.draws },
        privacy: { visibility: p.visibility, requestPolicy: p.requestPolicy, showClan: p.showClan, showStats: p.showStats },
        equipped: {
          frameId: p.equippedFrameId,
          frameName: p.equippedFrameId ? cosmeticNames.get(p.equippedFrameId) ?? null : null,
          titleId: p.equippedTitleId,
          titleName: p.equippedTitleId ? cosmeticNames.get(p.equippedTitleId) ?? null : null,
          badgeId: p.equippedBadgeId,
          badgeName: p.equippedBadgeId ? cosmeticNames.get(p.equippedBadgeId) ?? null : null,
          themeId: p.equippedThemeId,
          themeName: p.equippedThemeId ? cosmeticNames.get(p.equippedThemeId) ?? null : null,
        },
      },
      wallet: { balance: user.wallet?.balance ?? 0 },
    };
  }

  app.get('/me', auth, async (req) => loadMe(requireAuth(req).userId));

  app.patch('/me/profile', auth, async (req) => {
    const { userId } = requireAuth(req);
    const body = updateProfileSchema.parse(req.body);
    if (Object.keys(body).length === 0) throw Errors.badRequest('EMPTY_UPDATE', 'No fields to update');
    const tags = body.tags ? [...new Set(body.tags)] : undefined;
    const price = await app.prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT "userId" FROM "UserProfile" WHERE "userId" = ${userId} FOR UPDATE`;
      const current = await tx.userProfile.findUniqueOrThrow({ where: { userId }, select: { displayName: true, bio: true, avatarUrl: true } });
      const total = (body.displayName !== undefined && body.displayName !== current.displayName ? PROFILE_EDIT_PRICES.displayName : 0)
        + (body.bio !== undefined && body.bio !== current.bio ? PROFILE_EDIT_PRICES.bio : 0)
        + (body.avatarUrl !== undefined && body.avatarUrl !== current.avatarUrl ? PROFILE_EDIT_PRICES.avatarUrl : 0);
      if (total > 0) await applyWalletChange(tx, { userId, amount: -total, kind: 'SPEND', source: 'profile_customization', idempotencyKey: `profile-edit:${randomUUID()}` });
      await tx.userProfile.update({ where: { userId }, data: { ...body, ...(tags ? { tags } : {}) } });
      return total;
    });
    return { ...(await loadMe(userId)), customization: { charged: price, prices: PROFILE_EDIT_PRICES } };
  });

  // Explicit username search (prefix match). Players with a PRIVATE profile are not discoverable.
  app.get('/search', auth, async (req) => {
    const { userId } = requireAuth(req);
    const { q, limit } = searchSchema.parse(req.query);
    const blocks = await app.prisma.userBlock.findMany({
      where: { OR: [{ blockerId: userId }, { blockedId: userId }] },
      select: { blockerId: true, blockedId: true },
    });
    const hidden = new Set(blocks.flatMap((b) => [b.blockerId, b.blockedId]));
    hidden.add(userId);

    const users = await app.prisma.user.findMany({
      where: {
        status: 'ACTIVE',
        isDemo: false,
        username: { startsWith: q },
        id: { notIn: [...hidden] },
        profile: { is: { visibility: { not: 'PRIVATE' } } },
      },
      orderBy: { username: 'asc' },
      take: limit,
      select: PUBLIC_USER_SELECT,
    });
    return { items: users.map(toPublicUser) };
  });

  app.get('/:username', auth, async (req) => {
    const { userId: viewerId } = requireAuth(req);
    const username = usernameSchema.parse((req.params as { username: string }).username);

    const target = await app.prisma.user.findUnique({
      where: { username },
      select: { id: true, status: true, username: true, profile: true },
    });
    if (!target || target.status !== 'ACTIVE' || !target.profile) throw Errors.notFound('USER_NOT_FOUND', 'User not found');

    const blocks = await blockState(app.prisma, viewerId, target.id);
    if (blocks.bBlockedA) throw Errors.notFound('USER_NOT_FOUND', 'User not found');

    const relation = await getRelation(app.prisma, viewerId, target.id);
    const p = target.profile;
    const isSelf = relation.state === 'SELF';
    const isFriend = relation.state === 'FRIENDS';
    const canSee = isSelf || p.visibility === 'PUBLIC' || (p.visibility === 'FRIENDS' && isFriend);
    const gameStats = canSee && (p.showStats || isSelf)
      ? await app.prisma.matchParticipant.findMany({
          where: { userId: target.id, outcome: { not: null }, match: { status: 'COMPLETED' } },
          select: { outcome: true, match: { select: { game: { select: { key: true, name: true } } } } },
        })
      : [];
    const gameSummary = new Map<string, { gameKey: string; gameName: string; matches: number; wins: number }>();
    for (const item of gameStats) {
      const { key, name } = item.match.game;
      const current = gameSummary.get(key) ?? { gameKey: key, gameName: name, matches: 0, wins: 0 };
      current.matches++;
      if (item.outcome === 'WIN') current.wins++;
      gameSummary.set(key, current);
    }
    const equippedItems = canSee
      ? await app.prisma.storeItem.findMany({ where: { id: { in: [p.equippedFrameId, p.equippedTitleId, p.equippedBadgeId, p.equippedThemeId].filter((id): id is string => id !== null) } }, select: { id: true, name: true } })
      : [];
    const equippedNames = new Map(equippedItems.map((item) => [item.id, item.name]));

    const base = toPublicUser({
      id: target.id,
      username: target.username,
      profile: { displayName: p.displayName, avatarUrl: p.avatarUrl, level: p.level },
    });

    return {
      user: base,
      restricted: !canSee,
      profile: canSee
        ? {
            bio: p.bio,
            tags: p.tags,
            progress: levelProgress(app.levelTable, p.xp),
            trophies: p.trophies,
            stats:
              p.showStats || isSelf
                ? { totalMatches: p.totalMatches, wins: p.wins, losses: p.losses, draws: p.draws }
                : null,
            gameStats: p.showStats || isSelf ? [...gameSummary.values()] : null,
            equipped: {
              frameId: p.equippedFrameId,
              frameName: p.equippedFrameId ? equippedNames.get(p.equippedFrameId) ?? null : null,
              titleId: p.equippedTitleId,
              titleName: p.equippedTitleId ? equippedNames.get(p.equippedTitleId) ?? null : null,
              badgeId: p.equippedBadgeId,
              badgeName: p.equippedBadgeId ? equippedNames.get(p.equippedBadgeId) ?? null : null,
              themeId: p.equippedThemeId,
              themeName: p.equippedThemeId ? equippedNames.get(p.equippedThemeId) ?? null : null,
            },
          }
        : null,
      relation,
      canSendFriendRequest: relation.state === 'NONE' && p.requestPolicy === 'EVERYONE',
    };
  });
}
