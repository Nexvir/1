import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../../auth/plugin';
import { Errors } from '../../errors';
import { getRelation } from '../social/service';
import { ensureNoxBot, ensureNoxConversation } from '../accounts/service';

const pageQuery = z.object({ limit: z.coerce.number().int().min(1).max(100).default(50), before: z.string().datetime().optional() });

/** Private conversations are returned only to their members. */
export async function chatRoutes(app: FastifyInstance): Promise<void> {
  const createSchema = z.object({ username: z.string().trim().toLowerCase().min(3).max(20) });
  const sendSchema = z.object({ body: z.string().trim().min(1).max(1000), clientMsgId: z.string().min(8).max(64).optional() });
  app.post('/conversations', { preHandler: app.authenticate }, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { username } = createSchema.parse(req.body);
    const other = await app.prisma.user.findUnique({ where: { username }, select: { id: true } });
    if (!other) throw Errors.notFound('USER_NOT_FOUND', 'User not found');
    if (other.id === userId) throw Errors.badRequest('CANNOT_CHAT_SELF', 'You cannot start a conversation with yourself');
    if ((await getRelation(app.prisma, userId, other.id)).state !== 'FRIENDS') throw Errors.forbidden('CHAT_FRIENDS_ONLY', 'Private chat is available between friends only');
    const pairKey = [userId, other.id].sort().join(':');
    const conversation = await app.prisma.conversation.upsert({
      where: { pairKey }, create: { pairKey, members: { create: [{ userId }, { userId: other.id }] } }, update: {},
    });
    return reply.status(201).send({ id: conversation.id });
  });
  app.post('/announcements', { preHandler: app.authenticate }, async (req, reply) => {
    const { userId, role } = requireAuth(req);
    if (role !== 'ADMIN') throw Errors.forbidden('ADMIN_ONLY', 'Administrator access required');
    const { id, body } = z.object({ id: z.string().regex(/^[a-zA-Z0-9_-]{8,64}$/), body: z.string().trim().min(1).max(1000) }).parse(req.body);
    const botId = await app.prisma.$transaction((tx) => ensureNoxBot(tx));
    const recipients = await app.prisma.user.findMany({ where: { status: 'ACTIVE', isDemo: false }, select: { id: true } });
    let delivered = 0;
    for (const recipient of recipients) {
      const clientMsgId = `announcement:${id}:${recipient.id}`;
      await app.prisma.$transaction(async (tx) => {
        await ensureNoxConversation(tx, recipient.id);
        const pairKey = [recipient.id, botId].sort().join(':');
        const conversation = await tx.conversation.findUniqueOrThrow({ where: { pairKey }, select: { id: true } });
        const existing = await tx.privateMessage.findFirst({ where: { senderId: botId, clientMsgId }, select: { id: true } });
        if (existing) return;
        const message = await tx.privateMessage.create({ data: { conversationId: conversation.id, senderId: botId, clientMsgId, body: `📣 اطلاعیهٔ ناتس\n${body}` } });
        await tx.conversation.update({ where: { id: conversation.id }, data: { lastMessageAt: message.createdAt } });
        delivered++;
      });
    }
    return reply.send({ delivered, recipients: recipients.length });
  });
  app.get('/conversations', { preHandler: app.authenticate }, async (req) => {
    const { userId } = requireAuth(req);
    const rows = await app.prisma.conversation.findMany({
      where: { members: { some: { userId } } }, orderBy: [{ lastMessageAt: 'desc' }, { id: 'asc' }], take: 100,
      include: {
        members: { where: { userId: { not: userId } }, include: { user: { select: { id: true, username: true, profile: { select: { displayName: true, avatarUrl: true, level: true } } } } } },
        messages: { where: { deletedAt: null }, orderBy: { createdAt: 'desc' }, take: 1, select: { body: true, createdAt: true, senderId: true } },
      },
    });
    return { items: rows.map((c) => { const other = c.members[0]?.user; const p = other?.profile; const m = c.messages[0]; return { id: c.id, lastMessageAt: c.lastMessageAt, other: other ? { id: other.id, username: other.username, displayName: p?.displayName ?? other.username, avatarUrl: p?.avatarUrl ?? null, level: p?.level ?? 1 } : null, preview: m ? { body: m.body, createdAt: m.createdAt, mine: m.senderId === userId } : null }; }) };
  });

  app.get('/:id/messages', { preHandler: app.authenticate }, async (req) => {
    const { userId } = requireAuth(req);
    const { id } = z.object({ id: z.string().min(1).max(64) }).parse(req.params);
    const q = pageQuery.parse(req.query);
    const member = await app.prisma.conversationMember.findUnique({ where: { conversationId_userId: { conversationId: id, userId } }, select: { id: true } });
    if (!member) throw Errors.notFound('CONVERSATION_NOT_FOUND', 'Conversation not found');
    const items = await app.prisma.privateMessage.findMany({ where: { conversationId: id, deletedAt: null, ...(q.before ? { createdAt: { lt: new Date(q.before) } } : {}) }, orderBy: { createdAt: 'desc' }, take: q.limit, select: { id: true, senderId: true, body: true, createdAt: true } });
    return { items: items.reverse().map((m) => ({ ...m, mine: m.senderId === userId })) };
  });

  app.post('/:id/messages', { preHandler: app.authenticate }, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { id } = z.object({ id: z.string().min(1).max(64) }).parse(req.params);
    const body = sendSchema.parse(req.body);
    const member = await app.prisma.conversationMember.findUnique({ where: { conversationId_userId: { conversationId: id, userId } } });
    if (!member) throw Errors.notFound('CONVERSATION_NOT_FOUND', 'Conversation not found');
    const message = await app.prisma.$transaction(async (tx) => {
      const created = await tx.privateMessage.create({ data: { conversationId: id, senderId: userId, body: body.body, clientMsgId: body.clientMsgId } });
      await tx.conversation.update({ where: { id }, data: { lastMessageAt: created.createdAt } });
      return created;
    });
    return reply.status(201).send({ id: message.id, body: message.body, createdAt: message.createdAt, mine: true });
  });
}
