import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../../auth/plugin';

const listQuery = z.object({ q: z.string().trim().max(40).optional(), limit: z.coerce.number().int().min(1).max(50).default(30) });

/** Read-only clan discovery backed by real non-deleted clan and membership rows. */
export async function clanRoutes(app: FastifyInstance): Promise<void> {
  app.get('/', { preHandler: app.authenticate }, async (req) => {
    const { userId } = requireAuth(req);
    const q = listQuery.parse(req.query);
    const [membership, clans] = await Promise.all([
      app.prisma.clanMembership.findUnique({ where: { userId }, include: { clan: { include: { _count: { select: { members: true } } } } } }),
      app.prisma.clan.findMany({
        where: { deletedAt: null, ...(q.q ? { OR: [{ name: { contains: q.q, mode: 'insensitive' as const } }, { tag: { contains: q.q, mode: 'insensitive' as const } }] } : {}) },
        orderBy: [{ xp: 'desc' }, { id: 'asc' }], take: q.limit,
        include: { _count: { select: { members: true } } },
      }),
    ]);
    return {
      mine: membership ? { id: membership.clan.id, name: membership.clan.name, tag: membership.clan.tag, description: membership.clan.description, level: membership.clan.level, xp: membership.clan.xp, members: membership.clan._count.members, capacity: membership.clan.maxMembers, joinPolicy: membership.clan.joinPolicy, role: membership.role } : null,
      items: clans.map((c) => ({ id: c.id, name: c.name, tag: c.tag, description: c.description, emblem: c.emblem, level: c.level, xp: c.xp, joinPolicy: c.joinPolicy, members: c._count.members, capacity: c.maxMembers })),
    };
  });
}
