import type { Prisma } from '@prisma/client';
import type { AppConfig } from '../../config';
import type { DbClient } from '../../db';
import { hmacHex } from '../../auth/codes';

export type SecurityEventType =
  | 'ACCOUNT_CREATED'
  | 'GUEST_CREATED'
  | 'CAPTCHA_PASSED'
  | 'CAPTCHA_FAILED'
  | 'RECOVERY_SUCCEEDED'
  | 'RECOVERY_FAILED'
  | 'RECOVERY_LOCKED'
  | 'RECOVERY_CODE_ROTATED'
  | 'OTP_REQUESTED'
  | 'OTP_FAILED'
  | 'OTP_LOGIN'
  | 'GOOGLE_LOGIN'
  | 'IDENTITY_LINKED'
  | 'IDENTITY_LINK_CONFLICT'
  | 'GUEST_DELETED';

/** Raw IP addresses are never stored; only a keyed hash, enough to count events per source. */
export function ipHashOf(config: AppConfig, ip: string | undefined): string | null {
  return ip ? hmacHex(config.pepper, 'ip', ip) : null;
}

export interface NewSecurityEvent {
  type: SecurityEventType;
  userId?: string | null;
  ipHash?: string | null;
  /** Must never contain secrets (codes, tokens, passwords) or raw IPs / contact details. */
  metadata?: Prisma.InputJsonValue;
}

export async function recordEvent(db: DbClient, e: NewSecurityEvent): Promise<void> {
  await db.securityEvent.create({
    data: { type: e.type, userId: e.userId ?? null, ipHash: e.ipHash ?? null, metadata: e.metadata ?? undefined },
  });
}

export async function countEvents(
  db: DbClient,
  q: { type: SecurityEventType; ipHash?: string | null; userId?: string; sinceMs: number },
): Promise<number> {
  if (q.ipHash === null) return 0;
  return db.securityEvent.count({
    where: {
      type: q.type,
      ...(q.ipHash ? { ipHash: q.ipHash } : {}),
      ...(q.userId ? { userId: q.userId } : {}),
      createdAt: { gte: new Date(Date.now() - q.sinceMs) },
    },
  });
}
