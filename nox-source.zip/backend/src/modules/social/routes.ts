import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../../auth/plugin';
import { Errors } from '../../errors';
import {
  blockUser,
  cancelRequest,
  listBlocks,
  listFriends,
  listRequests,
  removeFriend,
  respondToRequest,
  sendFriendRequest,
  unblockUser,
} from './service';
import { usernameSchema } from '../auth/routes';

const idParam = z.object({ id: z.string().min(1).max(64) });
const userIdParam = z.object({ userId: z.string().min(1).max(64) });
const listQuery = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(50),
  cursor: z.string().min(1).max(64).optional(),
});
const sendBody = z.object({ username: usernameSchema });
const blockBody = z.object({ userId: z.string().min(1).max(64) });

export async function friendRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: app.authenticate };
  // Mutations that create rows get a tighter per-user-IP limit.
  const writeLimit = { rateLimit: { max: 30, timeWindow: '1 minute' } };

  app.get('/', auth, async (req) => {
    const { userId } = requireAuth(req);
    const q = listQuery.parse(req.query);
    return listFriends(app.prisma, userId, q.limit, q.cursor);
  });

  app.get('/requests', auth, async (req) => {
    const { userId } = requireAuth(req);
    const { direction } = z.object({ direction: z.enum(['incoming', 'outgoing']).default('incoming') }).parse(req.query);
    return { items: await listRequests(app.prisma, userId, direction) };
  });

  app.post('/requests', { ...auth, config: writeLimit }, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { username } = sendBody.parse(req.body);
    const target = await app.prisma.user.findUnique({ where: { username }, select: { id: true } });
    if (!target) throw Errors.notFound('USER_NOT_FOUND', 'User not found');
    const request = await sendFriendRequest(app.prisma, userId, target.id);
    return reply.status(201).send({ id: request.id, status: request.status, createdAt: request.createdAt });
  });

  app.post('/requests/:id/accept', { ...auth, config: writeLimit }, async (req) => {
    const { userId } = requireAuth(req);
    return respondToRequest(app.prisma, userId, idParam.parse(req.params).id, true);
  });

  app.post('/requests/:id/reject', { ...auth, config: writeLimit }, async (req) => {
    const { userId } = requireAuth(req);
    return respondToRequest(app.prisma, userId, idParam.parse(req.params).id, false);
  });

  app.delete('/requests/:id', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    await cancelRequest(app.prisma, userId, idParam.parse(req.params).id);
    return reply.status(204).send();
  });

  app.delete('/:userId', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    await removeFriend(app.prisma, userId, userIdParam.parse(req.params).userId);
    return reply.status(204).send();
  });
}

export async function blockRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: app.authenticate };

  app.get('/', auth, async (req) => {
    const { userId } = requireAuth(req);
    return { items: await listBlocks(app.prisma, userId) };
  });

  app.post('/', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    await blockUser(app.prisma, userId, blockBody.parse(req.body).userId);
    return reply.status(204).send();
  });

  app.delete('/:userId', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    await unblockUser(app.prisma, userId, userIdParam.parse(req.params).userId);
    return reply.status(204).send();
  });
}
