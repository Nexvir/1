import type { PrismaClient } from '@prisma/client';
import type { DbClient } from '../../db';
import { Errors, isUniqueViolation } from '../../errors';
import { orderedPair, pairKey } from '../../lib/ids';
import { createNotification } from '../notifications/service';

export type RelationState =
  | 'SELF'
  | 'NONE'
  | 'FRIENDS'
  | 'REQUEST_SENT'
  | 'REQUEST_RECEIVED'
  | 'BLOCKED_BY_ME';

export interface Relation {
  state: RelationState;
  requestId?: string;
}

export const PUBLIC_USER_SELECT = {
  id: true,
  username: true,
  profile: { select: { displayName: true, avatarUrl: true, level: true } },
} as const;

export function toPublicUser(u: {
  id: string;
  username: string;
  profile: { displayName: string; avatarUrl: string | null; level: number } | null;
}) {
  return {
    id: u.id,
    username: u.username,
    displayName: u.profile?.displayName ?? u.username,
    avatarUrl: u.profile?.avatarUrl ?? null,
    level: u.profile?.level ?? 1,
  };
}

export async function blockState(db: DbClient, a: string, b: string): Promise<{ aBlockedB: boolean; bBlockedA: boolean }> {
  const rows = await db.userBlock.findMany({
    where: { OR: [{ blockerId: a, blockedId: b }, { blockerId: b, blockedId: a }] },
    select: { blockerId: true },
  });
  return { aBlockedB: rows.some((r) => r.blockerId === a), bBlockedA: rows.some((r) => r.blockerId === b) };
}

/** How `viewerId` stands relative to `targetId`. Blocks by the target are NOT revealed here. */
export async function getRelation(db: DbClient, viewerId: string, targetId: string): Promise<Relation> {
  if (viewerId === targetId) return { state: 'SELF' };
  const [a, b] = orderedPair(viewerId, targetId);

  const [friendship, pending, blocked] = await Promise.all([
    db.friendship.findUnique({ where: { userAId_userBId: { userAId: a, userBId: b } }, select: { id: true } }),
    db.friendRequest.findFirst({ where: { pairKey: pairKey(viewerId, targetId), status: 'PENDING' }, select: { id: true, senderId: true } }),
    db.userBlock.findUnique({ where: { blockerId_blockedId: { blockerId: viewerId, blockedId: targetId } }, select: { id: true } }),
  ]);

  if (blocked) return { state: 'BLOCKED_BY_ME' };
  if (friendship) return { state: 'FRIENDS' };
  if (pending) {
    return { state: pending.senderId === viewerId ? 'REQUEST_SENT' : 'REQUEST_RECEIVED', requestId: pending.id };
  }
  return { state: 'NONE' };
}

export async function sendFriendRequest(prisma: PrismaClient, senderId: string, targetId: string) {
  if (senderId === targetId) throw Errors.badRequest('CANNOT_FRIEND_SELF', 'You cannot send a friend request to yourself');

  const target = await prisma.user.findUnique({
    where: { id: targetId },
    select: { id: true, status: true, profile: { select: { requestPolicy: true } } },
  });
  if (!target || target.status !== 'ACTIVE') throw Errors.notFound('USER_NOT_FOUND', 'User not found');

  const blocks = await blockState(prisma, senderId, targetId);
  if (blocks.bBlockedA) throw Errors.notFound('USER_NOT_FOUND', 'User not found'); // never reveal being blocked
  if (blocks.aBlockedB) throw Errors.conflict('YOU_BLOCKED_THIS_USER', 'Unblock this user first');
  if (target.profile?.requestPolicy === 'NOBODY') {
    throw Errors.forbidden('REQUESTS_DISABLED', 'This player does not accept friend requests');
  }

  const [a, b] = orderedPair(senderId, targetId);
  const friendship = await prisma.friendship.findUnique({ where: { userAId_userBId: { userAId: a, userBId: b } } });
  if (friendship) throw Errors.conflict('ALREADY_FRIENDS', 'You are already friends');

  const pending = await prisma.friendRequest.findFirst({ where: { pairKey: pairKey(senderId, targetId), status: 'PENDING' } });
  if (pending) {
    if (pending.senderId === senderId) throw Errors.conflict('REQUEST_ALREADY_SENT', 'Friend request already sent');
    throw Errors.conflict('REQUEST_ALREADY_RECEIVED', 'This player already sent you a request; accept it instead', {
      requestId: pending.id,
    });
  }

  try {
    return await prisma.$transaction(async (tx) => {
      const request = await tx.friendRequest.create({
        data: { senderId, receiverId: targetId, pairKey: pairKey(senderId, targetId) },
      });
      const sender = await tx.userProfile.findUnique({ where: { userId: senderId }, select: { displayName: true } });
      await createNotification(tx, {
        userId: targetId,
        type: 'FRIEND_REQUEST',
        title: 'درخواست دوستی جدید',
        body: sender?.displayName ?? '',
        data: { requestId: request.id, fromUserId: senderId },
      });
      return request;
    });
  } catch (err) {
    // Lost a race against an identical/reverse request: the partial unique index caught it.
    if (isUniqueViolation(err)) throw Errors.conflict('REQUEST_ALREADY_SENT', 'A pending request already exists');
    throw err;
  }
}

export async function respondToRequest(prisma: PrismaClient, userId: string, requestId: string, accept: boolean) {
  return prisma.$transaction(async (tx) => {
    const request = await tx.friendRequest.findUnique({ where: { id: requestId } });
    if (!request || request.receiverId !== userId) throw Errors.notFound('REQUEST_NOT_FOUND', 'Friend request not found');

    // Conditional update: only one concurrent responder can move it out of PENDING.
    const updated = await tx.friendRequest.updateMany({
      where: { id: requestId, status: 'PENDING' },
      data: { status: accept ? 'ACCEPTED' : 'REJECTED', respondedAt: new Date() },
    });
    if (updated.count !== 1) throw Errors.conflict('REQUEST_NOT_PENDING', 'This request was already handled');

    if (accept) {
      const blocks = await blockState(tx, request.senderId, request.receiverId);
      if (blocks.aBlockedB || blocks.bBlockedA) throw Errors.conflict('USER_BLOCKED', 'Cannot accept: a block exists');
      const [a, b] = orderedPair(request.senderId, request.receiverId);
      await tx.friendship.upsert({
        where: { userAId_userBId: { userAId: a, userBId: b } },
        create: { userAId: a, userBId: b },
        update: {},
      });
      const me = await tx.userProfile.findUnique({ where: { userId }, select: { displayName: true } });
      await createNotification(tx, {
        userId: request.senderId,
        type: 'FRIEND_REQUEST_ACCEPTED',
        title: 'درخواست دوستی پذیرفته شد',
        body: me?.displayName ?? '',
        data: { userId },
      });
    }
    return { requestId, status: accept ? ('ACCEPTED' as const) : ('REJECTED' as const) };
  });
}

export async function cancelRequest(prisma: PrismaClient, userId: string, requestId: string) {
  const updated = await prisma.friendRequest.updateMany({
    where: { id: requestId, senderId: userId, status: 'PENDING' },
    data: { status: 'CANCELLED', respondedAt: new Date() },
  });
  if (updated.count === 1) return;
  const existing = await prisma.friendRequest.findUnique({ where: { id: requestId }, select: { senderId: true } });
  if (!existing || existing.senderId !== userId) throw Errors.notFound('REQUEST_NOT_FOUND', 'Friend request not found');
  throw Errors.conflict('REQUEST_NOT_PENDING', 'This request was already handled');
}

export async function removeFriend(prisma: PrismaClient, userId: string, otherId: string) {
  const [a, b] = orderedPair(userId, otherId);
  const res = await prisma.friendship.deleteMany({ where: { userAId: a, userBId: b } });
  if (res.count === 0) throw Errors.notFound('NOT_FRIENDS', 'You are not friends with this user');
}

export async function listFriends(prisma: PrismaClient, userId: string, limit: number, cursor?: string) {
  const rows = await prisma.friendship.findMany({
    where: { OR: [{ userAId: userId }, { userBId: userId }] },
    orderBy: { id: 'asc' },
    take: limit + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    include: { userA: { select: { ...PUBLIC_USER_SELECT, status: true } }, userB: { select: { ...PUBLIC_USER_SELECT, status: true } } },
  });
  const page = rows.slice(0, limit);
  const items = page
    .map((f) => ({ other: f.userAId === userId ? f.userB : f.userA, since: f.createdAt }))
    .filter((x) => x.other.status === 'ACTIVE')
    .map((x) => ({ ...toPublicUser(x.other), friendsSince: x.since }));
  return { items, nextCursor: rows.length > limit ? (page[page.length - 1]?.id ?? null) : null };
}

export async function listRequests(prisma: PrismaClient, userId: string, direction: 'incoming' | 'outgoing') {
  const rows = await prisma.friendRequest.findMany({
    where: direction === 'incoming' ? { receiverId: userId, status: 'PENDING' } : { senderId: userId, status: 'PENDING' },
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: { sender: { select: PUBLIC_USER_SELECT }, receiver: { select: PUBLIC_USER_SELECT } },
  });
  return rows.map((r) => ({
    id: r.id,
    createdAt: r.createdAt,
    user: toPublicUser(direction === 'incoming' ? r.sender : r.receiver),
  }));
}

export async function blockUser(prisma: PrismaClient, userId: string, targetId: string) {
  if (userId === targetId) throw Errors.badRequest('CANNOT_BLOCK_SELF', 'You cannot block yourself');
  const target = await prisma.user.findUnique({ where: { id: targetId }, select: { id: true } });
  if (!target) throw Errors.notFound('USER_NOT_FOUND', 'User not found');

  const [a, b] = orderedPair(userId, targetId);
  await prisma.$transaction(async (tx) => {
    await tx.userBlock.upsert({
      where: { blockerId_blockedId: { blockerId: userId, blockedId: targetId } },
      create: { blockerId: userId, blockedId: targetId },
      update: {},
    });
    await tx.friendship.deleteMany({ where: { userAId: a, userBId: b } });
    await tx.friendRequest.updateMany({
      where: { pairKey: pairKey(userId, targetId), status: 'PENDING' },
      data: { status: 'CANCELLED', respondedAt: new Date() },
    });
  });
}

export async function unblockUser(prisma: PrismaClient, userId: string, targetId: string) {
  await prisma.userBlock.deleteMany({ where: { blockerId: userId, blockedId: targetId } });
}

export async function listBlocks(prisma: PrismaClient, userId: string) {
  const rows = await prisma.userBlock.findMany({
    where: { blockerId: userId },
    orderBy: { createdAt: 'desc' },
    take: 200,
    include: { blocked: { select: PUBLIC_USER_SELECT } },
  });
  return rows.map((r) => ({ ...toPublicUser(r.blocked), blockedAt: r.createdAt }));
}
