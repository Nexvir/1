import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { Errors } from '../../errors';
import { ipHashOf } from '../security/events';
import { answerChallenge, createChallenge, getOptionImage } from './service';

const idParam = z.object({ id: z.string().min(1).max(64) });
const answerBody = z.object({ optionId: z.string().min(1).max(64) });
const imageParams = z.object({ id: z.string().min(1).max(64), file: z.string().regex(/^[A-Za-z0-9_-]{8,64}\.png$/) });

export async function captchaRoutes(app: FastifyInstance): Promise<void> {
  const limit = { rateLimit: { max: app.config.authRateLimitMax * 3, timeWindow: '1 minute' } };

  // 1. The client asks for a challenge.
  app.post('/challenges', { config: limit }, async (req, reply) => {
    const challenge = await createChallenge(app.prisma, app.config, ipHashOf(app.config, req.ip));
    return reply.status(201).header('cache-control', 'no-store').send(challenge);
  });

  // 3-5. The player picks a picture; the server validates and, only if it is right, issues a pass.
  app.post('/challenges/:id/answer', { config: limit }, async (req, reply) => {
    const { id } = idParam.parse(req.params);
    const { optionId } = answerBody.parse(req.body);
    const solved = await answerChallenge(app.prisma, app.config, id, optionId, ipHashOf(app.config, req.ip));
    return reply.header('cache-control', 'no-store').send({
      passed: true,
      pass: solved.pass,
      expiresInSeconds: solved.expiresInSeconds,
      usage: 'Send as "captchaPass" to the sign-up / sign-in request. Single use.',
    });
  });

  // Pictures are rendered by the server per challenge; URLs carry no hint about the content.
  app.get('/challenges/:id/images/:file', { config: { rateLimit: { max: app.config.authRateLimitMax * 30, timeWindow: '1 minute' } } }, async (req, reply) => {
    const { id, file } = imageParams.parse(req.params);
    const png = await getOptionImage(app.prisma, id, file.replace(/\.png$/, ''));
    if (!png) throw Errors.notFound('CAPTCHA_NOT_FOUND', 'Image not found');
    return reply
      .header('content-type', 'image/png')
      .header('cache-control', 'no-store')
      .header('cross-origin-resource-policy', 'cross-origin')
      .header('content-security-policy', "default-src 'none'; style-src 'unsafe-inline'")
      .send(png);
  });
}
