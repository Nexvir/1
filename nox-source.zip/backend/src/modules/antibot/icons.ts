import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { PNG } from 'pngjs';

/**
 * Local picture set for the NØX picture challenge (Fluent Emoji 3D, MIT — see
 * assets/captcha/LICENSE.txt). The 256x256 PNGs ship with the server; no image is ever
 * fetched from the network. Every option is re-rendered per challenge (see renderOptionPng).
 */
export interface IconDef {
  key: string;
  /** Persian noun used in prompts ("گربه", "توپ فوتبال" ...). */
  fa: string;
  group: 'toy' | 'object';
  /** Pictures of the same category look alike; used by the "pick the right one among similar ones" challenge. */
  category: 'animal' | 'vehicle' | 'food' | null;
  file: string;
}

const ASSET_DIR = path.resolve(__dirname, '../../../assets/captcha');

const TOYS = new Set(['balloon', 'kite', 'teddy_bear', 'drum', 'soccer_ball', 'basketball', 'trumpet', 'guitar', 'video_game', 'wrapped_gift', 'rocket']);
const CATEGORIES: Record<string, 'animal' | 'vehicle' | 'food'> = {};
for (const k of ['cat', 'chick', 'dog', 'duck', 'fish', 'fox', 'frog', 'lion', 'owl', 'panda', 'penguin', 'rabbit_face', 'butterfly']) CATEGORIES[k] = 'animal';
for (const k of ['airplane', 'automobile', 'bicycle', 'helicopter', 'police_car', 'sailboat', 'rocket']) CATEGORIES[k] = 'vehicle';
for (const k of ['banana', 'cookie', 'cupcake', 'hamburger', 'ice_cream', 'red_apple', 'strawberry', 'watermelon', 'pizza']) CATEGORIES[k] = 'food';

/** Pairs whose Persian names would make a prompt ambiguous ("ماشین" vs "ماشین پلیس"); never shown together. */
const CONFLICTS: [string, string][] = [
  ['automobile', 'police_car'],
  ['moon', 'full_moon'],
];
export function compatible(a: string, b: string): boolean {
  return !CONFLICTS.some(([x, y]) => (a === x && b === y) || (a === y && b === x));
}

interface ManifestItem {
  file: string;
  id: string;
  name_fa: string;
}

function loadIcons(): Record<string, IconDef> {
  const items = JSON.parse(fs.readFileSync(path.join(ASSET_DIR, 'items.json'), 'utf8')) as ManifestItem[];
  const out: Record<string, IconDef> = {};
  for (const it of items) {
    out[it.id] = { key: it.id, fa: it.name_fa, group: TOYS.has(it.id) ? 'toy' : 'object', category: CATEGORIES[it.id] ?? null, file: it.file };
  }
  return out;
}

export const ICONS: Record<string, IconDef> = loadIcons();
export const ICON_KEYS = Object.keys(ICONS);
export const TOY_KEYS = ICON_KEYS.filter((k) => ICONS[k]!.group === 'toy');
export const OBJECT_KEYS = ICON_KEYS.filter((k) => ICONS[k]!.group === 'object');
export const CATEGORY_KEYS = (['animal', 'vehicle', 'food'] as const).map((c) => ({ category: c, keys: ICON_KEYS.filter((k) => ICONS[k]!.category === c) }));

const decoded = new Map<string, PNG>();
function sourcePng(key: string): PNG {
  let png = decoded.get(key);
  if (!png) {
    png = PNG.sync.read(fs.readFileSync(path.join(ASSET_DIR, ICONS[key]!.file)));
    decoded.set(key, png);
  }
  return png;
}

const BACKGROUNDS: [number, number, number][] = [
  [0x1d, 0x16, 0x46], [0x10, 0x2a, 0x4a], [0x2b, 0x12, 0x40], [0x0e, 0x33, 0x40], [0x34, 0x14, 0x46], [0x18, 0x20, 0x4a],
];

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface RenderableOption {
  token: string;
  icon: string;
}

const SIZE = 256;
const RADIUS = 56;

/**
 * Renders one option as a standalone PNG. Background colour, tilt, size, position and a few
 * decorative dots are derived from the option's random token, so two pictures of the same
 * icon never share the same pixels. This makes trivial byte/pixel matching harder; it is not
 * a defence against image-recognition models (see docs/AUTH.md).
 */
export function renderOptionPng(option: RenderableOption): Buffer {
  if (!ICONS[option.icon]) throw new Error('unknown icon');
  const src = sourcePng(option.icon);
  const seed = crypto.createHash('sha256').update(option.token).digest().readUInt32BE(0);
  const rnd = mulberry32(seed);

  const bg = BACKGROUNDS[Math.floor(rnd() * BACKGROUNDS.length)]!;
  const lift = 10 + rnd() * 26;
  const rot = ((rnd() * 24 - 12) * Math.PI) / 180;
  const scale = 0.7 + rnd() * 0.12;
  const offX = rnd() * 16 - 8;
  const offY = rnd() * 16 - 8;
  const dots = Array.from({ length: 5 }, () => ({ x: rnd() * SIZE, y: rnd() * SIZE, r: 3 + rnd() * 7, a: 0.08 + rnd() * 0.14 }));

  const out = new PNG({ width: SIZE, height: SIZE });
  const cos = Math.cos(-rot);
  const sin = Math.sin(-rot);
  const half = SIZE / 2;

  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const i = (y * SIZE + x) * 4;

      // Rounded-square mask.
      const cx = Math.min(Math.max(x + 0.5, RADIUS), SIZE - RADIUS);
      const cy = Math.min(Math.max(y + 0.5, RADIUS), SIZE - RADIUS);
      const dist = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
      if (dist > RADIUS) {
        out.data[i + 3] = 0;
        continue;
      }
      const edge = Math.min(1, RADIUS - dist);

      // Background: vertical gradient plus dots.
      const t = y / SIZE;
      let r = bg[0] + lift * t;
      let g = bg[1] + lift * t;
      let b = bg[2] + lift * t;
      for (const d of dots) {
        const k = Math.hypot(x - d.x, y - d.y) <= d.r ? d.a : 0;
        if (k) { r += (255 - r) * k; g += (255 - g) * k; b += (255 - b) * k; }
      }

      // Icon: inverse-map the output pixel into the source image (rotate, scale, shift) and sample bilinearly.
      const dx = (x - half - offX) / scale;
      const dy = (y - half - offY) / scale;
      const sx = dx * cos - dy * sin + half;
      const sy = dx * sin + dy * cos + half;
      if (sx >= 0 && sy >= 0 && sx < src.width - 1 && sy < src.height - 1) {
        const x0 = Math.floor(sx);
        const y0 = Math.floor(sy);
        const fx = sx - x0;
        const fy = sy - y0;
        let pr = 0, pg = 0, pb = 0, pa = 0;
        for (let j = 0; j < 4; j++) {
          const px = x0 + (j & 1);
          const py = y0 + (j >> 1);
          const w = (j & 1 ? fx : 1 - fx) * (j >> 1 ? fy : 1 - fy);
          const si = (py * src.width + px) * 4;
          const a = (src.data[si + 3]! / 255) * w;
          pr += src.data[si]! * a; pg += src.data[si + 1]! * a; pb += src.data[si + 2]! * a; pa += a;
        }
        if (pa > 0) {
          r = r * (1 - pa) + pr;
          g = g * (1 - pa) + pg;
          b = b * (1 - pa) + pb;
        }
      }

      out.data[i] = Math.max(0, Math.min(255, Math.round(r)));
      out.data[i + 1] = Math.max(0, Math.min(255, Math.round(g)));
      out.data[i + 2] = Math.max(0, Math.min(255, Math.round(b)));
      out.data[i + 3] = Math.round(255 * edge);
    }
  }
  return PNG.sync.write(out);
}
