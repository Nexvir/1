import crypto from 'node:crypto';
import type { CaptchaKind, Prisma, PrismaClient } from '@prisma/client';
import type { AppConfig } from '../../config';
import type { DbClient } from '../../db';
import { Errors } from '../../errors';
import { hmacHex, randomToken, safeEqual } from '../../auth/codes';
import { countEvents, recordEvent } from '../security/events';
import { CATEGORY_KEYS, ICONS, ICON_KEYS, OBJECT_KEYS, TOY_KEYS, compatible, renderOptionPng, type RenderableOption } from './icons';

/** Every challenge shows exactly six big pictures (a 2x3 grid fits a small phone screen). */
export const OPTION_COUNT = 6;

export interface StoredOption extends RenderableOption {}

export interface PublicChallenge {
  id: string;
  kind: CaptchaKind;
  /** Persian instruction, e.g. "عروسک خرسی رو پیدا کن!" */
  prompt: string;
  locale: 'fa';
  direction: 'rtl';
  options: { id: string; imageUrl: string }[];
  expiresAt: Date;
}

const rint = (n: number) => crypto.randomInt(0, n);
const pick = <T>(arr: readonly T[]): T => arr[rint(arr.length)]!;

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = rint(i + 1);
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

function sample<T>(arr: readonly T[], n: number): T[] {
  return shuffle([...arr]).slice(0, n);
}

const newToken = () => randomToken(12);

interface Built {
  kind: CaptchaKind;
  prompt: string;
  options: StoredOption[];
  correctToken: string;
}

function buildFindIcon(kind: 'FIND_TOY' | 'FIND_OBJECT'): Built {
  const target = pick(kind === 'FIND_TOY' ? TOY_KEYS : OBJECT_KEYS);
  const others = sample(ICON_KEYS.filter((k) => k !== target && compatible(k, target)), OPTION_COUNT - 1);
  const correct: StoredOption = { token: newToken(), icon: target };
  const options = shuffle([correct, ...others.map((icon) => ({ token: newToken(), icon }))]);
  return { kind, prompt: `${ICONS[target]!.fa} رو پیدا کن!`, options, correctToken: correct.token };
}

function buildOddOneOut(): Built {
  let [common, odd] = sample(ICON_KEYS, 2) as [string, string];
  while (!compatible(common, odd)) [common, odd] = sample(ICON_KEYS, 2) as [string, string];
  const oddOption: StoredOption = { token: newToken(), icon: odd };
  const options = shuffle([
    oddOption,
    ...Array.from({ length: OPTION_COUNT - 1 }, () => ({ token: newToken(), icon: common })),
  ]);
  return { kind: 'ODD_ONE_OUT', prompt: 'شکل متفاوت رو انتخاب کن!', options, correctToken: oddOption.token };
}

function buildFollowInstruction(): Built {
  // Harder variant: all six pictures come from one category (animals, vehicles or food) and exactly one matches the name.
  const { keys } = pick(CATEGORY_KEYS);
  const target = pick(keys);
  const others = sample(keys.filter((k) => k !== target && compatible(k, target)), OPTION_COUNT - 1);
  const correct: StoredOption = { token: newToken(), icon: target };
  const options = shuffle([correct, ...others.map((icon) => ({ token: newToken(), icon }))]);
  return { kind: 'FOLLOW_INSTRUCTION', prompt: `${ICONS[target]!.fa} رو انتخاب کن!`, options, correctToken: correct.token };
}

export function buildChallenge(): Built {
  switch (rint(4)) {
    case 0:
      return buildFindIcon('FIND_TOY');
    case 1:
      return buildOddOneOut();
    case 2:
      return buildFindIcon('FIND_OBJECT');
    default:
      return buildFollowInstruction();
  }
}

function toPublic(id: string, built: Built, expiresAt: Date): PublicChallenge {
  return {
    id,
    kind: built.kind,
    prompt: built.prompt,
    locale: 'fa',
    direction: 'rtl',
    // Opaque tokens: neither the option id nor the image URL reveals what the picture shows.
    options: built.options.map((o) => ({ id: o.token, imageUrl: `/v1/captcha/challenges/${id}/images/${o.token}.png` })),
    expiresAt,
  };
}

/** Too many wrong answers from one source: stop handing out challenges for a while. */
export async function assertCaptchaNotThrottled(prisma: DbClient, config: AppConfig, ipHash: string | null): Promise<void> {
  const failures = await countEvents(prisma, { type: 'CAPTCHA_FAILED', ipHash, sinceMs: 600_000 });
  if (failures >= config.antibot.failLimitPer10Min) {
    throw Errors.tooMany('TOO_MANY_CAPTCHA_FAILURES', 'Too many wrong answers from this network, try again later', 300);
  }
}

export async function createChallenge(prisma: PrismaClient, config: AppConfig, ipHash: string | null): Promise<PublicChallenge> {
  await assertCaptchaNotThrottled(prisma, config, ipHash);
  const built = buildChallenge();
  const expiresAt = new Date(Date.now() + config.antibot.challengeTtlSeconds * 1000);
  const row = await prisma.captchaChallenge.create({
    data: {
      kind: built.kind,
      prompt: built.prompt,
      options: built.options as unknown as Prisma.InputJsonValue,
      correctToken: built.correctToken,
      ipHash,
      expiresAt,
    },
  });
  return toPublic(row.id, built, expiresAt);
}

/** PNG for one option of a live challenge, or null. No answer information is revealed. */
export async function getOptionImage(prisma: PrismaClient, challengeId: string, token: string): Promise<Buffer | null> {
  const row = await prisma.captchaChallenge.findUnique({ where: { id: challengeId }, select: { options: true, expiresAt: true } });
  if (!row || row.expiresAt.getTime() < Date.now() - 60_000) return null;
  const option = (row.options as unknown as StoredOption[]).find((o) => o.token === token);
  return option ? renderOptionPng(option) : null;
}

export interface SolvedPass {
  pass: string;
  expiresInSeconds: number;
}

/**
 * Validates an answer on the server. A challenge can be answered exactly once: the first
 * attempt atomically claims it, so a wrong guess burns it and the client must request a
 * fresh challenge (no guessing six options against one challenge).
 */
export async function answerChallenge(
  prisma: PrismaClient,
  config: AppConfig,
  challengeId: string,
  optionId: string,
  ipHash: string | null,
): Promise<SolvedPass> {
  await assertCaptchaNotThrottled(prisma, config, ipHash);

  const now = new Date();
  const claimed = await prisma.captchaChallenge.updateMany({
    where: { id: challengeId, answeredAt: null, expiresAt: { gt: now } },
    data: { answeredAt: now },
  });
  if (claimed.count !== 1) {
    const existing = await prisma.captchaChallenge.findUnique({ where: { id: challengeId }, select: { answeredAt: true } });
    if (!existing) throw Errors.notFound('CAPTCHA_NOT_FOUND', 'Challenge not found');
    if (existing.answeredAt) throw Errors.conflict('CAPTCHA_ALREADY_ANSWERED', 'This challenge was already answered');
    throw Errors.unprocessable('CAPTCHA_EXPIRED', 'This challenge has expired');
  }

  const row = await prisma.captchaChallenge.findUniqueOrThrow({ where: { id: challengeId }, select: { correctToken: true } });
  if (!safeEqual(row.correctToken, optionId)) {
    await recordEvent(prisma, { type: 'CAPTCHA_FAILED', ipHash });
    throw Errors.unprocessable('CAPTCHA_WRONG', 'Wrong answer');
  }

  const pass = randomToken(32);
  await prisma.captchaChallenge.update({
    where: { id: challengeId },
    data: {
      solved: true,
      passHash: hmacHex(config.pepper, 'captcha-pass', pass),
      passExpiresAt: new Date(Date.now() + config.antibot.passTtlSeconds * 1000),
    },
  });
  await recordEvent(prisma, { type: 'CAPTCHA_PASSED', ipHash });
  return { pass, expiresInSeconds: config.antibot.passTtlSeconds };
}

// ---------------------------------------------------------------- passes

function passHashOf(config: AppConfig, pass: string): string {
  return hmacHex(config.pepper, 'captcha-pass', pass);
}

function missingPass(): never {
  throw Errors.badRequest('CAPTCHA_REQUIRED', 'Solve the picture challenge first and send its pass');
}

/**
 * Reserves one one-time-code send against a pass (so one solved challenge cannot be used to
 * trigger unlimited SMS / e-mails) without consuming it. Returns the challenge id the code
 * must be bound to, or null when the anti-bot system is disabled.
 */
export async function reservePassForOtp(db: DbClient, config: AppConfig, pass: string | undefined): Promise<string | null> {
  if (!config.antibot.enabled) return null;
  if (!pass) missingPass();
  const passHash = passHashOf(config, pass);
  const reserved = await db.captchaChallenge.updateMany({
    where: {
      passHash,
      solved: true,
      passConsumedAt: null,
      passExpiresAt: { gt: new Date() },
      passOtpSends: { lt: config.antibot.maxOtpSendsPerPass },
    },
    data: { passOtpSends: { increment: 1 } },
  });
  if (reserved.count !== 1) throw Errors.unprocessable('INVALID_CAPTCHA_PASS', 'The sign-up pass is invalid, expired or already used');
  const row = await db.captchaChallenge.findUniqueOrThrow({ where: { passHash }, select: { id: true } });
  return row.id;
}

/**
 * Consumes the pass. Call inside the same transaction that creates the account (or
 * completes the sign-in) so a failure rolls the consumption back and a success makes
 * the pass unusable. `boundChallengeId` ties a pass to the one-time code it authorised.
 */
export async function consumePass(
  db: DbClient,
  config: AppConfig,
  pass: string | undefined,
  boundChallengeId?: string | null,
): Promise<void> {
  if (!config.antibot.enabled) return;
  if (!pass) missingPass();
  const consumed = await db.captchaChallenge.updateMany({
    where: {
      passHash: passHashOf(config, pass),
      solved: true,
      passConsumedAt: null,
      passExpiresAt: { gt: new Date() },
      ...(boundChallengeId ? { id: boundChallengeId } : {}),
    },
    data: { passConsumedAt: new Date() },
  });
  if (consumed.count !== 1) throw Errors.unprocessable('INVALID_CAPTCHA_PASS', 'The sign-up pass is invalid, expired or already used');
}
