import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../../auth/plugin';

const wealthQuery = z.object({
  limit: z.coerce.number().int().min(1).max(50).default(50),
  offset: z.coerce.number().int().min(0).max(10_000).default(0),
});

export async function leaderboardRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: app.authenticate };

  /**
   * Wealth leaderboard. Wealth = current spendable coin balance (WEALTH_DEFINITION=balance).
   * Never reset by leagues or seasons. Suspended players and players with a PRIVATE
   * profile are not listed. Ties are broken by user id so ranks are deterministic.
   */
  app.get('/wealth', auth, async (req) => {
    const { userId } = requireAuth(req);
    const q = wealthQuery.parse(req.query);
    const eligible = { user: { status: 'ACTIVE' as const, isDemo: false, profile: { is: { visibility: { not: 'PRIVATE' as const } } } } };

    const rows = await app.prisma.wallet.findMany({
      where: eligible,
      orderBy: [{ balance: 'desc' }, { userId: 'asc' }],
      skip: q.offset,
      take: q.limit,
      select: {
        balance: true,
        user: { select: { id: true, username: true, profile: { select: { displayName: true, avatarUrl: true, level: true } } } },
      },
    });

    const mine = await app.prisma.wallet.findUnique({
      where: { userId },
      select: { balance: true, user: { select: { profile: { select: { visibility: true } } } } },
    });
    let me: { rank: number | null; wealth: number; listed: boolean } | null = null;
    if (mine) {
      const listed = mine.user.profile?.visibility !== 'PRIVATE';
      const ahead = listed
        ? await app.prisma.wallet.count({
            where: { ...eligible, OR: [{ balance: { gt: mine.balance } }, { balance: mine.balance, userId: { lt: userId } }] },
          })
        : 0;
      me = { rank: listed ? ahead + 1 : null, wealth: mine.balance, listed };
    }

    return {
      definition: app.config.wealthDefinition,
      offset: q.offset,
      items: rows.map((r, i) => ({
        rank: q.offset + i + 1,
        userId: r.user.id,
        username: r.user.username,
        displayName: r.user.profile?.displayName ?? r.user.username,
        avatarUrl: r.user.profile?.avatarUrl ?? null,
        level: r.user.profile?.level ?? 1,
        wealth: r.balance,
      })),
      me,
    };
  });

  app.get('/weekly', auth, async (req) => {
    const { userId } = requireAuth(req);
    const q = wealthQuery.parse(req.query);
    const period = await app.prisma.weeklyLeague.findFirst({ where: { status: 'ACTIVE', endsAt: { gt: new Date() } }, orderBy: { startsAt: 'desc' } });
    if (!period) return { period: null, items: [], me: null };
    const rows = await app.prisma.weeklyLeaderboardEntry.findMany({ where: { leagueId: period.id, user: { status: 'ACTIVE', isDemo: false, profile: { is: { visibility: { not: 'PRIVATE' } } } } }, orderBy: [{ score: 'desc' }, { userId: 'asc' }], skip: q.offset, take: q.limit, include: { user: { select: { id: true, username: true, profile: { select: { displayName: true, level: true } } } } } });
    const mine = await app.prisma.weeklyLeaderboardEntry.findUnique({ where: { leagueId_userId: { leagueId: period.id, userId } }, select: { score: true, user: { select: { profile: { select: { visibility: true } } } } } });
    const ahead = mine && mine.user.profile?.visibility !== 'PRIVATE' ? await app.prisma.weeklyLeaderboardEntry.count({ where: { leagueId: period.id, user: { status: 'ACTIVE', isDemo: false, profile: { is: { visibility: { not: 'PRIVATE' } } } }, OR: [{ score: { gt: mine.score } }, { score: mine.score, userId: { lt: userId } }] } }) : 0;
    return { period: { startsAt: period.startsAt, endsAt: period.endsAt }, items: rows.map((r, i) => ({ rank: q.offset + i + 1, username: r.user.username, displayName: r.user.profile?.displayName ?? r.user.username, level: r.user.profile?.level ?? 1, score: r.score })), me: mine ? { rank: mine.user.profile?.visibility === 'PRIVATE' ? null : ahead + 1, score: mine.score } : null };
  });

  app.get('/season', auth, async (req) => {
    const { userId } = requireAuth(req);
    const q = wealthQuery.parse(req.query);
    const period = await app.prisma.season.findFirst({ where: { status: 'ACTIVE', endsAt: { gt: new Date() } }, orderBy: { startsAt: 'desc' } });
    if (!period) return { period: null, items: [], me: null };
    const rows = await app.prisma.seasonLeaderboardEntry.findMany({ where: { seasonId: period.id, user: { status: 'ACTIVE', isDemo: false, profile: { is: { visibility: { not: 'PRIVATE' } } } } }, orderBy: [{ score: 'desc' }, { userId: 'asc' }], skip: q.offset, take: q.limit, include: { user: { select: { id: true, username: true, profile: { select: { displayName: true, level: true } } } } } });
    const mine = await app.prisma.seasonLeaderboardEntry.findUnique({ where: { seasonId_userId: { seasonId: period.id, userId } }, select: { score: true, user: { select: { profile: { select: { visibility: true } } } } } });
    const ahead = mine && mine.user.profile?.visibility !== 'PRIVATE' ? await app.prisma.seasonLeaderboardEntry.count({ where: { seasonId: period.id, user: { status: 'ACTIVE', isDemo: false, profile: { is: { visibility: { not: 'PRIVATE' } } } }, OR: [{ score: { gt: mine.score } }, { score: mine.score, userId: { lt: userId } }] } }) : 0;
    return { period: { name: period.name, startsAt: period.startsAt, endsAt: period.endsAt }, items: rows.map((r, i) => ({ rank: q.offset + i + 1, username: r.user.username, displayName: r.user.profile?.displayName ?? r.user.username, level: r.user.profile?.level ?? 1, score: r.score })), me: mine ? { rank: mine.user.profile?.visibility === 'PRIVATE' ? null : ahead + 1, score: mine.score } : null };
  });
}
