import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { Errors } from '../../errors';
import { requireAuth } from '../../auth/plugin';

/** The catalogue is sourced only from enabled, non-sample game registrations. */
export async function gameRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: app.authenticate };
  app.get('/', { preHandler: app.authenticate }, async (req) => {
    requireAuth(req);
    const items = await app.prisma.miniGame.findMany({
      where: { enabled: true, isSample: false },
      orderBy: [{ name: 'asc' }, { id: 'asc' }],
      select: { id: true, key: true, name: true, description: true, iconUrl: true, minPlayers: true, maxPlayers: true },
    });
    return { items };
  });

  // Match rooms are backed by real Match/MatchParticipant records. They are a lobby
  // foundation; a game-specific server engine must still validate moves and settle results.
  app.get('/:gameId/rooms', auth, async (req) => {
    const { userId } = requireAuth(req);
    const { gameId } = z.object({ gameId: z.string().min(1).max(80) }).parse(req.params);
    const game = await app.prisma.miniGame.findFirst({ where: { id: gameId, enabled: true, isSample: false }, select: { id: true } });
    if (!game) throw Errors.notFound('GAME_NOT_FOUND', 'Game not found');
    const rooms = await app.prisma.match.findMany({
      where: { gameId, status: 'WAITING', isPrivate: false },
      orderBy: { createdAt: 'asc' }, take: 20,
      include: { participants: { orderBy: { joinedAt: 'asc' }, select: { userId: true, user: { select: { username: true, profile: { select: { displayName: true, level: true } } } } } } },
    });
    return { items: rooms.map((room) => ({
      id: room.id,
      createdAt: room.createdAt,
      players: room.participants.map((p) => ({ userId: p.userId, username: p.user.username, displayName: p.user.profile?.displayName ?? p.user.username, level: p.user.profile?.level ?? 1 })),
      mine: room.participants.some((p) => p.userId === userId),
      owner: room.participants[0]?.userId === userId,
    })) };
  });

  app.post('/:gameId/rooms', { ...auth, config: { rateLimit: { max: 20, timeWindow: '1 minute' } } }, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { gameId } = z.object({ gameId: z.string().min(1).max(80) }).parse(req.params);
    const game = await app.prisma.miniGame.findFirst({ where: { id: gameId, enabled: true, isSample: false }, select: { id: true } });
    if (!game) throw Errors.notFound('GAME_NOT_FOUND', 'Game not found');
    const room = await app.prisma.match.create({
      data: { gameId, participants: { create: { userId } } },
      select: { id: true, createdAt: true, status: true },
    });
    return reply.status(201).send({ ...room, players: 1 });
  });

  app.post('/rooms/:roomId/join', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { roomId } = z.object({ roomId: z.string().min(1).max(80) }).parse(req.params);
    const result = await app.prisma.$transaction(async (tx) => {
      // Serialize joins to this room so two simultaneous requests cannot overfill it.
      await tx.$queryRaw`SELECT "id" FROM "Match" WHERE "id" = ${roomId} FOR UPDATE`;
      const room = await tx.match.findUnique({ where: { id: roomId }, include: { game: true, participants: { select: { userId: true } } } });
      if (!room || room.isPrivate || !room.game.enabled || room.game.isSample) throw Errors.notFound('ROOM_NOT_FOUND', 'Match room not found');
      if (room.status !== 'WAITING') throw Errors.conflict('ROOM_NOT_WAITING', 'This room is no longer waiting for players');
      if (room.participants.some((participant) => participant.userId === userId)) throw Errors.conflict('ALREADY_IN_ROOM', 'You already joined this room');
      if (room.participants.length >= room.game.maxPlayers) throw Errors.conflict('ROOM_FULL', 'This room is full');
      await tx.matchParticipant.create({ data: { matchId: room.id, userId } });
      const players = room.participants.length + 1;
      const updated = players >= room.game.maxPlayers
        ? await tx.match.update({ where: { id: room.id }, data: { status: 'ACTIVE', startedAt: new Date() }, select: { id: true, status: true } })
        : { id: room.id, status: room.status };
      return { ...updated, players };
    });
    return reply.send(result);
  });

  app.post('/rooms/:roomId/cancel', auth, async (req) => {
    const { userId } = requireAuth(req);
    const { roomId } = z.object({ roomId: z.string().min(1).max(80) }).parse(req.params);
    await app.prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT "id" FROM "Match" WHERE "id" = ${roomId} FOR UPDATE`;
      const room = await tx.match.findUnique({ where: { id: roomId }, include: { participants: { orderBy: { joinedAt: 'asc' }, select: { userId: true } } } });
      if (!room) throw Errors.notFound('ROOM_NOT_FOUND', 'Match room not found');
      if (room.status !== 'WAITING') throw Errors.conflict('ROOM_NOT_WAITING', 'This room is no longer waiting for players');
      if (room.participants[0]?.userId !== userId) throw Errors.forbidden('ROOM_OWNER_ONLY', 'Only the room owner can cancel it');
      await tx.match.delete({ where: { id: roomId } });
    });
    return { cancelled: true };
  });
}
