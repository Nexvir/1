import type { IdentityProvider, User } from '@prisma/client';
import type { AppConfig } from '../../config';
import type { DbClient } from '../../db';
import { AppError, Errors, isUniqueViolation } from '../../errors';
import { consumePass } from '../antibot/service';
import { assertAccountCreationAllowed, createAccountTx, recordAccountCreated } from '../accounts/service';

export type SignInMethod = 'phone' | 'email' | 'google';

export interface ResolvedLogin {
  user: Pick<User, 'id' | 'username' | 'accountCode' | 'status' | 'isGuest' | 'lastActivityAt'> & { displayName: string };
  isNewAccount: boolean;
}

/**
 * Signs in the account that owns `provider:identifier`, or creates it. Runs inside the caller's
 * transaction. This is the single place that creates accounts for phone / e-mail / Google, so
 * an identifier can never end up on two accounts and existing accounts are never merged.
 *
 * `passPolicy`: "always" consumes the CAPTCHA pass even for existing accounts (one-time-code
 * flows, where a pass authorised the SMS/e-mail); "onCreate" only when a new account is made
 * (Google, whose token already proves identity).
 */
export async function resolveIdentityLogin(
  tx: DbClient,
  config: AppConfig,
  p: {
    provider: IdentityProvider;
    identifier: string;
    method: SignInMethod;
    captchaPass?: string;
    boundChallengeId?: string | null;
    passPolicy: 'always' | 'onCreate';
    ipHash: string | null;
  },
): Promise<ResolvedLogin> {
  const select = {
    id: true,
    username: true,
    accountCode: true,
    status: true,
    isGuest: true,
    lastActivityAt: true,
    profile: { select: { displayName: true } },
  } as const;

  const existing = await tx.authIdentity.findUnique({
    where: { provider_identifier: { provider: p.provider, identifier: p.identifier } },
    select: { id: true, user: { select } },
  });

  if (existing) {
    if (p.passPolicy === 'always') await consumePass(tx, config, p.captchaPass, p.boundChallengeId);
    if (existing.user.status === 'SUSPENDED') throw new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended');
    await tx.authIdentity.update({ where: { id: existing.id }, data: { lastUsedAt: new Date() } });
    const { profile, ...u } = existing.user;
    return { user: { ...u, displayName: profile?.displayName ?? u.username }, isNewAccount: false };
  }

  await consumePass(tx, config, p.captchaPass, p.boundChallengeId);
  await assertAccountCreationAllowed(tx, config, p.ipHash);
  const created = await createAccountTx(tx, config, { kind: 'regular' });
  await tx.authIdentity.create({ data: { userId: created.id, provider: p.provider, identifier: p.identifier, lastUsedAt: new Date() } });
  await recordAccountCreated(tx, created, p.ipHash, p.method);
  const profile = await tx.userProfile.findUniqueOrThrow({ where: { userId: created.id }, select: { displayName: true } });
  return {
    user: {
      id: created.id,
      username: created.username,
      accountCode: created.accountCode,
      status: created.status,
      isGuest: false,
      lastActivityAt: created.lastActivityAt,
      displayName: profile.displayName,
    },
    isNewAccount: true,
  };
}

/**
 * Attaches a verified identity to an existing account (usually a guest) in place: same user id,
 * same data, no new account. If the identifier already belongs to ANOTHER account nothing is
 * merged or changed; the caller gets IDENTITY_IN_USE. A guest becomes a normal account, which
 * takes it out of the inactivity-deletion policy.
 */
export async function linkIdentity(
  tx: DbClient,
  p: { userId: string; provider: IdentityProvider; identifier: string },
): Promise<void> {
  // Serialize against the cleanup job and other linking attempts for this account.
  await tx.$queryRaw`SELECT "id" FROM "User" WHERE "id" = ${p.userId} FOR UPDATE`;

  const mine = await tx.authIdentity.findUnique({ where: { userId_provider: { userId: p.userId, provider: p.provider } }, select: { id: true } });
  if (mine) throw Errors.conflict('ALREADY_LINKED', 'This sign-in method is already linked to your account');

  const owner = await tx.authIdentity.findUnique({
    where: { provider_identifier: { provider: p.provider, identifier: p.identifier } },
    select: { userId: true },
  });
  if (owner) throw Errors.conflict('IDENTITY_IN_USE', 'This sign-in method already belongs to another account; accounts are not merged automatically');

  try {
    await tx.authIdentity.create({ data: { userId: p.userId, provider: p.provider, identifier: p.identifier, lastUsedAt: new Date() } });
  } catch (err) {
    if (isUniqueViolation(err)) throw Errors.conflict('IDENTITY_IN_USE', 'This sign-in method already belongs to another account; accounts are not merged automatically');
    throw err;
  }

  await tx.user.updateMany({ where: { id: p.userId, isGuest: true }, data: { isGuest: false, guestConvertedAt: new Date() } });
  await tx.auditLog.create({
    data: { actorId: p.userId, action: 'account.identity_linked', entityType: 'User', entityId: p.userId, metadata: { provider: p.provider } },
  });
}
