import type { FastifyInstance } from 'fastify';
import type { IdentityProvider, OtpChannel } from '@prisma/client';
import { z } from 'zod';
import { Errors } from '../../errors';
import { requireAuth } from '../../auth/plugin';
import { maskEmail, maskPhone, normalizePhone } from '../../auth/contact';
import { openSession } from '../../auth/sessions';
import { toAccountSummary, withGeneratedIdRetry } from '../accounts/service';
import { ipHashOf, recordEvent } from '../security/events';
import { linkIdentity, resolveIdentityLogin } from './identity';
import { checkOtp, consumeOtp, requestOtp } from './otp';
import { captchaPassSchema } from './routes';

const channelSchema = z.enum(['EMAIL', 'PHONE']);
const emailSchema = z.string().trim().toLowerCase().email().max(254);

const destinationBody = z.object({ channel: channelSchema, destination: z.string().trim().min(3).max(254) });
const requestBody = destinationBody.extend({ captchaPass: captchaPassSchema.optional() });
const verifyBody = destinationBody.extend({
  code: z.string().trim().regex(/^\d{6}$/, 'The code has 6 digits'),
  captchaPass: captchaPassSchema.optional(),
});
const linkVerifyBody = destinationBody.extend({ code: z.string().trim().regex(/^\d{6}$/, 'The code has 6 digits') });
const googleBody = z.object({ idToken: z.string().min(20).max(4096), captchaPass: captchaPassSchema.optional() });
const googleLinkBody = z.object({ idToken: z.string().min(20).max(4096) });

function normalizeDestination(channel: OtpChannel, raw: string): string {
  if (channel === 'EMAIL') {
    const parsed = emailSchema.safeParse(raw);
    if (!parsed.success) throw Errors.badRequest('VALIDATION_ERROR', 'Enter a valid e-mail address');
    return parsed.data;
  }
  const phone = normalizePhone(raw);
  if (!phone) throw Errors.badRequest('INVALID_PHONE', 'Enter a valid phone number, e.g. 09123456789');
  return phone;
}

const providerOf = (channel: OtpChannel): IdentityProvider => (channel === 'EMAIL' ? 'EMAIL' : 'PHONE');
const methodOf = (channel: OtpChannel) => (channel === 'EMAIL' ? ('email' as const) : ('phone' as const));

/** Phone / e-mail one-time-code sign-in, Google sign-in, and linking a method to an existing account. */
export async function identityRoutes(app: FastifyInstance): Promise<void> {
  const { config, prisma } = app;
  const limit = { rateLimit: { max: config.authRateLimitMax, timeWindow: '1 minute' } };
  const auth = { preHandler: app.authenticate };

  /** What the welcome screen may offer. Unconfigured methods are reported as unavailable, never faked. */
  app.get('/methods', async () => ({
    guest: { available: true },
    google: { available: app.googleVerifier !== null },
    email: { available: app.deliveries.email !== null },
    phone: { available: app.deliveries.sms !== null },
    antibot: { required: config.antibot.enabled },
    guestPolicy: { inactivityMonths: config.guest.inactivityMonths },
  }));

  // ------------------------------------------------------------ sign in / sign up with a one-time code

  app.post('/otp/request', { config: limit }, async (req) => {
    const body = requestBody.parse(req.body);
    const destination = normalizeDestination(body.channel, body.destination);
    const sent = await requestOtp(prisma, config, app.deliveries, {
      channel: body.channel,
      destination,
      purpose: 'LOGIN',
      captchaPass: body.captchaPass,
      ipHash: ipHashOf(config, req.ip),
    });
    // Identical whether or not an account exists for this destination.
    return { sent: true, ...sent };
  });

  app.post('/otp/verify', { config: limit }, async (req, reply) => {
    const body = verifyBody.parse(req.body);
    const destination = normalizeDestination(body.channel, body.destination);
    const ipHash = ipHashOf(config, req.ip);

    const otp = await checkOtp(prisma, config, { channel: body.channel, destination, purpose: 'LOGIN', code: body.code, ipHash });

    const login = await withGeneratedIdRetry(() =>
      prisma.$transaction(async (tx) => {
        await consumeOtp(tx, otp.id);
        return resolveIdentityLogin(tx, config, {
          provider: providerOf(body.channel),
          identifier: destination,
          method: methodOf(body.channel),
          captchaPass: body.captchaPass,
          boundChallengeId: otp.captchaChallengeId,
          passPolicy: 'always',
          ipHash,
        });
      }),
    );

    const { tokens, notice } = await openSession(prisma, config, login.user);
    await recordEvent(prisma, { type: 'OTP_LOGIN', userId: login.user.id, ipHash, metadata: { channel: body.channel, isNewAccount: login.isNewAccount } });
    return reply.status(login.isNewAccount ? 201 : 200).header('cache-control', 'no-store').send({
      account: { ...toAccountSummary({ ...login.user, profile: { displayName: login.user.displayName } }), isGuest: false },
      isNewAccount: login.isNewAccount,
      tokens,
      ...(notice ? { notice } : {}),
    });
  });

  // ------------------------------------------------------------ Google

  app.post('/google', { config: limit }, async (req, reply) => {
    const body = googleBody.parse(req.body);
    const verifier = app.googleVerifier;
    if (!verifier) throw Errors.unavailable('GOOGLE_NOT_CONFIGURED', 'Google sign-in is not configured on this server');

    // Only the identity proven by Google's signed token is used. Any name / e-mail / id the
    // client sends alongside is ignored.
    let sub: string;
    try {
      sub = (await verifier.verify(body.idToken)).sub;
    } catch {
      throw Errors.unauthorized('Google token could not be verified', 'INVALID_GOOGLE_TOKEN');
    }

    const ipHash = ipHashOf(config, req.ip);
    const login = await withGeneratedIdRetry(() =>
      prisma.$transaction((tx) =>
        resolveIdentityLogin(tx, config, {
          provider: 'GOOGLE',
          identifier: sub,
          method: 'google',
          captchaPass: body.captchaPass,
          passPolicy: 'onCreate',
          ipHash,
        }),
      ),
    );

    const { tokens, notice } = await openSession(prisma, config, login.user);
    await recordEvent(prisma, { type: 'GOOGLE_LOGIN', userId: login.user.id, ipHash, metadata: { isNewAccount: login.isNewAccount } });
    return reply.status(login.isNewAccount ? 201 : 200).header('cache-control', 'no-store').send({
      account: { ...toAccountSummary({ ...login.user, profile: { displayName: login.user.displayName } }), isGuest: false },
      isNewAccount: login.isNewAccount,
      tokens,
      ...(notice ? { notice } : {}),
    });
  });

  // ------------------------------------------------------------ link a method to the signed-in account

  async function conflictAware<T>(userId: string, ipHash: string | null, provider: IdentityProvider, fn: () => Promise<T>): Promise<T> {
    try {
      return await fn();
    } catch (err) {
      if (err instanceof Error && 'code' in err && (err as { code: string }).code === 'IDENTITY_IN_USE') {
        await recordEvent(prisma, { type: 'IDENTITY_LINK_CONFLICT', userId, ipHash, metadata: { provider } });
      }
      throw err;
    }
  }

  async function linkedResponse(userId: string, provider: IdentityProvider, masked: string) {
    const user = await prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { id: true, accountCode: true, isGuest: true } });
    return { linked: { provider, masked }, account: { id: user.id, accountCode: user.accountCode, isGuest: user.isGuest } };
  }

  app.post('/link/otp/request', { ...auth, config: limit }, async (req) => {
    const { userId } = requireAuth(req);
    const body = destinationBody.parse(req.body);
    const destination = normalizeDestination(body.channel, body.destination);

    const mine = await prisma.authIdentity.findUnique({ where: { userId_provider: { userId, provider: providerOf(body.channel) } }, select: { id: true } });
    if (mine) throw Errors.conflict('ALREADY_LINKED', 'This sign-in method is already linked to your account');

    const sent = await requestOtp(prisma, config, app.deliveries, {
      channel: body.channel,
      destination,
      purpose: 'LINK',
      userId,
      ipHash: ipHashOf(config, req.ip),
    });
    return { sent: true, ...sent };
  });

  app.post('/link/otp/verify', { ...auth, config: limit }, async (req) => {
    const { userId } = requireAuth(req);
    const body = linkVerifyBody.parse(req.body);
    const destination = normalizeDestination(body.channel, body.destination);
    const ipHash = ipHashOf(config, req.ip);
    const provider = providerOf(body.channel);

    // Ownership of the destination is proven by the code, so only now is it safe to tell the
    // player that it already belongs to a different account.
    const otp = await checkOtp(prisma, config, { channel: body.channel, destination, purpose: 'LINK', code: body.code, userId, ipHash });
    await conflictAware(userId, ipHash, provider, () =>
      prisma.$transaction(async (tx) => {
        await consumeOtp(tx, otp.id);
        await linkIdentity(tx, { userId, provider, identifier: destination });
      }),
    );
    await recordEvent(prisma, { type: 'IDENTITY_LINKED', userId, ipHash, metadata: { provider } });
    return linkedResponse(userId, provider, body.channel === 'PHONE' ? maskPhone(destination) : maskEmail(destination));
  });

  app.post('/link/google', { ...auth, config: limit }, async (req) => {
    const { userId } = requireAuth(req);
    const body = googleLinkBody.parse(req.body);
    const verifier = app.googleVerifier;
    if (!verifier) throw Errors.unavailable('GOOGLE_NOT_CONFIGURED', 'Google sign-in is not configured on this server');

    let sub: string;
    try {
      sub = (await verifier.verify(body.idToken)).sub;
    } catch {
      throw Errors.unauthorized('Google token could not be verified', 'INVALID_GOOGLE_TOKEN');
    }
    const ipHash = ipHashOf(config, req.ip);
    await conflictAware(userId, ipHash, 'GOOGLE', () =>
      prisma.$transaction((tx) => linkIdentity(tx, { userId, provider: 'GOOGLE', identifier: sub })),
    );
    await recordEvent(prisma, { type: 'IDENTITY_LINKED', userId, ipHash, metadata: { provider: 'GOOGLE' } });
    return linkedResponse(userId, 'GOOGLE', 'Google');
  });
}
