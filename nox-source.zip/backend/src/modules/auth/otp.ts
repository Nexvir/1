import crypto from 'node:crypto';
import type { OtpChannel, OtpCode, OtpPurpose, PrismaClient } from '@prisma/client';
import type { AppConfig } from '../../config';
import type { Deliveries } from '../../auth/delivery';
import { Errors } from '../../errors';
import { generateOtpCode, hmacHex, safeEqual } from '../../auth/codes';
import { reservePassForOtp } from '../antibot/service';
import { countEvents, recordEvent } from '../security/events';

const HOUR = 3_600_000;

export function destinationHashOf(config: AppConfig, channel: OtpChannel, destination: string): string {
  return hmacHex(config.pepper, `otp-dest:${channel}`, destination);
}

function codeHashOf(config: AppConfig, id: string, code: string): string {
  return hmacHex(config.pepper, 'otp-code', `${id}:${code}`);
}

export interface RequestOtpInput {
  channel: OtpChannel;
  /** Already normalized (lower-case e-mail / E.164 phone). */
  destination: string;
  purpose: OtpPurpose;
  userId?: string;
  captchaPass?: string;
  ipHash: string | null;
}

/**
 * Creates and sends a one-time code. Replies are identical whether or not an account exists
 * for the destination. Errors are raised BEFORE anything is sent; if delivery itself fails,
 * the code is deleted and the caller is told so (no fake success).
 */
export async function requestOtp(
  prisma: PrismaClient,
  config: AppConfig,
  deliveries: Deliveries,
  input: RequestOtpInput,
): Promise<{ expiresInSeconds: number; resendAfterSeconds: number }> {
  const sender = input.channel === 'EMAIL' ? deliveries.email : deliveries.sms;
  if (!sender) {
    throw input.channel === 'EMAIL'
      ? Errors.unavailable('EMAIL_NOT_CONFIGURED', 'E-mail sign-in is not configured on this server')
      : Errors.unavailable('SMS_NOT_CONFIGURED', 'Phone sign-in is not configured on this server');
  }

  const { otp: cfg } = config;
  const destinationHash = destinationHashOf(config, input.channel, input.destination);
  const id = crypto.randomUUID();
  const code = generateOtpCode();

  await prisma.$transaction(async (tx) => {
    // Serialize concurrent requests for the same destination so cooldown / caps cannot be raced.
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${destinationHash}))`;

    const last = await tx.otpCode.findFirst({ where: { destinationHash }, orderBy: { createdAt: 'desc' }, select: { createdAt: true } });
    if (last && cfg.resendCooldownSeconds > 0) {
      const waitMs = last.createdAt.getTime() + cfg.resendCooldownSeconds * 1000 - Date.now();
      if (waitMs > 0) throw Errors.tooMany('OTP_COOLDOWN', 'A code was just sent; wait before requesting another', waitMs / 1000);
    }
    const sentToDestination = await tx.otpCode.count({ where: { destinationHash, createdAt: { gte: new Date(Date.now() - HOUR) } } });
    if (sentToDestination >= cfg.maxPerDestinationHour) {
      throw Errors.tooMany('OTP_LIMIT_REACHED', 'Too many codes were requested for this destination', 1800);
    }
    if (input.ipHash) {
      const sentFromIp = await tx.otpCode.count({ where: { ipHash: input.ipHash, createdAt: { gte: new Date(Date.now() - HOUR) } } });
      if (sentFromIp >= cfg.maxPerIpHour) throw Errors.tooMany('OTP_LIMIT_REACHED', 'Too many codes were requested from this network', 1800);
    }
    if (input.userId) {
      const sentForUser = await tx.otpCode.count({ where: { userId: input.userId, createdAt: { gte: new Date(Date.now() - HOUR) } } });
      if (sentForUser >= cfg.maxPerUserHour) throw Errors.tooMany('OTP_LIMIT_REACHED', 'Too many codes were requested for this account', 1800);
    }

    // Login/sign-up codes must be authorised by a solved picture challenge; link codes by the signed-in user.
    const captchaChallengeId = input.purpose === 'LOGIN' ? await reservePassForOtp(tx, config, input.captchaPass) : null;

    // Only the newest code for a destination is ever valid.
    await tx.otpCode.updateMany({ where: { destinationHash, consumedAt: null }, data: { consumedAt: new Date() } });
    await tx.otpCode.create({
      data: {
        id,
        channel: input.channel,
        purpose: input.purpose,
        destinationHash,
        codeHash: codeHashOf(config, id, code),
        userId: input.userId ?? null,
        captchaChallengeId,
        ipHash: input.ipHash,
        maxAttempts: cfg.maxAttempts,
        expiresAt: new Date(Date.now() + cfg.ttlSeconds * 1000),
      },
    });
  });

  try {
    await sender.send(input.destination, code, cfg.ttlSeconds);
  } catch {
    // Not delivered: invalidate the code and say so honestly. Nothing about the error is logged here
    // because provider errors can echo the destination or code.
    await prisma.otpCode.deleteMany({ where: { id } });
    throw Errors.badGateway('DELIVERY_FAILED', 'The code could not be delivered');
  }

  await recordEvent(prisma, { type: 'OTP_REQUESTED', userId: input.userId ?? null, ipHash: input.ipHash, metadata: { channel: input.channel, purpose: input.purpose } });
  return { expiresInSeconds: cfg.ttlSeconds, resendAfterSeconds: cfg.resendCooldownSeconds };
}

export interface CheckOtpInput {
  channel: OtpChannel;
  destination: string;
  purpose: OtpPurpose;
  code: string;
  userId?: string;
  ipHash: string | null;
}

/**
 * Checks a code without consuming it. Every check (right or wrong) uses up one attempt of the
 * newest live code, so a six-digit code cannot be brute-forced. Returns the code row; the
 * caller consumes it with `consumeOtp` inside the transaction that completes the sign-in.
 */
export async function checkOtp(prisma: PrismaClient, config: AppConfig, input: CheckOtpInput): Promise<OtpCode> {
  const destinationHash = destinationHashOf(config, input.channel, input.destination);
  const fail = async (): Promise<never> => {
    await recordEvent(prisma, { type: 'OTP_FAILED', userId: input.userId ?? null, ipHash: input.ipHash, metadata: { channel: input.channel } });
    throw Errors.unprocessable('INVALID_OTP', 'The code is wrong or has expired');
  };

  // Anonymous guessing against many destinations is bounded per source.
  const recentFailures = await countEvents(prisma, { type: 'OTP_FAILED', ipHash: input.ipHash, sinceMs: 600_000 });
  if (recentFailures >= config.otp.maxAttempts * 6) {
    throw Errors.tooMany('OTP_ATTEMPTS_EXCEEDED', 'Too many wrong codes from this network', 300);
  }

  const now = new Date();
  const live = await prisma.otpCode.findFirst({
    where: {
      destinationHash,
      channel: input.channel,
      purpose: input.purpose,
      consumedAt: null,
      expiresAt: { gt: now },
      ...(input.purpose === 'LINK' ? { userId: input.userId ?? '__none__' } : {}),
    },
    orderBy: { createdAt: 'desc' },
  });
  if (!live) return fail();

  // Atomically use up one attempt; once the budget is gone the code is dead.
  const claimed = await prisma.otpCode.updateMany({
    where: { id: live.id, consumedAt: null, expiresAt: { gt: now }, attempts: { lt: live.maxAttempts } },
    data: { attempts: { increment: 1 } },
  });
  if (claimed.count !== 1) {
    throw Errors.tooMany('OTP_ATTEMPTS_EXCEEDED', 'Too many wrong codes; request a new one', 60);
  }

  if (!safeEqual(live.codeHash, codeHashOf(config, live.id, input.code))) return fail();
  return live;
}

/** Marks a verified code as used. Call inside the completing transaction; throws if it was already used. */
export async function consumeOtp(tx: Pick<PrismaClient, 'otpCode'>, id: string): Promise<void> {
  const res = await tx.otpCode.updateMany({ where: { id, consumedAt: null, expiresAt: { gt: new Date() } }, data: { consumedAt: new Date() } });
  if (res.count !== 1) throw Errors.unprocessable('INVALID_OTP', 'The code is wrong or has expired');
}
