import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { AppError, Errors, isUniqueViolation } from '../../errors';
import { hashPassword, verifyDummy, verifyPassword } from '../../auth/password';
import { openSession } from '../../auth/sessions';
import { hashToken } from '../../auth/tokens';
import { consumePass } from '../antibot/service';
import {
  assertAccountCreationAllowed,
  createAccountTx,
  recordAccountCreated,
  toAccountSummary,
} from '../accounts/service';
import { ipHashOf } from '../security/events';

export const usernameSchema = z
  .string()
  .trim()
  .toLowerCase()
  .regex(/^[a-z0-9_]{3,20}$/, 'Username must be 3-20 characters: letters, digits or underscore')
  .refine((username) => username !== 'nox_official', 'This username is reserved');

export const captchaPassSchema = z.string().min(20).max(100);

const registerSchema = z.object({
  username: usernameSchema,
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(8, 'Password must be at least 8 characters').max(128),
  displayName: z.string().trim().min(1).max(30).optional(),
  captchaPass: captchaPassSchema.optional(),
});

const loginSchema = z.object({
  identifier: z.string().trim().toLowerCase().min(3).max(254),
  password: z.string().min(1).max(128),
});

const refreshSchema = z.object({ refreshToken: z.string().min(20).max(200) });

/**
 * Classic username / e-mail + password accounts. Kept for backward compatibility; the
 * primary entry points are the guest, phone, e-mail-code and Google flows. Its e-mail is
 * NOT verified, so it is never treated as a sign-in identity (see docs/AUTH.md).
 */
export async function authRoutes(app: FastifyInstance): Promise<void> {
  const limit = { rateLimit: { max: app.config.authRateLimitMax, timeWindow: '1 minute' } };
  const { config, prisma } = app;

  app.post('/register', { config: limit }, async (req, reply) => {
    const body = registerSchema.parse(req.body);
    if (config.antibot.enabled && !body.captchaPass) {
      throw Errors.badRequest('CAPTCHA_REQUIRED', 'Solve the picture challenge first and send its pass');
    }
    if (body.password.toLowerCase() === body.username) {
      throw Errors.badRequest('WEAK_PASSWORD', 'Password must not equal the username');
    }
    const ipHash = ipHashOf(config, req.ip);
    await assertAccountCreationAllowed(prisma, config, ipHash);
    const passwordHash = await hashPassword(body.password);

    try {
      const user = await prisma.$transaction(async (tx) => {
        // Consumed in the same transaction that creates the account: a failure (e.g. a taken
        // username) rolls it back so the player can retry; a success makes it unusable.
        await consumePass(tx, config, body.captchaPass);
        const created = await createAccountTx(tx, config, {
          kind: 'regular',
          displayName: body.displayName,
          legacy: { username: body.username, email: body.email, passwordHash },
        });
        await recordAccountCreated(tx, created, ipHash, 'password');
        return created;
      });
      const { tokens } = await openSession(prisma, config, user);
      return reply.status(201).send({
        user: { ...toAccountSummary({ ...user, profile: { displayName: body.displayName ?? body.username } }) },
        tokens,
      });
    } catch (err) {
      if (isUniqueViolation(err)) throw Errors.conflict('ACCOUNT_EXISTS', 'Username or email is already in use');
      throw err;
    }
  });

  app.post('/login', { config: limit }, async (req) => {
    const body = loginSchema.parse(req.body);
    const user = await prisma.user.findFirst({
      where: { OR: [{ username: body.identifier }, { email: body.identifier }] },
      include: { profile: { select: { displayName: true } } },
    });
    // Guests (and phone / e-mail-code / Google accounts) have no password: same answer as a wrong one.
    if (!user || !user.passwordHash) {
      await verifyDummy(body.password);
      throw Errors.unauthorized('Invalid credentials', 'INVALID_CREDENTIALS');
    }
    if (!(await verifyPassword(user.passwordHash, body.password))) {
      throw Errors.unauthorized('Invalid credentials', 'INVALID_CREDENTIALS');
    }
    if (user.status === 'SUSPENDED') throw new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended');

    const { tokens, notice } = await openSession(prisma, config, user);
    return { user: toAccountSummary(user), tokens, ...(notice ? { notice } : {}) };
  });

  app.post('/refresh', { config: limit }, async (req) => {
    const { refreshToken } = refreshSchema.parse(req.body);
    const record = await prisma.refreshToken.findUnique({
      where: { tokenHash: hashToken(refreshToken) },
      include: { user: { select: { id: true, status: true, isGuest: true, lastActivityAt: true } } },
    });
    if (!record) throw Errors.unauthorized('Invalid refresh token', 'INVALID_REFRESH_TOKEN');

    if (record.revokedAt) {
      // A rotated token was presented again: assume theft and kill every session of this user.
      await prisma.refreshToken.updateMany({
        where: { userId: record.userId, revokedAt: null },
        data: { revokedAt: new Date() },
      });
      throw Errors.unauthorized('Invalid refresh token', 'INVALID_REFRESH_TOKEN');
    }
    if (record.expiresAt <= new Date()) throw Errors.unauthorized('Refresh token expired', 'INVALID_REFRESH_TOKEN');
    if (record.user.status === 'SUSPENDED') throw new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended');

    // Rotation: exactly one concurrent caller can consume the token.
    const consumed = await prisma.refreshToken.updateMany({
      where: { id: record.id, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    if (consumed.count !== 1) throw Errors.unauthorized('Invalid refresh token', 'INVALID_REFRESH_TOKEN');

    const { tokens, notice } = await openSession(prisma, config, record.user);
    return { tokens, ...(notice ? { notice } : {}) };
  });

  app.post('/logout', async (req, reply) => {
    const { refreshToken } = refreshSchema.parse(req.body);
    await prisma.refreshToken.updateMany({
      where: { tokenHash: hashToken(refreshToken), revokedAt: null },
      data: { revokedAt: new Date() },
    });
    return reply.status(204).send();
  });
}
