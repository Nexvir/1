import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { AppError, Errors } from '../../errors';
import { requireAuth } from '../../auth/plugin';
import { generateRecoveryCode, hmacHex, normalizeAccountCode, normalizeRecoveryCode, safeEqual } from '../../auth/codes';
import { maskEmail, maskPhone } from '../../auth/contact';
import { openSession, revokeAllSessions } from '../../auth/sessions';
import { consumePass } from '../antibot/service';
import { guestExpiry } from '../accounts/activity';
import { hashRecoveryCode, recoveryLockMinutes, recoveryThrottleKey } from '../accounts/recovery';
import {
  assertAccountCreationAllowed,
  createAccountTx,
  recordAccountCreated,
  toAccountSummary,
  withGeneratedIdRetry,
} from '../accounts/service';
import { countEvents, ipHashOf, recordEvent } from '../security/events';
import { captchaPassSchema } from './routes';

const guestBody = z.object({
  captchaPass: captchaPassSchema.optional(),
  displayName: z.string().trim().min(1).max(30).optional(),
});

const recoverBody = z.object({
  accountCode: z.string().trim().min(3).max(40),
  recoveryCode: z.string().trim().min(10).max(60),
});

const RECOVERY_WARNING_FA =
  'این کد بازیابی فقط همین یک بار نمایش داده می‌شود. آن را در جای امن نگه دار (کپی کن یا یادداشتش کن). ' +
  'اگر بازی را حذف کنی یا گوشی‌ات را عوض کنی، فقط با «شناسه حساب» و «کد بازیابی» می‌توانی پیشرفتت را برگردانی. ' +
  'کد بازیابی را به هیچ‌کس نگو.';

/** Guest accounts, account recovery and account status. */
export async function guestRoutes(app: FastifyInstance): Promise<void> {
  const { config, prisma } = app;
  const limit = { rateLimit: { max: config.authRateLimitMax, timeWindow: '1 minute' } };
  const auth = { preHandler: app.authenticate };

  /** Quick-start guest account: unique ID + secret recovery code, progress stored on the server. */
  app.post('/guest', { config: limit }, async (req, reply) => {
    const body = guestBody.parse(req.body ?? {});
    if (config.antibot.enabled && !body.captchaPass) {
      throw Errors.badRequest('CAPTCHA_REQUIRED', 'Solve the picture challenge first and send its pass');
    }
    const ipHash = ipHashOf(config, req.ip);
    await assertAccountCreationAllowed(prisma, config, ipHash);

    const recoveryCode = generateRecoveryCode();
    const user = await withGeneratedIdRetry(() =>
      prisma.$transaction(async (tx) => {
        await consumePass(tx, config, body.captchaPass);
        // The account code is generated inside createAccountTx, so hash after we know it.
        const created = await createAccountTx(tx, config, { kind: 'guest', displayName: body.displayName });
        await tx.user.update({
          where: { id: created.id },
          data: {
            recoveryCodeHash: hashRecoveryCode(config, created.accountCode, normalizeRecoveryCode(recoveryCode)!),
            recoveryCodeRotatedAt: new Date(),
          },
        });
        await recordAccountCreated(tx, created, ipHash, 'guest');
        await recordEvent(tx, { type: 'GUEST_CREATED', userId: created.id, ipHash });
        return created;
      }),
    );

    const profile = await prisma.userProfile.findUniqueOrThrow({ where: { userId: user.id }, select: { displayName: true } });
    const { tokens } = await openSession(prisma, config, user);
    return reply
      .status(201)
      .header('cache-control', 'no-store')
      .send({
        account: { ...toAccountSummary({ ...user, profile }), isGuest: true },
        // Shown ONCE. Only an HMAC of it is stored, so it cannot be shown again.
        recoveryCode,
        recoveryWarningFa: RECOVERY_WARNING_FA,
        guestPolicy: { inactivityMonths: config.guest.inactivityMonths },
        tokens,
      });
  });

  /**
   * Recover an account with its ID + recovery code (reinstall / new phone). The ID alone is not
   * enough. No new account is created; all progress stays with the same account.
   */
  app.post('/recover', { config: limit }, async (req, reply) => {
    const body = recoverBody.parse(req.body);
    const accountCode = normalizeAccountCode(body.accountCode);
    const code = normalizeRecoveryCode(body.recoveryCode);
    if (!accountCode || !code) throw Errors.badRequest('INVALID_RECOVERY_FORMAT', 'Account ID or recovery code has the wrong format');

    const ipHash = ipHashOf(config, req.ip);
    if ((await countEvents(prisma, { type: 'RECOVERY_FAILED', ipHash, sinceMs: 15 * 60_000 })) >= config.recovery.failedPerIp15Min) {
      throw Errors.tooMany('RECOVERY_IP_LIMIT', 'Too many failed recovery attempts from this network', 600);
    }

    // The failure counter is keyed by the submitted account code, whether or not it exists,
    // so existing and non-existing accounts lock out identically (no account enumeration).
    const throttleKey = recoveryThrottleKey(config, accountCode);
    const throttle = await prisma.authThrottle.findUnique({ where: { key: throttleKey } });
    if (throttle?.lockedUntil && throttle.lockedUntil.getTime() > Date.now()) {
      throw Errors.tooMany('RECOVERY_LOCKED', 'Too many failed attempts; this account is temporarily locked', (throttle.lockedUntil.getTime() - Date.now()) / 1000);
    }

    const user = await prisma.user.findUnique({
      where: { accountCode },
      select: {
        id: true,
        username: true,
        accountCode: true,
        status: true,
        isGuest: true,
        lastActivityAt: true,
        recoveryCodeHash: true,
        profile: { select: { displayName: true } },
      },
    });

    // Always compute and compare, so timing does not reveal whether the account exists.
    const computed = hashRecoveryCode(config, accountCode, code);
    const expected = user?.recoveryCodeHash ?? hmacHex(config.pepper, 'recovery-dummy', accountCode);
    const ok = safeEqual(computed, expected) && !!user?.recoveryCodeHash;

    if (!ok) {
      // A stale counter (no failure for 24 h) starts over.
      const stale = throttle && Date.now() - throttle.lastFailureAt.getTime() > 24 * 3_600_000;
      if (stale) await prisma.authThrottle.deleteMany({ where: { key: throttleKey } });
      const row = await prisma.authThrottle.upsert({
        where: { key: throttleKey },
        create: { key: throttleKey, failures: 1 },
        update: { failures: { increment: 1 }, lastFailureAt: new Date() },
      });
      await recordEvent(prisma, { type: 'RECOVERY_FAILED', userId: user?.id ?? null, ipHash });
      if (row.failures % config.recovery.maxFailuresBeforeLock === 0) {
        const minutes = recoveryLockMinutes(config, row.failures);
        await prisma.authThrottle.update({ where: { key: throttleKey }, data: { lockedUntil: new Date(Date.now() + minutes * 60_000) } });
        await recordEvent(prisma, { type: 'RECOVERY_LOCKED', userId: user?.id ?? null, ipHash, metadata: { minutes } });
      }
      throw Errors.unauthorized('Account ID or recovery code is wrong', 'INVALID_RECOVERY');
    }

    if (user!.status === 'SUSPENDED') throw new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended');

    // New secure session; every older session of this account is closed (lost / reinstalled device).
    const session = await prisma.$transaction(async (tx) => {
      await tx.authThrottle.deleteMany({ where: { key: throttleKey } });
      await revokeAllSessions(tx, user!.id);
      const opened = await openSession(tx, config, user!);
      await recordEvent(tx, { type: 'RECOVERY_SUCCEEDED', userId: user!.id, ipHash });
      return opened;
    });

    return reply.header('cache-control', 'no-store').send({
      account: { ...toAccountSummary(user!), isGuest: user!.isGuest },
      tokens: session.tokens,
      ...(session.notice ? { notice: session.notice } : {}),
    });
  });

  /** Replaces the recovery code; the previous one stops working immediately. */
  app.post('/recovery-code/rotate', { ...auth, config: limit }, async (req, reply) => {
    const { userId } = requireAuth(req);
    const user = await prisma.user.findUniqueOrThrow({ where: { id: userId }, select: { accountCode: true } });
    const recoveryCode = generateRecoveryCode();
    await prisma.user.update({
      where: { id: userId },
      data: {
        recoveryCodeHash: hashRecoveryCode(config, user.accountCode, normalizeRecoveryCode(recoveryCode)!),
        recoveryCodeRotatedAt: new Date(),
      },
    });
    // A new code is a fresh start: clear any failure lock on this account.
    await prisma.authThrottle.deleteMany({ where: { key: recoveryThrottleKey(config, user.accountCode) } });
    await recordEvent(prisma, { type: 'RECOVERY_CODE_ROTATED', userId, ipHash: ipHashOf(config, req.ip) });
    return reply.header('cache-control', 'no-store').send({ recoveryCode, recoveryWarningFa: RECOVERY_WARNING_FA });
  });

  /** The signed-in player's own account: ID, linked methods (masked), guest deadline. */
  app.get('/account', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    const user = await prisma.user.findUniqueOrThrow({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        accountCode: true,
        isGuest: true,
        lastActivityAt: true,
        recoveryCodeHash: true,
        identities: { select: { provider: true, identifier: true }, orderBy: { createdAt: 'asc' } },
      },
    });
    const expiry = guestExpiry(config, user);
    return reply.header('cache-control', 'no-store').send({
      id: user.id,
      username: user.username,
      accountCode: user.accountCode,
      isGuest: user.isGuest,
      hasRecoveryCode: user.recoveryCodeHash !== null,
      linked: user.identities.map((i) => ({
        provider: i.provider,
        masked: i.provider === 'PHONE' ? maskPhone(i.identifier) : i.provider === 'EMAIL' ? maskEmail(i.identifier) : 'Google',
      })),
      guestExpiry: expiry ? { expiresAt: expiry.expiresAt, daysLeft: expiry.daysLeft, warning: expiry.warning } : null,
    });
  });
}
