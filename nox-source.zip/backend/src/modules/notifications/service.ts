import type { Prisma } from '@prisma/client';
import type { DbClient } from '../../db';

export interface NewNotification {
  userId: string;
  type: string;
  title: string;
  body?: string;
  data?: Prisma.InputJsonValue;
}

export async function createNotification(db: DbClient, n: NewNotification) {
  return db.notification.create({
    data: { userId: n.userId, type: n.type, title: n.title, body: n.body ?? '', data: n.data ?? undefined },
  });
}
