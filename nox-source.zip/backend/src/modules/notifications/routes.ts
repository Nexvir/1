import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAuth } from '../../auth/plugin';
import { Errors } from '../../errors';

const listQuery = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(30),
  cursor: z.string().min(1).max(64).optional(),
  unreadOnly: z.enum(['true', 'false']).default('false'),
});

export async function notificationRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: app.authenticate };

  app.get('/', auth, async (req) => {
    const { userId } = requireAuth(req);
    const q = listQuery.parse(req.query);
    const rows = await app.prisma.notification.findMany({
      where: { userId, ...(q.unreadOnly === 'true' ? { readAt: null } : {}) },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      take: q.limit + 1,
      ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
    });
    const page = rows.slice(0, q.limit);
    return { items: page, nextCursor: rows.length > q.limit ? (page[page.length - 1]?.id ?? null) : null };
  });

  app.get('/unread-count', auth, async (req) => {
    const { userId } = requireAuth(req);
    return { count: await app.prisma.notification.count({ where: { userId, readAt: null } }) };
  });

  app.post('/read-all', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    await app.prisma.notification.updateMany({ where: { userId, readAt: null }, data: { readAt: new Date() } });
    return reply.status(204).send();
  });

  app.post('/:id/read', auth, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { id } = z.object({ id: z.string().min(1).max(64) }).parse(req.params);
    const res = await app.prisma.notification.updateMany({ where: { id, userId, readAt: null }, data: { readAt: new Date() } });
    if (res.count === 0) {
      const exists = await app.prisma.notification.findFirst({ where: { id, userId }, select: { id: true } });
      if (!exists) throw Errors.notFound('NOTIFICATION_NOT_FOUND', 'Notification not found');
    }
    return reply.status(204).send();
  });
}
