import type { User } from '@prisma/client';
import type { AppConfig } from '../../config';
import type { DbClient } from '../../db';
import { Errors, isUniqueViolation } from '../../errors';
import { generateAccountCode, randomBase32 } from '../../auth/codes';
import { applyWalletChange } from '../wallet/service';
import { countEvents, recordEvent } from '../security/events';
import { randomInt } from 'node:crypto';

export type NewAccountKind = 'guest' | 'regular';

export interface NewAccountInput {
  kind: NewAccountKind;
  displayName?: string;
  /** HMAC of the recovery code (guests, or anyone who has one). */
  recoveryCodeHash?: string;
  /** Only the legacy username / e-mail / password sign-up supplies these. */
  legacy?: { username: string; email: string; passwordHash: string };
}

export async function ensureNoxBot(tx: DbClient): Promise<string> {
  const existing = await tx.user.findUnique({ where: { username: 'nox_official' }, select: { id: true, isDemo: true, profile: { select: { displayName: true } } } });
  if (existing && (!existing.isDemo || existing.profile?.displayName !== 'ناتس')) {
    throw Errors.conflict('NOX_BOT_USERNAME_RESERVED', 'The official Nox bot username is already in use');
  }
  const bot = await tx.user.upsert({
    where: { username: 'nox_official' },
    update: {},
    create: {
      username: 'nox_official', accountCode: generateAccountCode(), isDemo: true,
      profile: { create: { displayName: 'ناتس', visibility: 'PRIVATE', requestPolicy: 'NOBODY', showClan: false, showStats: false } },
      wallet: { create: {} },
    },
    select: { id: true },
  });
  return bot.id;
}

export async function ensureNoxConversation(tx: DbClient, userId: string, welcomeCoins?: number): Promise<void> {
  const botId = await ensureNoxBot(tx);
  const pairKey = [userId, botId].sort().join(':');
  const conversation = await tx.conversation.upsert({
    where: { pairKey },
    update: {},
    create: { pairKey, members: { create: [{ userId }, { userId: botId }] } },
    select: { id: true },
  });
  if (welcomeCoins !== undefined) {
    const exists = await tx.privateMessage.findFirst({ where: { conversationId: conversation.id, clientMsgId: `welcome:${userId}` }, select: { id: true } });
    if (!exists) {
      const message = await tx.privateMessage.create({ data: { conversationId: conversation.id, senderId: botId, clientMsgId: `welcome:${userId}`, body: `خوش اومدی به NØX! ${welcomeCoins} سکهٔ هدیه به حسابت اضافه شد. از فروشگاه می‌تونی قاب و آیتم‌های پروفایل بخری.` } });
      await tx.conversation.update({ where: { id: conversation.id }, data: { lastMessageAt: message.createdAt } });
    }
  }
}

/** Creates the user, profile, wallet and welcome bonus inside the caller's transaction. */
export async function createAccountTx(tx: DbClient, config: AppConfig, input: NewAccountInput): Promise<User> {
  const suffix = randomBase32(8).toLowerCase();
  const username = input.legacy?.username ?? `${String.fromCharCode(97 + randomInt(26))}${randomInt(0, 1_000_000_000).toString().padStart(9, '0')}`;
  const displayName =
    input.displayName ?? input.legacy?.username ?? `${input.kind === 'guest' ? 'مهمان' : 'بازیکن'}-${suffix.slice(0, 4).toUpperCase()}`;

  const user = await tx.user.create({
    data: {
      username,
      email: input.legacy?.email ?? null,
      passwordHash: input.legacy?.passwordHash ?? null,
      accountCode: generateAccountCode(),
      isGuest: input.kind === 'guest',
      recoveryCodeHash: input.recoveryCodeHash ?? null,
      recoveryCodeRotatedAt: input.recoveryCodeHash ? new Date() : null,
      profile: { create: { displayName } },
      wallet: { create: {} },
    },
  });
  if (config.welcomeBonusCoins > 0) {
    await applyWalletChange(tx, {
      userId: user.id,
      amount: config.welcomeBonusCoins,
      kind: 'PROMO',
      source: 'welcome_bonus',
      idempotencyKey: `welcome:${user.id}`,
    });
  }
  await ensureNoxConversation(tx, user.id, config.welcomeBonusCoins);
  return user;
}

/**
 * Runs `fn` (a whole transaction) and retries when a randomly generated identifier
 * (account code / generated username) collides. Only for flows where the caller supplies
 * no unique value of their own; legacy sign-up must not use this.
 */
export async function withGeneratedIdRetry<T>(fn: () => Promise<T>, attempts = 5): Promise<T> {
  for (let i = 1; ; i++) {
    try {
      return await fn();
    } catch (err) {
      if (i < attempts && isUniqueViolation(err)) continue;
      throw err;
    }
  }
}

/** Per-source cap on new accounts, shared by every sign-up method. */
export async function assertAccountCreationAllowed(
  prisma: DbClient,
  config: AppConfig,
  ipHash: string | null,
): Promise<void> {
  const created = await countEvents(prisma, { type: 'ACCOUNT_CREATED', ipHash, sinceMs: 3_600_000 });
  if (created >= config.antibot.accountCreatePerIpHour) {
    throw Errors.tooMany('TOO_MANY_ACCOUNTS', 'Too many accounts were created from this network recently', 600);
  }
}

export async function recordAccountCreated(
  tx: DbClient,
  user: { id: string },
  ipHash: string | null,
  method: 'guest' | 'password' | 'phone' | 'email' | 'google',
): Promise<void> {
  await recordEvent(tx, { type: 'ACCOUNT_CREATED', userId: user.id, ipHash, metadata: { method } });
}

export function toAccountSummary(u: { id: string; username: string; accountCode: string; profile?: { displayName: string } | null }) {
  return { id: u.id, username: u.username, accountCode: u.accountCode, displayName: u.profile?.displayName ?? u.username };
}
