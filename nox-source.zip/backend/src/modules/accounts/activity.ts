import type { AppConfig } from '../../config';
import type { DbClient } from '../../db';

/**
 * Adds calendar months in UTC, clamping the day to the end of the target month
 * (Jan 31 + 1 month = Feb 28/29). Matches PostgreSQL's `timestamp + interval 'N months'`,
 * which the cleanup job uses, so warnings and deletions agree on the same instant.
 */
export function addMonthsUtc(date: Date, months: number): Date {
  const d = new Date(date.getTime());
  const day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const lastDay = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, lastDay));
  return d;
}

export interface GuestExpiry {
  expiresAt: Date;
  /** Whole days remaining, 0 when the deadline has passed but the cleanup job has not run yet. */
  daysLeft: number;
  /** True inside the final `GUEST_WARNING_DAYS` days. */
  warning: boolean;
}

/** null for accounts that are not guests (they are exempt from the policy). */
export function guestExpiry(
  config: AppConfig,
  user: { isGuest: boolean; lastActivityAt: Date },
  now: Date = new Date(),
): GuestExpiry | null {
  if (!user.isGuest) return null;
  const expiresAt = addMonthsUtc(user.lastActivityAt, config.guest.inactivityMonths);
  const msLeft = expiresAt.getTime() - now.getTime();
  const daysLeft = Math.max(0, Math.ceil(msLeft / 86_400_000));
  return { expiresAt, daysLeft, warning: msLeft <= config.guest.warningDays * 86_400_000 };
}

/** Records a server-confirmed activity (sign-in, token refresh, recovery). */
export async function touchActivity(db: DbClient, userId: string, now: Date = new Date()): Promise<void> {
  await db.user.updateMany({ where: { id: userId }, data: { lastActivityAt: now, lastSeenAt: now } });
}

export const GUEST_WARNING_NOTIFICATION = 'GUEST_EXPIRY_WARNING';

export interface SessionNotice {
  type: typeof GUEST_WARNING_NOTIFICATION;
  expiresAt: Date;
  daysLeft: number;
  messageFa: string;
}

/**
 * Builds the "your guest account was close to being deleted, link a permanent sign-in method"
 * notice. Must be evaluated against the activity time from BEFORE the current sign-in is
 * recorded, because signing in resets the inactivity clock. Also stores an in-app
 * notification (at most one per warning period) so the app can show it again later.
 */
export async function buildSessionNotice(
  db: DbClient,
  config: AppConfig,
  user: { id: string; isGuest: boolean; lastActivityAt: Date },
  now: Date = new Date(),
): Promise<SessionNotice | null> {
  const expiry = guestExpiry(config, user, now);
  if (!expiry || !expiry.warning) return null;

  const messageFa =
    'حساب مهمان تو مدت زیادی بدون فعالیت مونده بود و نزدیک بود حذف بشه. ' +
    'برای اینکه پیشرفتت همیشه حفظ بشه، همین حالا حسابت رو به گوگل، ایمیل یا شماره تلفن وصل کن.';

  const recent = await db.notification.findFirst({
    where: {
      userId: user.id,
      type: GUEST_WARNING_NOTIFICATION,
      createdAt: { gt: new Date(now.getTime() - config.guest.warningDays * 86_400_000) },
    },
    select: { id: true },
  });
  if (!recent) {
    await db.notification.create({
      data: {
        userId: user.id,
        type: GUEST_WARNING_NOTIFICATION,
        title: 'حسابت رو دائمی کن',
        body: messageFa,
        data: { expiresAt: expiry.expiresAt.toISOString(), daysLeft: expiry.daysLeft },
      },
    });
  }
  return { type: GUEST_WARNING_NOTIFICATION, expiresAt: expiry.expiresAt, daysLeft: expiry.daysLeft, messageFa };
}
