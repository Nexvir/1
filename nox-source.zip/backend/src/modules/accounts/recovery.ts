import type { AppConfig } from '../../config';
import { hmacHex } from '../../auth/codes';

/** HMAC of a recovery code, bound to its account. The plain code is never stored or logged. */
export function hashRecoveryCode(config: AppConfig, accountCode: string, normalizedCode: string): string {
  return hmacHex(config.pepper, 'recovery', `${accountCode}:${normalizedCode}`);
}

/** Key of the failure counter for an account code (also used for codes that do not exist). */
export function recoveryThrottleKey(config: AppConfig, accountCode: string): string {
  return `recovery:${hmacHex(config.pepper, 'recovery-throttle', accountCode)}`;
}

/** Lock length after the n-th block of failures: base, then doubling, capped at 24 hours. */
export function recoveryLockMinutes(config: AppConfig, failures: number): number {
  const block = Math.floor(failures / config.recovery.maxFailuresBeforeLock);
  return Math.min(config.recovery.lockMinutes * 2 ** Math.max(0, block - 1), 24 * 60);
}
