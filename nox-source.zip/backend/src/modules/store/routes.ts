import type { FastifyInstance } from 'fastify';
import { requireAuth } from '../../auth/plugin';
import { Errors } from '../../errors';
import { applyWalletChange } from '../wallet/service';
import { z } from 'zod';

const purchaseBody = z.object({ sku: z.string().min(1).max(80), idempotencyKey: z.string().regex(/^[a-zA-Z0-9_-]{8,64}$/) });
const equipBody = z.object({ type: z.enum(['PROFILE_FRAME', 'TITLE', 'BADGE', 'THEME']), sku: z.string().min(1).max(80).nullable() });

/** Catalogue and inventory are read from StoreItem/UserInventory; demo rows are excluded. */
export async function storeRoutes(app: FastifyInstance): Promise<void> {
  app.get('/', { preHandler: app.authenticate }, async (req) => {
    requireAuth(req);
    const items = await app.prisma.storeItem.findMany({ where: { available: true, isDemo: false }, orderBy: [{ type: 'asc' }, { price: 'asc' }, { id: 'asc' }], select: { id: true, sku: true, type: true, name: true, description: true, price: true, rarity: true, stackable: true } });
    return { items };
  });
  app.get('/inventory', { preHandler: app.authenticate }, async (req) => {
    const { userId } = requireAuth(req);
    const items = await app.prisma.userInventory.findMany({ where: { userId }, orderBy: { acquiredAt: 'desc' }, include: { item: { select: { sku: true, type: true, name: true, description: true, rarity: true } } } });
    return { items: items.map((i) => ({ id: i.id, itemId: i.itemId, quantity: i.quantity, acquiredAt: i.acquiredAt, ...i.item })) };
  });

  app.post('/purchase', { preHandler: app.authenticate }, async (req, reply) => {
    const { userId } = requireAuth(req);
    const { sku, idempotencyKey } = purchaseBody.parse(req.body);
    const item = await app.prisma.storeItem.findUnique({ where: { sku } });
    if (!item || !item.available || item.isDemo) throw Errors.notFound('STORE_ITEM_NOT_FOUND', 'Store item not found');
    const result = await app.prisma.$transaction(async (tx) => {
      const prior = await tx.purchase.findUnique({ where: { idempotencyKey } });
      if (prior) {
        if (prior.userId !== userId || prior.itemId !== item.id) throw Errors.conflict('IDEMPOTENCY_KEY_REUSED', 'This purchase key was already used');
        return { purchaseId: prior.id, price: prior.price, replayed: true };
      }
      const owned = await tx.userInventory.findUnique({ where: { userId_itemId: { userId, itemId: item.id } }, select: { id: true } });
      if (owned && !item.stackable) throw Errors.conflict('ITEM_ALREADY_OWNED', 'This item is already in your inventory');
      if (item.price > 0) await applyWalletChange(tx, { userId, amount: -item.price, kind: 'SPEND', source: 'store_purchase', refId: item.id, idempotencyKey: `store:${idempotencyKey}` });
      const purchase = await tx.purchase.create({ data: { userId, itemId: item.id, price: item.price, idempotencyKey } });
      if (item.stackable) await tx.userInventory.upsert({ where: { userId_itemId: { userId, itemId: item.id } }, create: { userId, itemId: item.id, quantity: 1 }, update: { quantity: { increment: 1 } } });
      else await tx.userInventory.create({ data: { userId, itemId: item.id } });
      return { purchaseId: purchase.id, price: item.price, replayed: false };
    });
    return reply.status(result.replayed ? 200 : 201).send(result);
  });

  app.post('/equip', { preHandler: app.authenticate }, async (req) => {
    const { userId } = requireAuth(req);
    const { type, sku } = equipBody.parse(req.body);
    const field = { PROFILE_FRAME: 'equippedFrameId', TITLE: 'equippedTitleId', BADGE: 'equippedBadgeId', THEME: 'equippedThemeId' }[type];
    let itemId: string | null = null;
    if (sku !== null) {
      const item = await app.prisma.storeItem.findUnique({ where: { sku }, select: { id: true, type: true } });
      if (!item || item.type !== type) throw Errors.notFound('STORE_ITEM_NOT_FOUND', 'Store item not found');
      const owned = await app.prisma.userInventory.findUnique({ where: { userId_itemId: { userId, itemId: item.id } }, select: { id: true } });
      if (!owned) throw Errors.forbidden('ITEM_NOT_OWNED', 'Buy this item before equipping it');
      itemId = item.id;
    }
    await app.prisma.userProfile.update({ where: { userId }, data: { [field]: itemId } });
    return { type, sku };
  });
}
