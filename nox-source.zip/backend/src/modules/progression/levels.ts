import type { LevelCurveConfig } from '../../config';

export interface LevelTable {
  /** thresholds[i] = total lifetime XP needed to reach level i + 1 (thresholds[0] = 0). */
  thresholds: number[];
  maxLevel: number;
}

/** Builds the cumulative XP table once from configuration. */
export function buildLevelTable(cfg: LevelCurveConfig): LevelTable {
  const thresholds = [0];
  let total = 0;
  for (let level = 1; level < cfg.maxLevel; level++) {
    total += Math.max(1, Math.round(cfg.baseXp * Math.pow(cfg.growth, level - 1)));
    thresholds.push(total);
  }
  return { thresholds, maxLevel: cfg.maxLevel };
}

export function levelFromXp(table: LevelTable, xp: number): number {
  let level = 1;
  while (level < table.maxLevel && xp >= (table.thresholds[level] ?? Infinity)) level++;
  return level;
}

export interface LevelProgress {
  level: number;
  xp: number;
  xpIntoLevel: number;
  /** XP span of the current level; 0 at max level. */
  xpForNextLevel: number;
  isMaxLevel: boolean;
}

export function levelProgress(table: LevelTable, xp: number): LevelProgress {
  const level = levelFromXp(table, xp);
  const floor = table.thresholds[level - 1] ?? 0;
  if (level >= table.maxLevel) {
    return { level, xp, xpIntoLevel: xp - floor, xpForNextLevel: 0, isMaxLevel: true };
  }
  const next = table.thresholds[level] ?? floor;
  return { level, xp, xpIntoLevel: xp - floor, xpForNextLevel: next - floor, isMaxLevel: false };
}
