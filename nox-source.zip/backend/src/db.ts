import { Prisma, PrismaClient } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';

/**
 * Creates a Prisma client using the pg driver adapter. The `schema` query
 * parameter (understood by the Prisma CLI) is translated to the adapter option.
 *
 * Every connection is pinned to the UTC time zone. Timestamps are stored as
 * `timestamp without time zone` holding UTC values, so SQL like `now()` or
 * `CURRENT_TIMESTAMP` defaults must be evaluated in UTC to agree with what the
 * application writes.
 */
export function createPrisma(databaseUrl: string): PrismaClient {
  const url = new URL(databaseUrl);
  const schema = url.searchParams.get('schema') ?? undefined;
  url.searchParams.delete('schema');
  const adapter = new PrismaPg(
    { connectionString: url.toString(), options: '-c timezone=UTC' },
    schema ? { schema } : undefined,
  );
  return new PrismaClient({ adapter });
}

/** Either the root client or an interactive-transaction client. */
export type DbClient = PrismaClient | Prisma.TransactionClient;
