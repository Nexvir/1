/**
 * Persian, kid-friendly messages for API error codes. Clients should show `messageFa`
 * (or map `code` themselves); the English `message` stays for developers and logs.
 */
export const FA_MESSAGES: Record<string, string> = {
  VALIDATION_ERROR: 'اطلاعاتی که وارد کردی درست نیست. یه بار دیگه چک کن.',
  UNAUTHORIZED: 'اول باید وارد حسابت بشی.',
  INVALID_TOKEN: 'زمان ورودت تموم شده. دوباره وارد شو.',
  INVALID_CREDENTIALS: 'نام کاربری یا رمز عبور درست نیست.',
  INVALID_REFRESH_TOKEN: 'زمان ورودت تموم شده. دوباره وارد شو.',
  ACCOUNT_SUSPENDED: 'این حساب مسدود شده است.',
  ACCOUNT_EXISTS: 'این نام کاربری یا ایمیل قبلاً استفاده شده.',
  RATE_LIMITED: 'خیلی سریع داری تلاش می‌کنی! کمی صبر کن و دوباره امتحان کن.',
  INTERNAL_ERROR: 'یه مشکلی پیش اومد. چند لحظه بعد دوباره امتحان کن.',
  NOT_FOUND: 'چیزی که دنبالش بودی پیدا نشد.',

  // anti-bot
  CAPTCHA_REQUIRED: 'اول چالش تصویری رو حل کن.',
  CAPTCHA_NOT_FOUND: 'این چالش پیدا نشد. یه چالش جدید بگیر.',
  CAPTCHA_WRONG: 'اشتباه شد! یه چالش جدید بگیر و دوباره امتحان کن.',
  CAPTCHA_EXPIRED: 'زمان این چالش تموم شده. یه چالش جدید بگیر.',
  CAPTCHA_ALREADY_ANSWERED: 'این چالش قبلاً جواب داده شده. یه چالش جدید بگیر.',
  INVALID_CAPTCHA_PASS: 'مجوز ثبت‌نامت معتبر نیست یا قبلاً استفاده شده. چالش رو دوباره حل کن.',
  TOO_MANY_CAPTCHA_FAILURES: 'چند بار اشتباه جواب دادی. چند دقیقه صبر کن و دوباره امتحان کن.',
  TOO_MANY_ACCOUNTS: 'از این شبکه خیلی حساب ساخته شده. کمی بعد دوباره امتحان کن.',

  // guest / recovery
  INVALID_RECOVERY_FORMAT: 'شناسه حساب یا کد بازیابی به شکل درست وارد نشده. شناسه مثل NX-7K2M9QXD و کد شامل ۲۰ حرف و عدد است.',
  INVALID_RECOVERY: 'شناسه حساب یا کد بازیابی درست نیست.',
  RECOVERY_LOCKED: 'چند بار اشتباه وارد کردی. برای امنیت حسابت، کمی صبر کن و بعد دوباره امتحان کن.',
  RECOVERY_IP_LIMIT: 'تلاش‌های ناموفق زیادی از این شبکه انجام شده. کمی بعد دوباره امتحان کن.',

  // one-time codes
  OTP_COOLDOWN: 'کد تازه فرستاده شده. چند ثانیه صبر کن و دوباره درخواست بده.',
  OTP_LIMIT_REACHED: 'تعداد درخواست‌های کد زیاد بود. بعداً دوباره امتحان کن.',
  INVALID_OTP: 'کد واردشده درست نیست یا منقضی شده.',
  OTP_ATTEMPTS_EXCEEDED: 'چند بار اشتباه وارد کردی. یه کد جدید بگیر.',
  EMAIL_NOT_CONFIGURED: 'ورود با ایمیل فعلاً در دسترس نیست. با روش دیگه‌ای وارد شو.',
  SMS_NOT_CONFIGURED: 'ورود با شماره تلفن فعلاً در دسترس نیست. با روش دیگه‌ای وارد شو.',
  DELIVERY_FAILED: 'ارسال کد انجام نشد. چند لحظه بعد دوباره امتحان کن.',
  INVALID_PHONE: 'شماره تلفن درست نیست. مثلاً: 09123456789',

  // Google
  GOOGLE_NOT_CONFIGURED: 'ورود با گوگل فعلاً در دسترس نیست. با روش دیگه‌ای وارد شو.',
  INVALID_GOOGLE_TOKEN: 'ورود با گوگل تأیید نشد. دوباره امتحان کن.',

  // linking
  IDENTITY_IN_USE:
    'این روش ورود قبلاً به حساب دیگه‌ای وصل شده. برای اینکه اطلاعات هیچ حسابی از بین نره، حساب‌ها خودکار ادغام نمی‌شن. با همون حساب وارد شو یا از روش دیگه‌ای استفاده کن.',
  ALREADY_LINKED: 'این نوع ورود قبلاً به حسابت وصل شده.',
};
