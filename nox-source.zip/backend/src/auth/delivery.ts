import nodemailer from 'nodemailer';
import type { AppConfig, SmsConfig, SmtpConfig } from '../config';

/**
 * Sends a one-time code. Implementations MUST NOT log the code or the destination.
 * Throwing means "not delivered"; callers never report success after a throw.
 */
export interface OtpSender {
  send(destination: string, code: string, ttlSeconds: number): Promise<void>;
}

/** A channel that is `null` is not configured on this server and is reported as unavailable. */
export interface Deliveries {
  email: OtpSender | null;
  sms: OtpSender | null;
}

export class SmtpEmailSender implements OtpSender {
  private readonly transport;

  constructor(private readonly cfg: SmtpConfig) {
    this.transport = nodemailer.createTransport({
      host: cfg.host,
      port: cfg.port,
      secure: cfg.secure,
      requireTLS: cfg.requireTLS && !cfg.secure,
      auth: cfg.user ? { user: cfg.user, pass: cfg.pass ?? '' } : undefined,
      connectionTimeout: 10_000,
      greetingTimeout: 10_000,
      socketTimeout: 15_000,
    });
  }

  async send(destination: string, code: string, ttlSeconds: number): Promise<void> {
    const minutes = Math.max(1, Math.round(ttlSeconds / 60));
    await this.transport.sendMail({
      from: this.cfg.from,
      to: destination,
      subject: `کد ورود NØX: ${code}`,
      text:
        `کد ورود شما به NØX: ${code}\n\n` +
        `این کد ${minutes} دقیقه معتبر است و فقط یک بار می‌شود از آن استفاده کرد.\n` +
        'اگر شما این درخواست را نداده‌اید، این پیام را نادیده بگیرید و کد را به کسی نگویید.\n\n' +
        `Your NØX sign-in code: ${code} (valid for ${minutes} minutes). If you did not request it, ignore this message.`,
      html:
        `<div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;background:#0b0b14;color:#e8e8f4;padding:24px;border-radius:12px">` +
        `<p>کد ورود شما به <b>NØX</b>:</p>` +
        `<p style="font-size:32px;letter-spacing:8px;color:#b46cff;margin:12px 0" dir="ltr">${code}</p>` +
        `<p>این کد ${minutes} دقیقه معتبر است و فقط یک بار قابل استفاده است.</p>` +
        `<p style="color:#9a9ab8">اگر شما این درخواست را نداده‌اید، این پیام را نادیده بگیرید و کد را به کسی نگویید.</p></div>`,
    });
  }
}

/**
 * Kavenegar "verify/lookup" (template-based OTP SMS) adapter, written from Kavenegar's
 * public API documentation. It has NOT been exercised against the live service from this
 * project (no account / network access); it is covered only by a test against a local mock
 * of the documented request/response shape. Verify with a real key before relying on it.
 * The code travels in a POST body, never in a URL.
 */
export class KavenegarSmsSender implements OtpSender {
  constructor(private readonly cfg: SmsConfig) {}

  async send(destination: string, code: string): Promise<void> {
    // Kavenegar expects the local Iranian format (09123456789) for Iranian numbers.
    const receptor = destination.startsWith('+98') ? `0${destination.slice(3)}` : destination.replace(/^\+/, '');
    const res = await fetch(`${this.cfg.baseUrl}/v1/${encodeURIComponent(this.cfg.apiKey)}/verify/lookup.json`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ receptor, token: code, template: this.cfg.template }).toString(),
      signal: AbortSignal.timeout(10_000),
    });
    const json = (await res.json().catch(() => null)) as { return?: { status?: number } } | null;
    if (!res.ok || json?.return?.status !== 200) throw new Error('SMS provider rejected the message');
  }
}

export function createDeliveries(config: AppConfig): Deliveries {
  return {
    email: config.smtp ? new SmtpEmailSender(config.smtp) : null,
    sms: config.sms ? new KavenegarSmsSender(config.sms) : null,
  };
}
