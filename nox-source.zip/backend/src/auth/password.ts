import argon2 from 'argon2';

const OPTIONS = {
  type: argon2.argon2id,
  memoryCost: 19456, // KiB (OWASP minimum recommendation for argon2id)
  timeCost: 2,
  parallelism: 1,
} as const;

export function hashPassword(password: string): Promise<string> {
  return argon2.hash(password, OPTIONS);
}

export async function verifyPassword(hash: string, password: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, password);
  } catch {
    return false;
  }
}

let dummyHash: Promise<string> | undefined;

/** Burns roughly the same time as a real verification so unknown users are not distinguishable by timing. */
export async function verifyDummy(password: string): Promise<void> {
  dummyHash ??= hashPassword('nox-dummy-password-for-timing');
  await verifyPassword(await dummyHash, password);
}
