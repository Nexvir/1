import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { PrismaClient, UserRole } from '@prisma/client';
import type { AppConfig } from '../config';
import { AppError, Errors } from '../errors';
import type { Deliveries } from './delivery';
import type { GoogleVerifier } from './google';
import { verifyAccessToken } from './tokens';

export interface AuthContext {
  userId: string;
  role: UserRole;
}

declare module 'fastify' {
  interface FastifyInstance {
    config: AppConfig;
    prisma: PrismaClient;
    deliveries: Deliveries;
    /** null when GOOGLE_CLIENT_IDS is not configured. */
    googleVerifier: GoogleVerifier | null;
    authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
  }
  interface FastifyRequest {
    auth: AuthContext | null;
  }
}

/** Returns the authenticated context or throws 401. Use inside handlers behind `authenticate`. */
export function requireAuth(req: FastifyRequest): AuthContext {
  if (!req.auth) throw Errors.unauthorized();
  return req.auth;
}

/** An authenticated request counts as activity, but is only written at most once per hour. */
const ACTIVITY_WRITE_INTERVAL_MS = 3_600_000;

export function registerAuth(app: FastifyInstance): void {
  app.decorateRequest('auth', null);

  app.decorate('authenticate', async (req: FastifyRequest) => {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) throw Errors.unauthorized();

    let userId: string;
    try {
      userId = verifyAccessToken(app.config, header.slice(7)).sub;
    } catch {
      throw Errors.unauthorized('Invalid or expired token', 'INVALID_TOKEN');
    }

    // Authorization decisions use the live DB state, never claims in the token.
    const user = await app.prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, role: true, status: true, lastActivityAt: true },
    });
    if (!user) throw Errors.unauthorized('Invalid or expired token', 'INVALID_TOKEN');
    if (user.status === 'SUSPENDED') {
      throw new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended');
    }

    // Server-confirmed activity (keeps guest accounts out of the inactivity policy).
    const now = Date.now();
    if (now - user.lastActivityAt.getTime() > ACTIVITY_WRITE_INTERVAL_MS) {
      await app.prisma.user.updateMany({
        where: { id: user.id, lastActivityAt: { lt: new Date(now - ACTIVITY_WRITE_INTERVAL_MS) } },
        data: { lastActivityAt: new Date(now) },
      });
    }
    req.auth = { userId: user.id, role: user.role };
  });
}
