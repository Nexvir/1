import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import type { AppConfig } from '../config';

export interface AccessClaims {
  sub: string;
}

export function signAccessToken(config: AppConfig, userId: string): string {
  return jwt.sign({}, config.jwtAccessSecret, {
    algorithm: 'HS256',
    subject: userId,
    expiresIn: config.accessTokenTtlSeconds,
  });
}

/** Throws if the token is invalid or expired. */
export function verifyAccessToken(config: AppConfig, token: string): AccessClaims {
  const payload = jwt.verify(token, config.jwtAccessSecret, { algorithms: ['HS256'] });
  if (typeof payload === 'string' || typeof payload.sub !== 'string') {
    throw new Error('malformed token');
  }
  return { sub: payload.sub };
}

/** Opaque, high-entropy refresh token. Only its SHA-256 hash is stored. */
export function generateRefreshToken(): string {
  return crypto.randomBytes(48).toString('base64url');
}

export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}
