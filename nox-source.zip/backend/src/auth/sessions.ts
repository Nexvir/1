import type { AppConfig } from '../config';
import type { DbClient } from '../db';
import { buildSessionNotice, touchActivity, type SessionNotice } from '../modules/accounts/activity';
import { generateRefreshToken, hashToken, signAccessToken } from './tokens';

export interface Tokens {
  accessToken: string;
  refreshToken: string;
  tokenType: 'Bearer';
  expiresIn: number;
}

/** Creates a new refresh-token record and a matching access token. */
export async function issueTokens(
  db: DbClient,
  config: AppConfig,
  user: { id: string; isGuest: boolean },
): Promise<Tokens> {
  const refreshToken = generateRefreshToken();
  const ttlDays = user.isGuest ? config.guestRefreshTokenTtlDays : config.refreshTokenTtlDays;
  await db.refreshToken.create({
    data: {
      userId: user.id,
      tokenHash: hashToken(refreshToken),
      expiresAt: new Date(Date.now() + ttlDays * 86_400_000),
    },
  });
  return {
    accessToken: signAccessToken(config, user.id),
    refreshToken,
    tokenType: 'Bearer',
    expiresIn: config.accessTokenTtlSeconds,
  };
}

export async function revokeAllSessions(db: DbClient, userId: string): Promise<void> {
  await db.refreshToken.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } });
}

export interface OpenedSession {
  tokens: Tokens;
  /** Present when the player should be nudged to link a permanent sign-in method. */
  notice: SessionNotice | null;
}

/**
 * Starts a session for a verified user: evaluates the guest-expiry warning against the
 * PREVIOUS activity time, records the new activity, then issues tokens.
 */
export async function openSession(
  db: DbClient,
  config: AppConfig,
  user: { id: string; isGuest: boolean; lastActivityAt: Date },
): Promise<OpenedSession> {
  const now = new Date();
  const notice = await buildSessionNotice(db, config, user, now);
  await touchActivity(db, user.id, now);
  const tokens = await issueTokens(db, config, user);
  return { tokens, notice };
}
