const PERSIAN_DIGITS = /[۰-۹]/g;
const ARABIC_DIGITS = /[٠-٩]/g;

function toAsciiDigits(s: string): string {
  return s
    .replace(PERSIAN_DIGITS, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(ARABIC_DIGITS, (d) => String(d.charCodeAt(0) - 0x0660));
}

/**
 * Normalizes a phone number to E.164 ("+989123456789") or returns null.
 * Accepts Persian/Arabic digits, spaces, dashes, "09123456789", "0098912..." and "+98912...".
 * Iranian numbers must be mobile numbers.
 */
export function normalizePhone(input: string): string | null {
  let s = toAsciiDigits(input).replace(/[\s\-().]/g, '');
  if (s.startsWith('00')) s = `+${s.slice(2)}`;
  if (/^09\d{9}$/.test(s)) s = `+98${s.slice(1)}`;
  if (!/^\+[1-9]\d{7,14}$/.test(s)) return null;
  if (s.startsWith('+98') && !/^\+989\d{9}$/.test(s)) return null;
  return s;
}

export function maskPhone(phone: string): string {
  return `${phone.slice(0, 5)}***${phone.slice(-4)}`;
}

export function maskEmail(email: string): string {
  const [local = '', domain = ''] = email.split('@');
  return `${local.slice(0, 1)}***@${domain}`;
}
