import { OAuth2Client } from 'google-auth-library';
import type { AppConfig } from '../config';

export interface VerifiedGoogleIdentity {
  /** Google's stable, unique account id. The only claim we trust as an identifier. */
  sub: string;
}

export interface GoogleVerifier {
  /** Throws if the ID token is invalid, expired, issued for another app, or not signed by Google. */
  verify(idToken: string): Promise<VerifiedGoogleIdentity>;
}

/**
 * Verifies Google ID tokens on the server with Google's official library: signature
 * (against Google's published certificates), issuer, expiry and audience (our client IDs).
 * Names / e-mails sent by the client are never used; only the verified `sub` is.
 */
export class GoogleIdTokenVerifier implements GoogleVerifier {
  constructor(
    private readonly clientIds: string[],
    private readonly client: OAuth2Client = new OAuth2Client(),
  ) {}

  async verify(idToken: string): Promise<VerifiedGoogleIdentity> {
    const ticket = await this.client.verifyIdToken({ idToken, audience: this.clientIds });
    const payload = ticket.getPayload();
    if (!payload?.sub) throw new Error('token has no subject');
    return { sub: payload.sub };
  }
}

export function createGoogleVerifier(config: AppConfig): GoogleVerifier | null {
  return config.googleClientIds.length > 0 ? new GoogleIdTokenVerifier(config.googleClientIds) : null;
}
