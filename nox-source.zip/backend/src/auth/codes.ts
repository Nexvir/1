import crypto from 'node:crypto';

// Crockford base32: no I, L, O, U, so codes are easy to read aloud and copy by hand.
const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

/** `n` random characters from the alphabet. 256 is a multiple of 32, so masking is unbiased. */
export function randomBase32(n: number): string {
  const bytes = crypto.randomBytes(n);
  let out = '';
  for (const b of bytes) out += ALPHABET[b & 31];
  return out;
}

/** Public account identifier, e.g. "NX-7K2M9QXD". Identifies an account; it is NOT a credential. */
export function generateAccountCode(): string {
  return `NX-${randomBase32(8)}`;
}

/** 100-bit secret shown once to the player, e.g. "7K2M9-QXD4F-8H3JN-V6PRT". */
export function generateRecoveryCode(): string {
  return randomBase32(20).match(/.{5}/g)!.join('-');
}

function crockford(input: string): string {
  return input.toUpperCase().replace(/[\s-]/g, '').replace(/[IL]/g, '1').replace(/O/g, '0');
}

/** Returns the canonical 20-character form (no dashes) or null if the shape is wrong. */
export function normalizeRecoveryCode(input: string): string | null {
  const c = crockford(input);
  return /^[0-9A-Z]{20}$/.test(c) ? c : null;
}

/** Returns "NX-XXXXXXXX" or null. Tolerates case, spaces, a missing dash and look-alike characters. */
export function normalizeAccountCode(input: string): string | null {
  const m = /^NX-?([0-9A-Z]{8})$/.exec(input.toUpperCase().replace(/\s/g, ''));
  return m ? `NX-${crockford(m[1]!)}` : null;
}

/** Six-digit one-time code, uniformly random. */
export function generateOtpCode(): string {
  return crypto.randomInt(0, 1_000_000).toString().padStart(6, '0');
}

/** URL-safe random token with `bytes` bytes of entropy. */
export function randomToken(bytes: number): string {
  return crypto.randomBytes(bytes).toString('base64url');
}

/** Domain-separated HMAC-SHA256 keyed with the server pepper. */
export function hmacHex(pepper: string, domain: string, value: string): string {
  return crypto.createHmac('sha256', pepper).update(`${domain}\0${value}`).digest('hex');
}

/** Constant-time comparison of two equal-purpose hex digests. */
export function safeEqual(a: string, b: string): boolean {
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}
