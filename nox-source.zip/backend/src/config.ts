import { z } from 'zod';

const bool = (def: 'true' | 'false') => z.enum(['true', 'false']).default(def);
const optionalStr = z.string().default('');

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  HOST: z.string().default('0.0.0.0'),
  PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  TRUST_PROXY: bool('false'),

  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),

  JWT_ACCESS_SECRET: z.string().min(32, 'JWT_ACCESS_SECRET must be at least 32 characters'),
  // Keys the HMACs used for recovery codes, one-time codes, CAPTCHA passes and IP hashes.
  // Rotating it invalidates every outstanding recovery code, so treat it like a database key.
  SERVER_PEPPER: z.string().min(32, 'SERVER_PEPPER must be at least 32 characters'),
  ACCESS_TOKEN_TTL_SECONDS: z.coerce.number().int().min(60).default(900),
  REFRESH_TOKEN_TTL_DAYS: z.coerce.number().int().min(1).default(30),
  // Guests have no password to fall back on, so their sessions live as long as the inactivity policy.
  GUEST_REFRESH_TOKEN_TTL_DAYS: z.coerce.number().int().min(1).default(270),

  CORS_ORIGINS: z.string().default(''),
  RATE_LIMIT_MAX: z.coerce.number().int().min(1).default(120),
  RATE_LIMIT_WINDOW_SECONDS: z.coerce.number().int().min(1).default(60),
  // Stricter limit for credential endpoints (login / register / refresh / recovery).
  AUTH_RATE_LIMIT_MAX: z.coerce.number().int().min(1).default(10),

  // Economy. Promotional coins granted once at account creation (ledger entry, kind PROMO).
  WELCOME_BONUS_COINS: z.coerce.number().int().min(0).max(1_000_000).optional(),

  // Level curve: XP needed to go from level n to n+1 is round(baseXp * growth^(n-1)).
  LEVEL_BASE_XP: z.coerce.number().int().min(1).default(100),
  LEVEL_GROWTH: z.coerce.number().min(1).max(3).default(1.2),
  LEVEL_MAX: z.coerce.number().int().min(1).max(1000).default(100),

  WEALTH_DEFINITION: z.enum(['balance']).default('balance'),
  PAYMENT_PROVIDER: z.string().default(''),

  // ---- anti-bot (NØX picture challenge)
  ANTIBOT_ENABLED: bool('true'),
  CAPTCHA_TTL_SECONDS: z.coerce.number().int().min(30).default(600),
  CAPTCHA_PASS_TTL_SECONDS: z.coerce.number().int().min(30).default(600),
  // How many one-time codes a single CAPTCHA pass may trigger (resends).
  CAPTCHA_MAX_OTP_SENDS_PER_PASS: z.coerce.number().int().min(1).default(3),
  // Wrong answers per IP per 10 minutes before challenges are temporarily refused.
  CAPTCHA_FAIL_LIMIT_PER_10_MIN: z.coerce.number().int().min(1).default(15),
  // New accounts (any method) per IP per hour.
  ACCOUNT_CREATE_PER_IP_HOUR: z.coerce.number().int().min(1).default(10),

  // ---- recovery
  RECOVERY_MAX_FAILURES_BEFORE_LOCK: z.coerce.number().int().min(1).default(5),
  // First lock duration; doubles on each further block of failures, capped at 24 h.
  RECOVERY_LOCK_MINUTES: z.coerce.number().int().min(1).default(15),
  RECOVERY_FAILED_PER_IP_15_MIN: z.coerce.number().int().min(1).default(30),

  // ---- one-time codes (SMS / e-mail)
  OTP_TTL_SECONDS: z.coerce.number().int().min(30).default(300),
  OTP_MAX_ATTEMPTS: z.coerce.number().int().min(1).default(5),
  OTP_RESEND_COOLDOWN_SECONDS: z.coerce.number().int().min(0).default(60),
  OTP_MAX_PER_DESTINATION_HOUR: z.coerce.number().int().min(1).default(5),
  OTP_MAX_PER_IP_HOUR: z.coerce.number().int().min(1).default(20),
  OTP_MAX_PER_USER_HOUR: z.coerce.number().int().min(1).default(5),

  // ---- guest accounts
  GUEST_INACTIVITY_MONTHS: z.coerce.number().int().min(1).default(9),
  GUEST_WARNING_DAYS: z.coerce.number().int().min(1).default(30),
  JOBS_ENABLED: bool('true'),
  GUEST_CLEANUP_INTERVAL_MINUTES: z.coerce.number().int().min(1).default(60),
  GUEST_CLEANUP_BATCH: z.coerce.number().int().min(1).max(1000).default(100),

  // ---- e-mail delivery (SMTP). Leave SMTP_HOST empty = e-mail sign-in unavailable.
  SMTP_HOST: optionalStr,
  SMTP_PORT: z.coerce.number().int().min(1).max(65535).default(587),
  SMTP_SECURE: bool('false'), // true = implicit TLS (port 465)
  SMTP_REQUIRE_TLS: bool('true'), // refuse to send in plaintext when not using implicit TLS
  SMTP_USER: optionalStr,
  SMTP_PASS: optionalStr,
  SMTP_FROM: optionalStr,

  // ---- SMS delivery. SMS_PROVIDER empty = phone sign-in unavailable. Supported: "kavenegar".
  SMS_PROVIDER: optionalStr,
  KAVENEGAR_API_KEY: optionalStr,
  KAVENEGAR_TEMPLATE: optionalStr,
  KAVENEGAR_BASE_URL: z.string().default('https://api.kavenegar.com'),

  // ---- Google sign-in: comma separated OAuth client IDs accepted as the ID-token audience.
  GOOGLE_CLIENT_IDS: optionalStr,
});

export interface LevelCurveConfig {
  baseXp: number;
  growth: number;
  maxLevel: number;
}

export interface SmtpConfig {
  host: string;
  port: number;
  secure: boolean;
  requireTLS: boolean;
  user: string | null;
  pass: string | null;
  from: string;
}

export interface SmsConfig {
  provider: 'kavenegar';
  apiKey: string;
  template: string;
  baseUrl: string;
}

export interface AppConfig {
  env: 'development' | 'test' | 'production';
  host: string;
  port: number;
  logLevel: string;
  trustProxy: boolean;
  databaseUrl: string;
  jwtAccessSecret: string;
  pepper: string;
  accessTokenTtlSeconds: number;
  refreshTokenTtlDays: number;
  guestRefreshTokenTtlDays: number;
  corsOrigins: string[];
  rateLimitMax: number;
  rateLimitWindowSeconds: number;
  authRateLimitMax: number;
  welcomeBonusCoins: number;
  levelCurve: LevelCurveConfig;
  wealthDefinition: 'balance';
  paymentProvider: string | null;
  antibot: {
    enabled: boolean;
    challengeTtlSeconds: number;
    passTtlSeconds: number;
    maxOtpSendsPerPass: number;
    failLimitPer10Min: number;
    accountCreatePerIpHour: number;
  };
  recovery: {
    maxFailuresBeforeLock: number;
    lockMinutes: number;
    failedPerIp15Min: number;
  };
  otp: {
    ttlSeconds: number;
    maxAttempts: number;
    resendCooldownSeconds: number;
    maxPerDestinationHour: number;
    maxPerIpHour: number;
    maxPerUserHour: number;
  };
  guest: {
    inactivityMonths: number;
    warningDays: number;
    jobsEnabled: boolean;
    cleanupIntervalMinutes: number;
    cleanupBatch: number;
  };
  /** null = e-mail delivery not configured. */
  smtp: SmtpConfig | null;
  /** null = SMS delivery not configured. */
  sms: SmsConfig | null;
  googleClientIds: string[];
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const parsed = envSchema.safeParse(env);
  if (!parsed.success) {
    const problems = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ');
    throw new Error(`Invalid environment configuration: ${problems}`);
  }
  const e = parsed.data;

  if (e.NODE_ENV === 'production') {
    for (const [name, value] of [
      ['JWT_ACCESS_SECRET', e.JWT_ACCESS_SECRET],
      ['SERVER_PEPPER', e.SERVER_PEPPER],
    ] as const) {
      if (/REPLACE|CHANGE_ME/i.test(value)) {
        throw new Error(`Invalid environment configuration: ${name} still has its placeholder value`);
      }
    }
    if (e.ANTIBOT_ENABLED === 'false') {
      throw new Error('Invalid environment configuration: ANTIBOT_ENABLED must be true in production');
    }
  }

  let smtp: SmtpConfig | null = null;
  if (e.SMTP_HOST.trim() !== '') {
    if (e.SMTP_FROM.trim() === '') throw new Error('Invalid environment configuration: SMTP_FROM is required when SMTP_HOST is set');
    smtp = {
      host: e.SMTP_HOST.trim(),
      port: e.SMTP_PORT,
      secure: e.SMTP_SECURE === 'true',
      requireTLS: e.SMTP_REQUIRE_TLS === 'true',
      user: e.SMTP_USER === '' ? null : e.SMTP_USER,
      pass: e.SMTP_PASS === '' ? null : e.SMTP_PASS,
      from: e.SMTP_FROM.trim(),
    };
  }

  let sms: SmsConfig | null = null;
  if (e.SMS_PROVIDER.trim() !== '') {
    if (e.SMS_PROVIDER.trim().toLowerCase() !== 'kavenegar') {
      throw new Error(`Invalid environment configuration: unsupported SMS_PROVIDER "${e.SMS_PROVIDER}" (supported: kavenegar)`);
    }
    if (e.KAVENEGAR_API_KEY === '' || e.KAVENEGAR_TEMPLATE === '') {
      throw new Error('Invalid environment configuration: KAVENEGAR_API_KEY and KAVENEGAR_TEMPLATE are required for SMS_PROVIDER=kavenegar');
    }
    sms = { provider: 'kavenegar', apiKey: e.KAVENEGAR_API_KEY, template: e.KAVENEGAR_TEMPLATE, baseUrl: e.KAVENEGAR_BASE_URL.replace(/\/+$/, '') };
  }

  return {
    env: e.NODE_ENV,
    host: e.HOST,
    port: e.PORT,
    logLevel: e.LOG_LEVEL,
    trustProxy: e.TRUST_PROXY === 'true',
    databaseUrl: e.DATABASE_URL,
    jwtAccessSecret: e.JWT_ACCESS_SECRET,
    pepper: e.SERVER_PEPPER,
    accessTokenTtlSeconds: e.ACCESS_TOKEN_TTL_SECONDS,
    refreshTokenTtlDays: e.REFRESH_TOKEN_TTL_DAYS,
    guestRefreshTokenTtlDays: e.GUEST_REFRESH_TOKEN_TTL_DAYS,
    corsOrigins: e.CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean),
    rateLimitMax: e.RATE_LIMIT_MAX,
    rateLimitWindowSeconds: e.RATE_LIMIT_WINDOW_SECONDS,
    authRateLimitMax: e.AUTH_RATE_LIMIT_MAX,
    // Generous default only for local development; keep test and production safe.
    welcomeBonusCoins: e.WELCOME_BONUS_COINS ?? (e.NODE_ENV === 'development' ? 1_000_000 : 500),
    levelCurve: { baseXp: e.LEVEL_BASE_XP, growth: e.LEVEL_GROWTH, maxLevel: e.LEVEL_MAX },
    wealthDefinition: e.WEALTH_DEFINITION,
    paymentProvider: e.PAYMENT_PROVIDER.trim() === '' ? null : e.PAYMENT_PROVIDER.trim(),
    antibot: {
      enabled: e.ANTIBOT_ENABLED === 'true',
      challengeTtlSeconds: e.CAPTCHA_TTL_SECONDS,
      passTtlSeconds: e.CAPTCHA_PASS_TTL_SECONDS,
      maxOtpSendsPerPass: e.CAPTCHA_MAX_OTP_SENDS_PER_PASS,
      failLimitPer10Min: e.CAPTCHA_FAIL_LIMIT_PER_10_MIN,
      accountCreatePerIpHour: e.ACCOUNT_CREATE_PER_IP_HOUR,
    },
    recovery: {
      maxFailuresBeforeLock: e.RECOVERY_MAX_FAILURES_BEFORE_LOCK,
      lockMinutes: e.RECOVERY_LOCK_MINUTES,
      failedPerIp15Min: e.RECOVERY_FAILED_PER_IP_15_MIN,
    },
    otp: {
      ttlSeconds: e.OTP_TTL_SECONDS,
      maxAttempts: e.OTP_MAX_ATTEMPTS,
      resendCooldownSeconds: e.OTP_RESEND_COOLDOWN_SECONDS,
      maxPerDestinationHour: e.OTP_MAX_PER_DESTINATION_HOUR,
      maxPerIpHour: e.OTP_MAX_PER_IP_HOUR,
      maxPerUserHour: e.OTP_MAX_PER_USER_HOUR,
    },
    guest: {
      inactivityMonths: e.GUEST_INACTIVITY_MONTHS,
      warningDays: e.GUEST_WARNING_DAYS,
      jobsEnabled: e.JOBS_ENABLED === 'true',
      cleanupIntervalMinutes: e.GUEST_CLEANUP_INTERVAL_MINUTES,
      cleanupBatch: e.GUEST_CLEANUP_BATCH,
    },
    smtp,
    sms,
    googleClientIds: e.GOOGLE_CLIENT_IDS.split(',').map((s) => s.trim()).filter(Boolean),
  };
}
