import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import Fastify, { type FastifyInstance } from 'fastify';
import type { PrismaClient } from '@prisma/client';
import { createDeliveries, type Deliveries } from './auth/delivery';
import { createGoogleVerifier, type GoogleVerifier } from './auth/google';
import { registerAuth } from './auth/plugin';
import type { AppConfig } from './config';
import { createPrisma } from './db';
import { registerErrorHandler } from './errors';
import { captchaRoutes } from './modules/antibot/routes';
import { chatRoutes } from './modules/chat/routes';
import { guestRoutes } from './modules/auth/guestRoutes';
import { identityRoutes } from './modules/auth/identityRoutes';
import { authRoutes } from './modules/auth/routes';
import { leaderboardRoutes } from './modules/leaderboards/routes';
import { notificationRoutes } from './modules/notifications/routes';
import { buildLevelTable, type LevelTable } from './modules/progression/levels';
import { blockRoutes, friendRoutes } from './modules/social/routes';
import { userRoutes } from './modules/users/routes';
import { walletRoutes } from './modules/wallet/routes';
import { storeRoutes } from './modules/store/routes';

declare module 'fastify' {
  interface FastifyInstance {
    levelTable: LevelTable;
  }
}

export interface BuildAppOptions {
  config: AppConfig;
  /** Inject an existing client (tests). If omitted, one is created and closed with the app. */
  prisma?: PrismaClient;
  /** Override SMS / e-mail delivery (tests). Defaults to what the configuration enables. */
  deliveries?: Deliveries;
  /** Override Google token verification (tests). Defaults to the real verifier when configured. */
  googleVerifier?: GoogleVerifier | null;
}

export async function buildApp(opts: BuildAppOptions): Promise<FastifyInstance> {
  const { config } = opts;
  const app = Fastify({
    logger: {
      level: config.logLevel,
      redact: ['req.headers.authorization', 'req.headers.cookie'],
    },
    trustProxy: config.trustProxy,
    bodyLimit: 64 * 1024,
  });

  const prisma = opts.prisma ?? createPrisma(config.databaseUrl);
  app.decorate('config', config);
  app.decorate('prisma', prisma);
  app.decorate('levelTable', buildLevelTable(config.levelCurve));
  app.decorate('deliveries', opts.deliveries ?? createDeliveries(config));
  app.decorate('googleVerifier', opts.googleVerifier === undefined ? createGoogleVerifier(config) : opts.googleVerifier);
  if (!opts.prisma) app.addHook('onClose', async () => prisma.$disconnect());

  await app.register(helmet);
  await app.register(cors, { origin: config.corsOrigins.length > 0 ? config.corsOrigins : false });
  await app.register(rateLimit, { max: config.rateLimitMax, timeWindow: config.rateLimitWindowSeconds * 1000 });

  registerErrorHandler(app);
  registerAuth(app);

  app.get('/health', async (_req, reply) => {
    try {
      await prisma.$queryRaw`SELECT 1`;
      return { status: 'ok' };
    } catch {
      return reply.status(503).send({ status: 'degraded' });
    }
  });

  await app.register(authRoutes, { prefix: '/v1/auth' });
  await app.register(guestRoutes, { prefix: '/v1/auth' });
  await app.register(identityRoutes, { prefix: '/v1/auth' });
  await app.register(captchaRoutes, { prefix: '/v1/captcha' });
  await app.register(userRoutes, { prefix: '/v1/users' });
  await app.register(friendRoutes, { prefix: '/v1/friends' });
  await app.register(blockRoutes, { prefix: '/v1/blocks' });
  await app.register(walletRoutes, { prefix: '/v1/wallet' });
  await app.register(storeRoutes, { prefix: '/v1/store' });
  await app.register(leaderboardRoutes, { prefix: '/v1/leaderboards' });
  await app.register(chatRoutes, { prefix: '/v1/chat' });
  await app.register(notificationRoutes, { prefix: '/v1/notifications' });

  return app;
}
