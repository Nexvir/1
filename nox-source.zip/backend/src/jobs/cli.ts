// Manual run of the guest-expiry job:
//   npm run job:guest-cleanup -- --dry-run     (report only)
//   npm run job:guest-cleanup                   (delete eligible guest accounts)
import { loadConfig } from '../config';
import { createPrisma } from '../db';
import { runAuthMaintenance, runGuestCleanup } from './guestCleanup';

async function main(): Promise<void> {
  const config = loadConfig();
  const prisma = createPrisma(config.databaseUrl);
  try {
    const dryRun = process.argv.includes('--dry-run');
    console.log(JSON.stringify({ guestCleanup: await runGuestCleanup(prisma, config, { dryRun }) }));
    if (!dryRun) console.log(JSON.stringify({ maintenance: await runAuthMaintenance(prisma) }));
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
