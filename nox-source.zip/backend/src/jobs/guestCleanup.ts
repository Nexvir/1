import { Prisma, type PrismaClient } from '@prisma/client';
import type { AppConfig } from '../config';

export interface CleanupOptions {
  /** Evaluate the policy as of this instant (tests). Defaults to the database clock. */
  now?: Date;
  /** Report what would be deleted without changing anything. */
  dryRun?: boolean;
  batchSize?: number;
}

export interface CleanupResult {
  dryRun: boolean;
  candidates: number;
  deleted: number;
  /** Candidates that became ineligible (activity / linking) or were locked by a concurrent request. */
  skipped: number;
  /** Candidates whose deletion raised an error (e.g. a constraint); they are retried on the next run. */
  failed: number;
}

/**
 * Eligibility, evaluated by the database so that the candidate scan and the per-account
 * re-check use exactly the same rule:
 *  - the account is still a guest (linking a method flips this, permanently),
 *  - it has no sign-in identity at all (belt and braces),
 *  - it is not suspended (moderation holds are never auto-deleted),
 *  - it does not own a clan (deleting an owner would orphan the clan),
 *  - the last server-confirmed activity is at least N months ago (never the creation date).
 */
function eligibility(config: AppConfig, now: Date | undefined): Prisma.Sql {
  const nowSql = now ? Prisma.sql`${now.toISOString()}::timestamptz` : Prisma.sql`now()`;
  return Prisma.sql`
    u."isGuest" = true
    AND u."status" = 'ACTIVE'
    AND u."lastActivityAt" + make_interval(months => ${config.guest.inactivityMonths}) <= ${nowSql}
    AND NOT EXISTS (SELECT 1 FROM "AuthIdentity" i WHERE i."userId" = u."id")
    AND NOT EXISTS (SELECT 1 FROM "ClanMembership" m WHERE m."userId" = u."id" AND m."role" = 'OWNER')`;
}

/**
 * Deletes guest accounts that have been inactive for GUEST_INACTIVITY_MONTHS.
 *
 * Safety properties:
 *  - Each account is handled in its own transaction that first locks the user row
 *    (`FOR UPDATE SKIP LOCKED`) and re-checks eligibility. A player who signs in, links a method,
 *    or is otherwise being updated at that moment is skipped, never deleted.
 *  - Several runners may execute at once (multiple instances): they cannot delete the same
 *    account twice or block each other.
 *  - Before the account is removed, a tombstone, a snapshot, and every financial row (wallet
 *    ledger, purchases) are copied to tables that outlive the account. The security event log and
 *    audit log have no foreign key to users and are kept untouched.
 */
export async function runGuestCleanup(prisma: PrismaClient, config: AppConfig, opts: CleanupOptions = {}): Promise<CleanupResult> {
  const batch = opts.batchSize ?? config.guest.cleanupBatch;
  const where = eligibility(config, opts.now);
  const result: CleanupResult = { dryRun: opts.dryRun === true, candidates: 0, deleted: 0, skipped: 0, failed: 0 };

  const candidates = await prisma.$queryRaw<{ id: string }[]>(Prisma.sql`
    SELECT u."id" FROM "User" u WHERE ${where} ORDER BY u."lastActivityAt" ASC LIMIT ${batch}`);
  result.candidates = candidates.length;
  if (opts.dryRun) return result;

  for (const { id } of candidates) {
    try {
      const outcome = await prisma.$transaction(async (tx) => {
        const locked = await tx.$queryRaw<{ id: string; accountCode: string; createdAt: Date; lastActivityAt: Date }[]>(Prisma.sql`
          SELECT u."id", u."accountCode", u."createdAt", u."lastActivityAt"
          FROM "User" u WHERE u."id" = ${id} AND ${where}
          FOR UPDATE OF u SKIP LOCKED`);
        const user = locked[0];
        if (!user) return 'skipped' as const;

        const [profile, wallet, clan, counts] = await Promise.all([
          tx.userProfile.findUnique({ where: { userId: id }, select: { xp: true, level: true, trophies: true, totalMatches: true } }),
          tx.wallet.findUnique({ where: { userId: id } }),
          tx.clanMembership.findUnique({ where: { userId: id }, select: { clanId: true, role: true } }),
          Promise.all([
            tx.walletTransaction.count({ where: { userId: id } }),
            tx.friendship.count({ where: { OR: [{ userAId: id }, { userBId: id }] } }),
            tx.purchase.count({ where: { userId: id } }),
          ]),
        ]);

        const deletion = await tx.accountDeletionRecord.create({
          data: {
            userId: id,
            accountCode: user.accountCode,
            reason: 'guest_inactive',
            accountCreatedAt: user.createdAt,
            lastActivityAt: user.lastActivityAt,
            snapshot: {
              inactivityMonths: config.guest.inactivityMonths,
              progress: profile ?? null,
              wallet: wallet
                ? { balance: wallet.balance, earnedTotal: wallet.earnedTotal, purchasedTotal: wallet.purchasedTotal, spentTotal: wallet.spentTotal, promoTotal: wallet.promoTotal }
                : null,
              clan: clan ?? null,
              counts: { walletTransactions: counts[0], friendships: counts[1], purchases: counts[2] },
            },
          },
        });

        // Financial records outlive the account (as JSON copies, with their original timestamps).
        await tx.$executeRaw`
          INSERT INTO "DeletedAccountLedgerEntry" ("id", "deletionId", "kind", "payload", "originalCreatedAt")
          SELECT gen_random_uuid()::text, ${deletion.id}, 'WALLET_TRANSACTION', to_jsonb(w), w."createdAt"
          FROM "WalletTransaction" w WHERE w."userId" = ${id}`;
        await tx.$executeRaw`
          INSERT INTO "DeletedAccountLedgerEntry" ("id", "deletionId", "kind", "payload", "originalCreatedAt")
          SELECT gen_random_uuid()::text, ${deletion.id}, 'PURCHASE', to_jsonb(p), p."createdAt"
          FROM "Purchase" p WHERE p."userId" = ${id}`;

        await tx.auditLog.create({
          data: {
            actorId: null,
            action: 'account.guest_expired_deleted',
            entityType: 'User',
            entityId: id,
            metadata: { accountCode: user.accountCode, deletionId: deletion.id, lastActivityAt: user.lastActivityAt.toISOString() },
          },
        });
        await tx.securityEvent.create({ data: { type: 'GUEST_DELETED', userId: id, metadata: { deletionId: deletion.id } } });

        // Dependent rows (profile, wallet, friendships, sessions, notifications, chat messages ...) go with
        // the user through ON DELETE CASCADE.
        await tx.user.delete({ where: { id } });
        return 'deleted' as const;
      });
      if (outcome === 'deleted') result.deleted++;
      else result.skipped++;
    } catch {
      // e.g. a constraint protecting immutable history; the account stays and is retried next run.
      result.failed++;
    }
  }
  return result;
}

/** Housekeeping for short-lived authentication rows. Never touches security events or deletion records. */
export async function runAuthMaintenance(prisma: PrismaClient, now: Date = new Date()): Promise<Record<string, number>> {
  const day = 86_400_000;
  const [captcha, otp, refresh, throttle] = await Promise.all([
    prisma.captchaChallenge.deleteMany({ where: { expiresAt: { lt: new Date(now.getTime() - day) } } }),
    prisma.otpCode.deleteMany({ where: { expiresAt: { lt: new Date(now.getTime() - day) } } }),
    prisma.refreshToken.deleteMany({ where: { expiresAt: { lt: new Date(now.getTime() - 7 * day) } } }),
    prisma.authThrottle.deleteMany({
      where: { lastFailureAt: { lt: new Date(now.getTime() - 7 * day) }, OR: [{ lockedUntil: null }, { lockedUntil: { lt: now } }] },
    }),
  ]);
  return { captchaChallenges: captcha.count, otpCodes: otp.count, refreshTokens: refresh.count, throttles: throttle.count };
}
