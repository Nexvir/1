import type { FastifyInstance } from 'fastify';
import { runAuthMaintenance, runGuestCleanup } from './guestCleanup';

/**
 * Starts the periodic backend jobs (guest expiry + auth housekeeping). The schedule lives on
 * the server; phones never decide when an account is deleted. Safe with several instances:
 * the cleanup locks each account row and skips ones another runner holds.
 */
export function startJobs(app: FastifyInstance): void {
  const { config, prisma, log } = app;
  if (!config.guest.jobsEnabled) {
    log.info('background jobs disabled (JOBS_ENABLED=false)');
    return;
  }

  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      const cleanup = await runGuestCleanup(prisma, config);
      const maintenance = await runAuthMaintenance(prisma);
      log.info({ cleanup, maintenance }, 'background jobs finished');
    } catch (err) {
      log.error({ err }, 'background jobs failed');
    } finally {
      running = false;
    }
  };

  const first = setTimeout(() => void tick(), 30_000);
  const timer = setInterval(() => void tick(), config.guest.cleanupIntervalMinutes * 60_000);
  first.unref();
  timer.unref();
  app.addHook('onClose', async () => {
    clearTimeout(first);
    clearInterval(timer);
  });
}
