/** Orders two ids with plain code-unit comparison (matches COLLATE "C" in the DB constraints). */
export function orderedPair(a: string, b: string): [string, string] {
  return a < b ? [a, b] : [b, a];
}

/** Canonical key for an unordered pair of users: "<smaller>:<larger>". */
export function pairKey(a: string, b: string): string {
  const [x, y] = orderedPair(a, b);
  return `${x}:${y}`;
}
