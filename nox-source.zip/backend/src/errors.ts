import type { FastifyError, FastifyInstance } from 'fastify';
import { Prisma } from '@prisma/client';
import { ZodError } from 'zod';
import { FA_MESSAGES } from './i18n/fa';

export class AppError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message: string,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const Errors = {
  badRequest: (code: string, message: string, details?: unknown) => new AppError(400, code, message, details),
  unauthorized: (message = 'Authentication required', code = 'UNAUTHORIZED') => new AppError(401, code, message),
  forbidden: (code: string, message: string) => new AppError(403, code, message),
  notFound: (code: string, message = 'Resource not found') => new AppError(404, code, message),
  conflict: (code: string, message: string, details?: unknown) => new AppError(409, code, message, details),
  unprocessable: (code: string, message: string, details?: unknown) => new AppError(422, code, message, details),
  tooMany: (code: string, message: string, retryAfterSeconds?: number) =>
    new AppError(429, code, message, retryAfterSeconds === undefined ? undefined : { retryAfterSeconds: Math.max(1, Math.ceil(retryAfterSeconds)) }),
  notImplemented: (code: string, message: string) => new AppError(501, code, message),
  /** A required external service (SMS, e-mail, Google) is not configured on this server. */
  unavailable: (code: string, message: string) => new AppError(503, code, message),
  badGateway: (code: string, message: string) => new AppError(502, code, message),
};

/** True for a Postgres unique-constraint violation, optionally matching a constraint/column hint. */
export function isUniqueViolation(err: unknown, hint?: string): boolean {
  if (!(err instanceof Prisma.PrismaClientKnownRequestError) || err.code !== 'P2002') return false;
  if (!hint) return true;
  const haystack = `${err.message} ${JSON.stringify(err.meta ?? {})}`;
  return haystack.includes(hint);
}

function body(code: string, message: string, details?: unknown) {
  const messageFa = FA_MESSAGES[code];
  return {
    error: {
      code,
      message,
      ...(messageFa ? { messageFa } : {}),
      ...(details !== undefined ? { details } : {}),
    },
  };
}

export function registerErrorHandler(app: FastifyInstance): void {
  app.setNotFoundHandler((_req, reply) => {
    reply.status(404).send(body('NOT_FOUND', 'Route not found'));
  });

  app.setErrorHandler((err: FastifyError | Error, req, reply) => {
    if (err instanceof AppError) {
      const retry = (err.details as { retryAfterSeconds?: unknown } | undefined)?.retryAfterSeconds;
      if (err.status === 429 && typeof retry === 'number') reply.header('retry-after', String(retry));
      return reply.status(err.status).send(body(err.code, err.message, err.details));
    }
    if (err instanceof ZodError) {
      return reply.status(400).send(
        body(
          'VALIDATION_ERROR',
          'Request validation failed',
          err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
        ),
      );
    }
    const status = (err as FastifyError).statusCode;
    if (status === 429) return reply.status(429).send(body('RATE_LIMITED', 'Too many requests, slow down'));
    if (status && status >= 400 && status < 500) return reply.status(status).send(body('BAD_REQUEST', 'Malformed request'));
    // Unexpected: log details server-side, never leak them to the client.
    req.log.error({ err }, 'unhandled error');
    return reply.status(500).send(body('INTERNAL_ERROR', 'Something went wrong'));
  });
}
