// Development seed: clearly flagged DEMO accounts (User.isDemo = true).
// Never runs in production. The shared demo password comes from the environment,
// it is not stored in the repository.
//
//   DEMO_SEED_PASSWORD='choose-something' npm run db:seed

import { generateAccountCode } from '../src/auth/codes';
import { hashPassword } from '../src/auth/password';
import { loadConfig } from '../src/config';
import { createPrisma } from '../src/db';
import { applyWalletChange } from '../src/modules/wallet/service';
import { buildLevelTable, levelFromXp } from '../src/modules/progression/levels';

const DEMO_PLAYERS = [
  { username: 'shadowking', displayName: 'ShadowKing', xp: 4200, trophies: 320, coins: 8750 },
  { username: 'sara_blue', displayName: 'Sara_Blue', xp: 3900, trophies: 298, coins: 11980 },
  { username: 'rexhunter', displayName: 'RexHunter', xp: 3600, trophies: 261, coins: 10760 },
  { username: 'armanxp', displayName: 'ArmanXP', xp: 2500, trophies: 190, coins: 9320 },
  { username: 'nika_storm', displayName: 'Nika_Storm', xp: 2100, trophies: 172, coins: 8910 },
];

async function main(): Promise<void> {
  const config = loadConfig();
  if (config.env === 'production') throw new Error('Refusing to seed demo data in production');
  const password = process.env.DEMO_SEED_PASSWORD;
  if (!password || password.length < 8) throw new Error('Set DEMO_SEED_PASSWORD (min 8 characters) to seed demo accounts');

  const prisma = createPrisma(config.databaseUrl);
  const table = buildLevelTable(config.levelCurve);
  const passwordHash = await hashPassword(password);

  try {
    for (const p of DEMO_PLAYERS) {
      const existing = await prisma.user.findUnique({ where: { username: p.username } });
      if (existing) {
        console.log(`skip ${p.username} (exists)`);
        continue;
      }
      await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            username: p.username,
            email: `${p.username}@demo.nox.invalid`,
            passwordHash,
            accountCode: generateAccountCode(),
            isDemo: true,
            profile: {
              create: { displayName: p.displayName, xp: p.xp, level: levelFromXp(table, p.xp), trophies: p.trophies },
            },
            wallet: { create: {} },
          },
        });
        await applyWalletChange(tx, {
          userId: user.id,
          amount: p.coins,
          kind: 'PROMO',
          source: 'demo_seed',
          idempotencyKey: `seed:${user.id}:coins`,
        });
      });
      console.log(`created demo player ${p.username}`);
    }
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
