-- Authentication overhaul: guest accounts + recovery codes, linked identities
-- (e-mail / phone / Google), one-time codes, NØX picture challenge, security events,
-- and guest-account deletion records.
--
-- Additive and data-preserving: existing users keep every row. Existing e-mail /
-- password accounts keep working. As with the init migration this file is written by
-- hand (see README "Known limitations") and uses Prisma's naming conventions.

-- CreateEnum
CREATE TYPE "IdentityProvider" AS ENUM ('EMAIL', 'PHONE', 'GOOGLE');
CREATE TYPE "OtpChannel" AS ENUM ('EMAIL', 'PHONE');
CREATE TYPE "OtpPurpose" AS ENUM ('LOGIN', 'LINK');
CREATE TYPE "CaptchaKind" AS ENUM ('FIND_TOY', 'ODD_ONE_OUT', 'FIND_OBJECT', 'FOLLOW_INSTRUCTION');

-- AlterTable "User": guests have neither e-mail nor password.
ALTER TABLE "User" ALTER COLUMN "email" DROP NOT NULL;
ALTER TABLE "User" ALTER COLUMN "passwordHash" DROP NOT NULL;
ALTER TABLE "User"
  ADD COLUMN "accountCode" TEXT,
  ADD COLUMN "isGuest" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN "guestConvertedAt" TIMESTAMP(3),
  ADD COLUMN "recoveryCodeHash" TEXT,
  ADD COLUMN "recoveryCodeRotatedAt" TIMESTAMP(3),
  ADD COLUMN "lastActivityAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Backfill existing rows (no data is removed or reset).
UPDATE "User"
SET "accountCode" = 'NX-' || upper(substr(md5(random()::text || "id"), 1, 8)),
    "lastActivityAt" = COALESCE("lastSeenAt", "createdAt")
WHERE "accountCode" IS NULL;

ALTER TABLE "User" ALTER COLUMN "accountCode" SET NOT NULL;
CREATE UNIQUE INDEX "User_accountCode_key" ON "User"("accountCode");
-- Serves the guest-expiry job without scanning every user.
CREATE INDEX "User_guest_activity_idx" ON "User"("lastActivityAt") WHERE "isGuest" = true;

-- CreateTable
CREATE TABLE "AuthIdentity" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "provider" "IdentityProvider" NOT NULL,
    "identifier" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastUsedAt" TIMESTAMP(3),
    CONSTRAINT "AuthIdentity_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "OtpCode" (
    "id" TEXT NOT NULL,
    "channel" "OtpChannel" NOT NULL,
    "purpose" "OtpPurpose" NOT NULL,
    "destinationHash" TEXT NOT NULL,
    "codeHash" TEXT NOT NULL,
    "userId" TEXT,
    "captchaChallengeId" TEXT,
    "ipHash" TEXT,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "maxAttempts" INTEGER NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "consumedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "OtpCode_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "CaptchaChallenge" (
    "id" TEXT NOT NULL,
    "kind" "CaptchaKind" NOT NULL,
    "prompt" TEXT NOT NULL,
    "options" JSONB NOT NULL,
    "correctToken" TEXT NOT NULL,
    "ipHash" TEXT,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "answeredAt" TIMESTAMP(3),
    "solved" BOOLEAN NOT NULL DEFAULT false,
    "passHash" TEXT,
    "passExpiresAt" TIMESTAMP(3),
    "passConsumedAt" TIMESTAMP(3),
    "passOtpSends" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CaptchaChallenge_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AuthThrottle" (
    "key" TEXT NOT NULL,
    "failures" INTEGER NOT NULL DEFAULT 0,
    "lockedUntil" TIMESTAMP(3),
    "lastFailureAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AuthThrottle_pkey" PRIMARY KEY ("key")
);

CREATE TABLE "SecurityEvent" (
    "id" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "userId" TEXT,
    "ipHash" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "SecurityEvent_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AccountDeletionRecord" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "accountCode" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "accountCreatedAt" TIMESTAMP(3) NOT NULL,
    "lastActivityAt" TIMESTAMP(3) NOT NULL,
    "deletedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "snapshot" JSONB NOT NULL,
    CONSTRAINT "AccountDeletionRecord_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "DeletedAccountLedgerEntry" (
    "id" TEXT NOT NULL,
    "deletionId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "payload" JSONB NOT NULL,
    "originalCreatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "DeletedAccountLedgerEntry_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "AuthIdentity_provider_identifier_key" ON "AuthIdentity"("provider", "identifier");
CREATE UNIQUE INDEX "AuthIdentity_userId_provider_key" ON "AuthIdentity"("userId", "provider");
CREATE INDEX "OtpCode_destinationHash_createdAt_idx" ON "OtpCode"("destinationHash", "createdAt" DESC);
CREATE INDEX "OtpCode_ipHash_createdAt_idx" ON "OtpCode"("ipHash", "createdAt");
CREATE INDEX "OtpCode_userId_createdAt_idx" ON "OtpCode"("userId", "createdAt");
CREATE INDEX "OtpCode_expiresAt_idx" ON "OtpCode"("expiresAt");
CREATE UNIQUE INDEX "CaptchaChallenge_passHash_key" ON "CaptchaChallenge"("passHash");
CREATE INDEX "CaptchaChallenge_expiresAt_idx" ON "CaptchaChallenge"("expiresAt");
CREATE INDEX "CaptchaChallenge_ipHash_createdAt_idx" ON "CaptchaChallenge"("ipHash", "createdAt");
CREATE INDEX "AuthThrottle_lastFailureAt_idx" ON "AuthThrottle"("lastFailureAt");
CREATE INDEX "SecurityEvent_type_ipHash_createdAt_idx" ON "SecurityEvent"("type", "ipHash", "createdAt");
CREATE INDEX "SecurityEvent_userId_createdAt_idx" ON "SecurityEvent"("userId", "createdAt");
CREATE INDEX "SecurityEvent_createdAt_idx" ON "SecurityEvent"("createdAt");
CREATE INDEX "AccountDeletionRecord_userId_idx" ON "AccountDeletionRecord"("userId");
CREATE INDEX "AccountDeletionRecord_accountCode_idx" ON "AccountDeletionRecord"("accountCode");
CREATE INDEX "DeletedAccountLedgerEntry_deletionId_idx" ON "DeletedAccountLedgerEntry"("deletionId");

-- AddForeignKey
ALTER TABLE "AuthIdentity" ADD CONSTRAINT "AuthIdentity_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "DeletedAccountLedgerEntry" ADD CONSTRAINT "DeletedAccountLedgerEntry_deletionId_fkey" FOREIGN KEY ("deletionId") REFERENCES "AccountDeletionRecord"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Custom constraints (not expressible in schema.prisma)
ALTER TABLE "OtpCode" ADD CONSTRAINT "OtpCode_attempts_check" CHECK ("attempts" >= 0 AND "maxAttempts" > 0);
ALTER TABLE "CaptchaChallenge" ADD CONSTRAINT "CaptchaChallenge_pass_sends_check" CHECK ("passOtpSends" >= 0);
ALTER TABLE "AuthIdentity" ADD CONSTRAINT "AuthIdentity_identifier_nonempty_check" CHECK (length("identifier") > 0);
