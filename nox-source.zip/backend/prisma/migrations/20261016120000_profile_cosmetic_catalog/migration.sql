INSERT INTO "StoreItem" ("id", "sku", "type", "name", "description", "price", "rarity", "available", "stackable", "isDemo", "createdAt")
VALUES
  ('catalog_frame_neon', 'frame_neon', 'PROFILE_FRAME', 'قاب نئون', 'قاب درخشان بنفش برای تصویر پروفایل', 250, 'COMMON', true, false, false, CURRENT_TIMESTAMP),
  ('catalog_frame_aurora', 'frame_aurora', 'PROFILE_FRAME', 'قاب شفق', 'قاب رنگین با درخشش آبی و بنفش', 600, 'RARE', true, false, false, CURRENT_TIMESTAMP),
  ('catalog_frame_crown', 'frame_crown', 'PROFILE_FRAME', 'قاب سلطنتی', 'قاب طلایی ویژهٔ پروفایل', 1200, 'EPIC', true, false, false, CURRENT_TIMESTAMP),
  ('catalog_title_star', 'title_star_player', 'TITLE', 'ستارهٔ بازی', 'عنوان نمایشی ستارهٔ بازی', 180, 'COMMON', true, false, false, CURRENT_TIMESTAMP),
  ('catalog_badge_victor', 'badge_victor', 'BADGE', 'نشان پیروز', 'نشان ویژهٔ بازیکنان برنده', 350, 'RARE', true, false, false, CURRENT_TIMESTAMP),
  ('catalog_theme_midnight', 'theme_midnight', 'THEME', 'تم نیمه‌شب', 'تم تیره با جزئیات بنفش', 500, 'RARE', true, false, false, CURRENT_TIMESTAMP)
ON CONFLICT ("sku") DO NOTHING;
