CREATE TABLE "DeviceAccount" (
    "id" TEXT NOT NULL,
    "installationHash" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "DeviceAccount_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "DeviceAccount_installationHash_key" ON "DeviceAccount"("installationHash");
CREATE UNIQUE INDEX "DeviceAccount_userId_key" ON "DeviceAccount"("userId");

ALTER TABLE "DeviceAccount"
    ADD CONSTRAINT "DeviceAccount_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
