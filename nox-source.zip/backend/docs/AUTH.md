# NØX — Sign-up, login, recovery and anti-bot

Scope: only the account system. Game features are untouched. Everything below is implemented and covered by
integration tests that run against a real PostgreSQL database (`npm test`, 130 tests in total).

## Account types

| Type | How it is created | Notes |
|---|---|---|
| Guest | `POST /v1/auth/guest` (+ captcha pass) | Gets a public account ID `NX-XXXXXXXX` and a one-time **recovery code** (20 chars, shown once, stored only as an HMAC). The ID alone can never log in. |
| Phone | `POST /v1/auth/otp/request` + `/otp/verify` (`channel: PHONE`) | Iranian mobile numbers, normalised to E.164. |
| E-mail code | same endpoints, `channel: EMAIL` | Passwordless. |
| Google | `POST /v1/auth/google` | ID token verified on the server (signature, issuer, expiry, audience). Only the verified `sub` is trusted. |
| Legacy password | `POST /v1/auth/register` / `login` | Kept for compatibility (captcha now required). Its e-mail is **not** verified and is not a sign-in identity. |

None is mandatory. `GET /v1/auth/methods` reports honestly which methods this server can really perform.

## Flows

**Captcha** — `POST /v1/captcha/challenges` → 6 picture options (PNG via `GET .../images/:file.png`) and a Persian prompt;
`POST .../challenges/:id/answer {optionId}` → `{pass}`. One answer per challenge; a wrong answer invalidates it (new challenge needed).
The pass is single-use and short-lived, and is consumed inside the account-creation transaction. One pass may authorise at most 3 OTP sends.
Sign-in to an *existing* Google/phone/e-mail account does not require a pass for Google; OTP always requires one (it triggers a message).

**Guest** — captcha pass → `POST /v1/auth/guest` → `{account, recoveryCode, tokens}`.
**Recovery** — `POST /v1/auth/recover {accountCode, recoveryCode}` → new session, same account and data. The recovery code is rotated
only via `POST /v1/auth/recovery-code/rotate` (authenticated). Repeated failures lock the account code (15 → 30 → 60 min … up to 24 h);
non-existent codes lock identically (no enumeration); there is also a per-IP failure cap.
**Linking** — authenticated `POST /v1/auth/link/otp/request|verify` or `/link/google`. The account ID, data and recovery code are
unchanged; `isGuest` becomes false, which permanently ends the auto-deletion policy. If the method already belongs to another account the
answer is `409 IDENTITY_IN_USE` and **nothing is merged or changed**.

## Guest auto-deletion

Guests whose **last server-verified activity** (sign-in, token refresh, recovery, authenticated API use at most hourly) is ≥ 9 months old
(`GUEST_INACTIVITY_MONTHS`) are deleted by a backend job (hourly in-process scheduler, or `npm run job:guest-cleanup [-- --dry-run]`).
Exempt: linked accounts, accounts with any identity, suspended accounts, clan owners. Each deletion locks the row (`FOR UPDATE SKIP LOCKED`),
re-checks eligibility, writes a tombstone + snapshot (`AccountDeletionRecord`), copies wallet ledger and purchases to
`DeletedAccountLedgerEntry`, and writes audit/security events (which have no FK to users and are kept). Profile, sessions, friendships,
notifications, XP/trophy rows are removed with the account.
Warning: when a guest signs in/recovers/refreshes within the last `GUEST_WARNING_DAYS` (30) before the deadline, the response includes
`notice` (Persian message) and an in-app notification is stored (once per warning period). `GET /v1/auth/account` always returns `guestExpiry`.

## Configuration (see `.env.example`)

| Needed for | Variables | Without it |
|---|---|---|
| Everything | `SERVER_PEPPER` (≥32 chars, secret, stable), `JWT_ACCESS_SECRET`, `DATABASE_URL` | server refuses to start |
| E-mail codes | `SMTP_HOST`, `SMTP_PORT`, `SMTP_FROM`, `SMTP_USER/PASS` (TLS required by default) | `EMAIL_NOT_CONFIGURED` (503, Persian message) |
| SMS codes | `SMS_PROVIDER=kavenegar`, `KAVENEGAR_API_KEY`, `KAVENEGAR_TEMPLATE` | `SMS_NOT_CONFIGURED` (503) |
| Google | `GOOGLE_CLIENT_IDS` | `GOOGLE_NOT_CONFIGURED` (503) |

A failed delivery returns `502 DELIVERY_FAILED` and leaves no live code; success is never faked. Passwords, codes, recovery codes and tokens are
never logged; the database stores only HMACs/hashes of codes, phone/e-mail lookups and IPs.

## Known limitations (honest list)

- **No Android client exists yet**, so the dark-neon RTL sign-in/captcha screens are not built; the API provides Persian prompts and messages.
- The Kavenegar adapter follows the public docs and is tested only against a local mock — try it with a real key before launch.
  Real Google verification is tested with locally generated keys, not against Google's live certificates.
- SMTP is tested against a local server without TLS (with `SMTP_REQUIRE_TLS=false`) and the plaintext refusal; a TLS handshake against a real provider was not tested.
- The picture CAPTCHA is a deterrent against simple bots, not a defense against ML solvers; passes are not IP-bound. Rate limits and lockouts are the second layer.
- The migration `20261015120000_auth_overhaul` is hand-written (not diffed by Prisma); it was applied to dev and test databases only.
- A guest that appears in a finalized leaderboard snapshot cannot be deleted (immutability trigger); the job counts it as `failed` and retries. To be revisited with the leaderboard milestone.
- Legacy password accounts are not guests and are never auto-deleted.
